<?php
session_start();
include('include/conn.php');
include('include/tanggal.php');
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$myusername=strtolower($_POST['username']);
$mypassword=md5(md5($_POST['password'])); 
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysql_real_escape_string($myusername);
$mypassword = mysql_real_escape_string($mypassword);
$mywarehouse = $_POST['warehouse'];


$aktivitas="LOGIN";
$menu="LOGIN";
if(!empty($myusername) && !empty($mypassword) && $mywarehouse<>'00'){
   $sql="SELECT username,password,level,id_user FROM `tbl_user` where username='$myusername' and md5='$mypassword'";
   //echo $sql."<br>";
   $result=mysql_query($sql); 
   $count=mysql_num_rows($result);
   $brs_user = mysql_fetch_row($result);
   if($count==1){
      $_SESSION['kdadmin'] = $brs_user[3];
	  $_SESSION['user_name'] = $myusername;
	  $_SESSION['user_level'] = $brs_user[2];
	  $_SESSION['warehouse'] = $_POST['warehouse'];
	  $url = $_SERVER['REQUEST_URI'];
	  mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$brs_user[2]', '$brs_user[0]','$aktivitas','$menu', '$mywarehouse');");
	  
	  echo "<script>location.href='index_log.php'</script>";
      header("Location: index_log.php");
   }else{
      echo "<script>alert('Maaf, Username atau password salah');location.href='index.php'</script>";
      header("Location: index.php");
   }
 }else{
  echo "<script>alert('Maaf, Data Kosong');location.href='index.php'</script>";
  header("Location: index.php");
}
?>