<?php
session_start();
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
$tgl_retur1 = $_POST[tgl_retur1];
list($day, $month, $year) = split('[/.-]', $tgl_retur1);
$tgl_retur1 = $year."-".$month."-".$day;

$tgl_retur2 = $_POST[tgl_retur2];
list($day, $month, $year) = split('[/.-]', $tgl_retur2);
$tgl_retur2 = $year."-".$month."-".$day;
				  
if($_POST[del]=='1'){
	$dele="DELETE FROM `db_knm`.`tbl_retur` WHERE  `kode_retur_int`='$_POST[id]';";
	//echo $dele;
	mysql_query($dele);
	
	$gmt=date("Z");
	$session_time=date("U");
	$session_id=session_id();
	$ipaddress=$_SERVER['REMOTE_ADDR'];
	$ip= $REMOTE_ADDR;
	$host_name = GetHostByName($ip);
	$aktivitas="DELETE RETUR ".$_POST[id];
	$menu="SALES";
	$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
$url = $_SERVER['REQUEST_URI'];
mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");
	
	$del_stok="DELETE FROM `db_knm`.`tbl_stok` WHERE  `kode_so_int_FK`='$_POST[id]';";
	//echo $del_stok."<br>";
	mysql_query($del_stok);
}

///////////////////////////////////
$batasan = 30;  
 	if(isset($_POST["batas"])){   
  		$batas = $_POST["batas"];  
 	}  
 	else if(isset($_GET["batas"])){   
  		$batas = $_GET["batas"];   
 	}else{  
		$batas = $batasan;   
 	}  
 	if(isset($_POST["halaman"])){   
  		$halaman = $_POST["halaman"];  
 	}else{ 
		$halaman = $_GET["halaman"]; 
	}  
	if(empty($halaman)){  
  		$posisi = 0;  
  		$halaman = 1;  
 	}else{  
		$posisi = intval(($halaman-1) * $batas);  
 	}  
?>
<style type="text/css">
<!--
.style1 {color: #F0F0F0}
-->
</style>
<input type="hidden" name="halaman" value="<?php echo $halaman;?>" />  
<?php  
 	if(empty($batas)){
		$batas = intval($batasan);  
	}else{
		$batas=intval($batas);
	}
?>  
<link href="../admin/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<form name="form_tr" action="" method="POST">
<table width="100%" cellspacing="0" class="sort-table" id="table-1">
<thead>
  <tr >
    <td width="42" ><div align="center">NO</div></td>
	<td ><div align="center">NO.<span class="style1">.</span>RETUR</div></td>
    <td ><div align="center">NO.<span class="style1">.</span>RETUR<span class="style1">.</span>INTERNAL</div></td>
    <td width="360" ><div align="center">PEMESAN</div></td>
    <td width="317" ><div align="center">NILAI</div></td>
	<td ><div align="center">TANGGAL RETUR</div></td>
    <td width="82" ><div align="center">APPROVAL</div></td>
    <td width="34" ><div align="center">EDIT</div></td>
    <td width="34" ><div align="center">VIEW</div></td>
    <td width="29" ><div align="center">DEL</div></td>
  </tr>
  </thead>
<tbody>
<?php

if($_POST[pemesan]<>'00000000000000000000'){
	$pemesan="AND tbl_retur.id_buyer_FK = '$_POST[pemesan]'";
}
if(!empty($_POST[kode_retur])){
	$kode_retur="AND tbl_retur.kode_retur like '%$_POST[kode_retur]%'";
}
$limit="LIMIT $posisi,$batas";
$groupby="group by tbl_retur.kode_retur_int";
$sql_data="SELECT
tbl_retur.id_retur,
tbl_retur.kode_retur,
tbl_retur.kode_retur_int,
tbl_retur.tanggal_retur,
tbl_retur.id_satuan_FK,
tbl_retur.id_size_FK,
tbl_retur.harga_jual,
tbl_retur.jumlah,
tbl_retur.kode_produk_FK,
tbl_retur.id_buyer_FK,
tbl_buyer.nama_buyer
FROM
tbl_retur
Inner Join tbl_buyer ON tbl_buyer.id_buyer = tbl_retur.id_buyer_FK
WHERE tbl_retur.tanggal_retur between '$tgl_retur1' and '$tgl_retur2'
";
	$sql_data1=$sql_data." ".$pemesan." ".$kode_retur." ".$groupby." ".$limit;
	//echo $sql_data1;
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$sql_count_edit=mysql_query("select count(kode_so_int_FK) from tbl_retur_aprove where kode_so_int_FK = '$data[kode_retur_int]'");
		$rs_count_edit=mysql_fetch_row($sql_count_edit);
		//echo $rs_count_edit[0]."<br>";
		
		$i++;
		$x=$batasan*($halaman-1)+$i;
		if($x=='0'){
			$z=$i;
		}else{
			$z=$x;
		}
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#E8FFFF";
		}else{
	   		$warna ="#B0D8FF";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#CCFF99'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  class="dr1"><div align="center"><?php echo $x; ?></div></td>
    <td width="179"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[kode_retur];?>
<input name="id<?php echo $i;?>" type="hidden" value="<?php echo $data[kode_retur_int];?>" /></div></td>
<td width="179"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[kode_retur_int];?></div></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "  width="360" class="dr1"><div align="left"><?php echo $data[nama_buyer];?></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  width="317" class="dr1"><div align="right"><?php echo comma0($data[sumharga]);?></div></td>
    <td class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><?php echo tampil_tgl($data[tanggal_retur]);?></div></td>
    <td class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><img src="../images/check.ico" width="16" onclick="javascript:MM_openBrWindow1('../input_retur/apr.php?id=<?PHP echo $data[kode_retur_int];?>')" /></div></td>
	<td width="34"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center">
	<?php
		if($rs_count_edit[0]=='2'){
			echo "";
		}else{
			echo "<img src=../images/edit.ico border=0 width=16 onclick=javascript:MM_openBrWindow1('../input_retur/ed.php?id=$data[kode_retur_int]') title=EDIT PURCHASE ORDER [ $data[kode_retur_int]]/>";
		}
	?>
	</div></td>
    <td width="29"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><?php
		if($rs_count_edit[0]=='2'){
			echo "<img src=../images/view1.ico border=0 width=16 onclick=javascript:MM_openBrWindow1('../input_retur/view.php?id=$data[kode_retur_int]') title=VIEW PURCHASE ORDER [ $data[kode_retur_int]]/>";
		}else{
			echo "";
		}
	?>
	</div></td>
    <td width="29"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center">
	<?php
		if($rs_count_edit[0]=='2'){
			echo "";
		}else{
			echo "<input type=checkbox name=del onclick='get_del(this.form, $i)'/>";
		}
	?>
	</div></td>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<td colspan="10">
    <input type="hidden" name="pemesan" value="<?php echo $_POST[pemesan];?>" />
    <input type="hidden" name="kode_retur" value="<?php echo $_POST[kode_retur];?>" />
    <input type="hidden" name="tgl_retur1" value="<?php echo $_POST[tgl_retur1];?>" />
    <input type="hidden" name="tgl_retur2" value="<?php echo $_POST[tgl_retur2];?>" /></td>
   </tr>
   </tbody>
</table>
<?php
	echo"<div align=\"center\">"; 
	$sql_tampil2="SELECT
tbl_retur.id_retur,
tbl_buyer.nama_buyer
FROM
tbl_retur
Inner Join tbl_buyer ON tbl_buyer.id_buyer = tbl_retur.id_buyer_FK
WHERE tbl_retur.tanggal_retur between '$tgl_retur1' and '$tgl_retur2'
";
	$sql_data1=$sql_tampil2." ".$pemesan." ".$kode_retur." ".$groupby;
	//echo "$sql_data1"."<br>";
	$tampil2 = mysql_query($sql_data1);  
	$jmldata = mysql_num_rows($tampil2);  
	$jmlhalaman = ceil($jmldata/$batas);  
	if($halaman > 1){  
		$previous=$halaman-1;  
?>  
	<input type="button" value="<<" onClick="javascript:get_first(this.parentNode, this.form, <?php echo "1";?>);">&nbsp;|&nbsp;
	<input type="button" value="<" onClick="javascript:get_prev(this.parentNode, this.form, <?php echo $previous;?>);">&nbsp;|&nbsp;
<?php  
 	}else{
?>
		<input type="button" value="<<" >&nbsp;|&nbsp;
		<input type="button" value="<" >&nbsp;|&nbsp;
<?php
	}  
 	$angka=($halaman > 3 ? " ... " : " ");  
 	for($i=$halaman-2;$i<$halaman;$i++){  
  	if($i < 1)  
   		continue;  
  		//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";
		$angka .=$i;
 	}  
 	$angka .= " <b>$halaman</b> ";  
 	for($i=$halaman+1;$i<($halaman+3);$i++){  
  		if($i > $jmlhalaman)  
   			break;  
			//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";  
			$angka .=$i;  
 		}  
		$angka .=($halaman+2<$jmlhalaman ?"...$jmlhalaman ":""); 
		//$angka .= ($halaman+2<$jmlhalaman ? " ... <a href=?halaman=$jmlhalaman&batas=$batas class=linka>$jmlhalaman</a> " : " ");  
 		echo"$angka";  
 		if($halaman < $jmlhalaman){  
  			$next=$halaman+1;
			?>
  			|&nbsp;<input type="button" value=">" onClick="javascript:get_next(this.parentNode, this.form, <?php echo $next;?>);">&nbsp;|&nbsp;
			<input type="button" value=">>" onClick="javascript:get_last(this.parentNode, this.form, <?php echo $jmlhalaman;?>);">
			<?php
 		}else{ ?>
 			<input type="button" value=">">&nbsp;|&nbsp;<input type="button" value=">>" >
		<?php
 		}  
 		echo"Total : <b>$jmldata</b>";   
?>
</form>

<script type="text/javascript">
//<![CDATA[
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
//]]>
</script>
