<?php
session_start();
include('include/conn.php');
//include('include/tanggal.php');
$hour = gmdate("H");
$minute = gmdate("i");
$seconds = gmdate("s");
$day = gmdate("d");
$month = gmdate("m");
$year = gmdate("Y");
$hour = $hour + 7; 
$lengkap = date("Y-m-d h:i:s", mktime ($hour,$minute,$seconds,$month,$day,$year)); 

$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$aktivitas="Logout";
$menu="Logout";
$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
$url = $_SERVER['REQUEST_URI'];
 mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");


session_start();
session_unset();
session_destroy();
session_start();

$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();

$session_user="Guest";
$session_mode="-1";
echo "<script>location.href='index.php'</script>";
header("location:index.php");
?>