<?php
	class cek_so {
		function createConnection() {
			require_once "../include/conn.php";
			mysql_select_db($database_conn);
		}
		
		function cek_so1($no_pemesanan) {
			if (!empty($no_pemesanan)) {
			  $user = trim($no_pemesanan);		
			      $query12 = mysql_query("SELECT kode_so FROM tbl_so where kode_so ='$no_pemesanan'");
			      $result12 = mysql_fetch_array($query12);
			      if(empty($result12[0])){
					echo "<div align=center><input class=inputbutton type=button name=button2 value=POST onClick='javascript:get(this.parentNode, this.form);showCustomer(this.value)'/>   <input class=inputbutton type=button name=button3 value=SAVE onClick='javascript:window.close()'/></div>";
			      }else{
			        echo "<div align=center><font color=red>Already Registered</font><br/> <img src=../images/no.ico /></div>";
			      } 
			}else {
			  echo ""; 
			}
		}		
	}
	
	$no_pemesanan = $_GET['v'];
	cek_so::createConnection();
	cek_so::cek_so1($no_pemesanan);
?>
