<?php
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma1($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 1, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 1, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}

$no_pemesanan=trim($_POST[no_pemesanan]);

$tgl_pemesanan = $_POST[tgl_pemesanan];
list($day, $month, $year) = split('[/.-]', $tgl_pemesanan);
$tgl_pemesanan = $year."-".$month."-".$day;

$tgl_kirim = $_POST[tgl_kirim];
list($day, $month, $year) = split('[/.-]', $tgl_kirim);
$tgl_kirim = $year."-".$month."-".$day;

// MENCARI id_satuan_FK
$sql_digt=mysql_query("select 
kode_produk,kode_produk_buyer,
nama_produk,nama_faktur_pajak,
nama_lain, id_sbu_FK,ppn,id_satuan_FK 
from tbl_produk 
where kode_produk = '$_POST[item]'");
/*echo "select 
kode_produk,kode_produk_buyer,
nama_produk,nama_faktur_pajak,
nama_lain, id_sbu_FK,ppn,id_satuan_FK 
from tbl_produk 
where kode_produk = '$_POST[item]'";*/
$digit=mysql_fetch_assoc($sql_digt);

//mencari id_buyer_grup_FK
$sql_buyer_grup_FK=mysql_query("select id_buyer_grup_FK,nama_buyer from tbl_buyer where id_buyer = '$_POST[pemesan]'");
$buyer_grup_FK=mysql_fetch_assoc($sql_buyer_grup_FK);

//mencari id_company_FK
$sql_company_FK=mysql_query("select id_company_FK from tbl_buyer_grup where id_buyer_grup = '$buyer_grup_FK[id_buyer_grup_FK]'");
$company_FK=mysql_fetch_assoc($sql_company_FK);

//mencari harga terakhir SEMENTARA TIDAK DIPAKAI
$sql_hrg=mysql_query("select harga_jual 
from tbl_harga 
where id_buyer_grup_FK = '$buyer_grup_FK[id_buyer_grup_FK]' 
and aktif = 'YES' 
and kode_produk_FK ='$_POST[item]'");
//$hrg=mysql_fetch_assoc($sql_hrg);

//mencari nilai tbl_so_number ada yang kembar tidak??????
/*$sql_kembar=mysql_query("select count(kode_so) from tbl_so_number where kode_so = '$_POST[no_pemesanan]'");
echo "select count(kode_so) from tbl_so_number where kode_so = '$_POST[no_pemesanan]'"."<br>";
$rs_kembar=mysql_fetch_row($sql_kembar);
$kembar=$rs_kembar[0];
//echo $kembar."<br>";*/
//mencari nilai due day
if(empty($_POST[due_day])){
	$sql_dd="select due_day from tbl_buyer where id_buyer = '$_POST[pemesan]'";
	$qry_dd=mysql_query($sql_dd);
	$dt_dd=mysql_fetch_row($qry_dd);
	$dueday=$dt_dd[0];
}else{
	$dueday=$_POST[due_day];
}
if($_POST[input]=='1'){
	$input="INSERT INTO `tbl_so` (
	`kode_so_int`, `kode_so`, `tanggal_so`, `tanggal_kirim`, `id_satuan_FK`, 
	`mc`, `harga_jual`, `jumlah`, `kode_produk_FK`, 
	`id_buyer_FK`, `posting_so_si`, `id_company_FK`, `val_ppn`, `input_account`, `input_time`, `sbu`, `kode_marketing`, `due_day`, `nama_produk`, `nama_buyer`, `nama_lain`, `kode_produk_buyer`
	) VALUES (
	'$_POST[kode_so_int]', '$_POST[no_pemesanan]', '$tgl_pemesanan', '$tgl_kirim', '$digit[id_satuan_FK]', 
	'', '$_POST[harga_jual]', '$_POST[jumlah]', '$_POST[item]',
	'$_POST[pemesan]', '', '$company_FK[id_company_FK]', '$_POST[value_ppn]', '$_POST[input_account]', '$_POST[input_time]', '$_POST[kode_kita]', '$_POST[sales]', '$dueday', '$digit[nama_produk]', '$buyer_grup_FK[nama_buyer]', '$digit[nama_lain]', '$digit[kode_produk_buyer]');";
	mysql_query($input);
	//echo $input."<br>";
}
if($_POST[del]=='1'){
	$dele="DELETE FROM `tbl_so` WHERE `id_so`='$_POST[id_so]'";
	mysql_query($dele);
	//echo $dele."<br>";
}
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<style type="text/css">
<!--
.style1 {color: #F0F0F0}
-->
</style>

<!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<link href="../admin/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>

<div class="panel-body">
<div class="table-responsive">
<table class="table table-bordered table-hover table-striped" id="dataTable-example">
<thead>
  <tr >
    <th width="48" class="dr2"><div align="center">No</div></th>
    <th width="144" class="dr2"><div align="center">Barcode</div></th>
    <th width="652" class="dr2"><div align="center">Nama Barang</div></th>
	<th width="84" class="dr2"><div align="center">Satuan</div></th>
	<th width="124" class="dr2"><div align="center">Jumlah</div></th>
    <th width="125" class="dr2"><div align="center">Harga/Satuan</div></th>
	<th width="125" class="dr2"><div align="center">Total</div></th>
    <th width="38" class="dr2"><div align="center">Del</div></th>
  </tr>
</thead>
<tbody>
<?php
	$sql_data="SELECT
	tbl_so.id_so,
	tbl_so.kode_so,
	tbl_so.id_satuan_FK,
	tbl_so.harga_jual,
	tbl_so.jumlah,
	tbl_so.kode_produk_FK,
	tbl_so.id_buyer_FK,
	tbl_produk.kode_produk_buyer,
	tbl_produk.nama_produk,
	tbl_satuan.nama_satuan
	FROM
	tbl_so
	INNER JOIN tbl_produk ON tbl_produk.kode_produk = tbl_so.kode_produk_FK
	INNER JOIN tbl_satuan ON tbl_satuan.id_satuan = tbl_so.id_satuan_FK
	WHERE
	kode_so = '$no_pemesanan'";
	//echo $sql_data;
	$qry_data = mysql_query($sql_data);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#9DC5E6";
		}else{
	   		$warna ="#BCDADA";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#FFFFB0'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <th style="color: windowtext; border-right: .5pt solid windowtext; "  ><div align="center"><?php echo $i; ?></div></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext; "  width="144" ><div align="left"><?php echo $data[kode_produk_buyer];?>
	  <input name="id_so<?php echo $i;?>" type="hidden" value="<?php echo $data[id_so];?>" />
	</div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; "  ><?php echo $data[nama_produk];?></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo $data[nama_satuan];?></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma1($data[jumlah]); $total_jumlah+=$data[jumlah];?></div></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[harga_jual]);?></div>	</th>
	<th style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php 
	$total_harga=$data[harga_jual]*$data[jumlah];echo comma0($total_harga);  $sumharga+=$total_harga; 
	?></div>	</th>
    <th width="38"  style="color: windowtext; border-right: .5pt solid windowtext; ">
	  <div align="center"><input type="checkbox" name="del" onclick="get_del(this.form, <?php echo $i;?>);" /></div>
	</a></th>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; " colspan="4"><div align="center">
    <input type="hidden" name="pemesan" value="<?php echo $_POST[pemesan];?>" />
    <input type="hidden" name="no_pemesanan" value="<?php echo $_POST[no_pemesanan];?>" />
    <input type="hidden" name="tgl_pemesanan" value="<?php echo $_POST[tgl_pemesanan];?>" />
    <input type="hidden" name="tgl_kirim" value="<?php echo $_POST[tgl_kirim];?>" />
    <input type="hidden" name="item" value="<?php echo $_POST[item];?>" />
    <input type="hidden" name="jumlah" value="<?php echo $_POST[jumlah];?>" />
	<input type="hidden" name="ppn" value="<?php echo $_POST[ppn];?>" />
    <input type="hidden" name="kode_so_int" value="<?php echo $_POST[kode_so_int];?>" /></div></th>
   <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma1($total_jumlah);?></strong></div></th>
   <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"></div></th>
   <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sumharga);?></strong></div></th>
   <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;</th>
   </tr>
   </tbody>
</table>
</div>
</div>
<script type="text/javascript">
//<![CDATA[
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
//]]>
</script>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
</html>
