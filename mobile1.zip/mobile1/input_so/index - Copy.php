<?php 
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$aktivitas="VIEW ADD SALES ORDER";
$menu="SALES";
$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
$url = $_SERVER['REQUEST_URI'];
mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");

function tampil_tgl($tgl){
  		list($year, $month ,$day ) = split('[/.-]', $tgl);
		$tgl_view=$day."/".$month."/".$year;
  		return $tgl_view;
	}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADD</title>
<script type="text/javascript" language="javascript">
  function MM_openBrWindow(theURL,winName,features) { //v2.0
  		var width  = 900;
		var height = 300;
		window.open(theURL,winName,'toolbar=no,menubar=no,resizable=no,scrollbars=yes,status=no,location=no,width='+width+',height='+height);
	}
</script>
<link type="text/css" rel="stylesheet" href="../include/styles00.css" />
<link type="text/css" rel="stylesheet" href="../include/dhtmlgoodies_calendar.css?random=20051112" media="screen"></LINK>
<link type="text/css" rel="stylesheet" href="../include/jquery.autocomplete.css" />
<link type="text/css" rel="stylesheet" href="../include/thickbox.css" />

<SCRIPT type="text/javascript" src="../include/dhtmlgoodies_calendar.js?random=20060118"></script>
<script type="text/javascript" src="../include/jquery.js"></script>
<script type="text/javascript" src="../include/menu.js"></script>
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<script type="text/javascript" src="../include/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="../include/thickbox-compressed.js"></script>
<script type="text/javascript" src="../include/jquery.autocomplete.js"></script>
<script type="text/javascript" src="../include/localdata.js"></script>
<script type="text/javascript" src="../include/selectjenis.js"></script>
<script type="text/javascript" language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<!-------------data  autocomplet--->
<script type="text/javascript">
	$().ready(function() {
	
		function findValueCallback(event, data, formatted) {
			$("<li>").html( !data ? "No match!" : "Selected: " + formatted).appendTo("#result");
		}
		function formatItem(row) {
			return row[0] + " (<strong>id: " + row[1] + "</strong>)";
		}

		function formatResult(row) {
			return row[0].replace(/(<.+?>)/gi, '');
		}
		
		$("#singleBirdRemote1").autocomplete("pemesan.php", {
		width: 252,
		selectFirst: false
		});
		$("#singleBirdRemote1").result(function(event, data, formatted) {
			if (data)
				$(this).parent().next().find("input").val(data[1]);
		});
	});
	function changeOptions(){
		var max = parseInt(window.prompt('Please type number of items to display:', jQuery.Autocompleter.defaults.max));
		if (max > 0) {
			$("#suggest1").setOptions({
				max: max
			});
		}
	}
	function changeScrollHeight() {
		var h = parseInt(window.prompt('Please type new scroll height (number in pixels):', jQuery.Autocompleter.defaults.scrollHeight));
		if(h > 0) {
			$("#suggest1").setOptions({
				scrollHeight: h
			});
		}
	}
	function changeToMonths(){
		$("#suggest1")
			// clear existing data
			.val("")
			// change the local data to months
			.setOptions({data: months})
			// get the label tag
			.prev()
			// update the label tag
			.text("Month (local):");
	}
	var http_request = false;
   function makePOSTRequest(url, parameters) {
      http_request = false;
      if (window.XMLHttpRequest) { // Mozilla, Safari,...
         http_request = new XMLHttpRequest();
         if (http_request.overrideMimeType) {
            http_request.overrideMimeType('text/html');
         }
      } else if (window.ActiveXObject) { // IE
         try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
         } catch (e) {
            try {
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
         }
      }
      if (!http_request) {
         alert('Cannot create XMLHTTP instance');
         return false;
      }
      http_request.onreadystatechange = alertContents;
      http_request.open('POST', url, true);
      http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      http_request.setRequestHeader("Content-length", parameters.length);
      http_request.setRequestHeader("Connection", "close");
      http_request.send(parameters);
   }
   function alertContents() {
      if (http_request.readyState == 4) {
         if (http_request.status == 200) {
            result = http_request.responseText;
            document.getElementById('myspan').innerHTML = result;            
         } else {
            alert('There was a problem with the request.');
         }
      }
   }

function get(obj, df) { 
	var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_kirim=" + encodeURI(df['tgl_kirim'].value)+
				  "&tgl_pemesanan=" + encodeURI(df['tgl_pemesanan'].value)+
				  "&item=" + encodeURI(df['item'].value)+
				  "&jumlah=" + encodeURI(df['jumlah'].value)+
				  "&harga_jual=" + encodeURI(df['harga_jual'].value)+
				  //"&value_ppn=" + encodeURI(df['value_ppn'].value)+ 
				  "&kode_so_int=" + encodeURI(df['kode_so_int'].value)+
				  "&input_account=" + encodeURI(df['input_account'].value)+
				  "&input_time=" + encodeURI(df['input_time'].value)+  
				  "&kode_kita=" + encodeURI(df['kode_kita'].value)+  
				  "&sales=" + encodeURI(df['sales'].value)+  
				  "&due_day=" + encodeURI(df['due_day'].value)+  
				  "&input=1";
				  if(df['pemesan'].value=='00000000000000000000'){
				  	alert('Nama Pemesan Harap Diisi');
				  }else if(df['no_pemesanan'].value==''){
				  	alert ('No Pemesanan Harap Diisi');
				  }else if(df['item'].value=='00000000000000000000'){
				  	alert ('Item Tolong Diisi');
				  }else if(df['jumlah'].value==''){
				  	alert ('Jumlahnya Berapa ???');
				  }else if(df['harga_jual'].value==''){
				  	alert ('Harga Berapa ???');
				  }else{
	makePOSTRequest('post.php', poststr);
	}
}
function get_del(df, val) {  
if (confirm('Apakah anda ingin menghapus data ?')) {
	var poststr = "del=1"+  
				  "&pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan=" + encodeURI(df['tgl_pemesanan'].value)+
				  "&tgl_kirim=" + encodeURI(df['tgl_kirim'].value)+ 
				  "&item=" + encodeURI(df['item'].value)+ 
				  "&jumlah=" + encodeURI(df['jumlah'].value)+
				  "&id_so=" + encodeURI(df['id_so'+val].value)+
				  "&kode_so_int=" + encodeURI(df['kode_so_int'].value);
	makePOSTRequest('post.php', poststr);
}else {
		return false;
 	}
}

function get_nol_cdt(obj, df) {  
	df['no_pemesanan'].value = '';
}
/*function get_ganti_ppn(){
	var x=document.getElementById("myform"); 
	//alert(x.elements['ppn'].value);
	if(x.elements['ppn'].value=='FP'){
		x.elements['value_ppn'].value ='10';
	}else{
		x.elements['value_ppn'].value ='0';
	}
}*/
function get_nol_jumlah(obj, df) {  
	df['jumlah'].value = '';
}
function get_nol_harga(obj, df) {  
	df['harga_jual'].value = '';
}
/////////////MEMBEDAKAN HURUF DAN ANGKA START/////////////////
function getkey(e)
{
if (window.event)
   return window.event.keyCode;
else if (e)
   return e.which;
else
   return null;
}
function goodchars(e, goods, field)
{
var key, keychar;
key = getkey(e);
if (key == null) return true;
 
keychar = String.fromCharCode(key);
keychar = keychar.toLowerCase();
goods = goods.toLowerCase();
 
// check goodkeys
if (goods.indexOf(keychar) != -1)
    return true;
// control keys
if ( key==null || key==0 || key==8 || key==9 || key==27 )
   return true;
    
if (key == 13) {
    var i;
    for (i = 0; i < field.form.elements.length; i++)
        if (field == field.form.elements[i])
            break;
    i = (i + 1) % field.form.elements.length;
    field.form.elements[i].focus();
    return false;
    };
// else return false
return false;
}
/////////////MEMBEDAKAN HURUF DAN ANGKA END/////////////////
</script>
<script type="text/javascript" src="../include/registrasi.js"></script>
<script type="text/javascript" src="../include/registrasi2.js"></script>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
<form action="javascript:get(document.getElementById('myform'));" name="myform" id="myform">
<div align="left" style="font-size:11px; color:#FF0000;">SALES || ORDER || ADD</div>
<table width="100%" border="1" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
<tr class="medium">
	<td width="12%"  ><div align="left">PEMESAN
	  <input name="pemesanh" type="hidden" style="width: 100%; background-color:#FFFFCC;" id="singleBirdRemote1" onClick="javascript:get_nol_pemesan(this.parentNode, this.form);showCustomer(this.value)" />
	</div></td>
    <td width="29%" ><div align="left">
      <select name="pemesan" style="width: 100%; background-color:#CCFF99;" >
	  	<option value="00000000000000000000" selected="selected">--- Isi Nama Pemesan ---</option>
	  	<?php
			$sql_sup=mysql_query("SELECT tbl_buyer.id_buyer, tbl_buyer.nama_buyer FROM tbl_buyer ORDER BY tbl_buyer.nama_buyer ASC");
			while($sup = mysql_fetch_assoc($sql_sup)){
		?>
		<option value="<?php echo $sup[id_buyer];?>"><?php echo $sup[nama_buyer];?></option>
		<?php
			}
		?>
	  </select>
    </div></td>
	<td width="12%" height="18" ><div align="left">TANGGAL<span class="style1">.</span>PESAN </div></td>
	<td width="20%" ><div align="left">
	  <input type="text" style="width: 98%; background-color:#CCFF99;" name="tgl_pemesanan" onClick="displayCalendar(document.forms[0].tgl_pemesanan,'dd/mm/yyyy',this)" value="<?php echo $tgl_inihari; ?>" readonly>
	</div></td>
	<td width="6%" height="18" >ID/DUE DAY</td>
	<td width="21%"><input name="kode_so_int" id="kode_so_int" type="text" style="width: 80%; background-color:#CCFF99;" readonly/>
    <input name="due_day" type="text" value="14" style="width: 15%; background-color:#FFFFCC;" onKeyPress="return goodchars(event,'0123456789',this)" title="Biarkan Kosong Jika Due Day Default" /></td>
</tr>
<tr class="medium">
	<td height="18" ><div align="left">NO.SO<span class="style1">.</span>/<span class="style1">.</span>CDT</div></td>
    <td><div align="left"><input name="no_pemesanan" id="no_pemesanan" type="text" style="width: 100%; background-color:#FFFFCC;" onClick="javascript:get_nol_cdt(this.parentNode, this.form);showCustomer(this.value)" onKeyUp="check_so(this.value,'registrasi_cek.php','hslcek1')"/></div></td>
	<td width="12%" height="18" ><div align="left">TANGGAL<span class="style1">.</span>KIRIM</div></td>
	<td><div align="left">
	<input name="tgl_kirim" type="text" style="width: 98%; background-color:#CCFF99;" onClick="displayCalendar(document.forms[0].tgl_kirim,'dd/mm/yyyy',this)" value="<?php echo $tgl_inihari; ?>" readonly/></div></td>
	<td width="6%" height="18" >VALUE/SALES</td>
	<td><select name="ppn" id="ppn" style="width: 40%; background-color:#CCFF99;" title="NON TAX jika Non PPN, 0 jika FP 0%, 10 Jika FP 10%">
	  	 <option value="NP" selected="selected">NON TAX</option>
         <option value="FP0" >0%</option>
         <option value="FP1" >10%</option>
	  </select><select name="sales" id="sales" style="width: 50%; background-color:#CCFF99;" title="Pilih Nama Sales">
	  	 <option value="MK.M004" selected="selected">MUKTI WIBOWO</option>
		 <?php 
		 $qry_sales=mysql_query("select kode_marketing, nama_marketing from tbl_marketing where kode_marketing <> 'MK.M004' order by nama_marketing ASC");
		 while($rs_sales=mysql_fetch_assoc($qry_sales)){
		 ?>
         <option value="<?php echo $rs_sales[kode_marketing];?>" ><?php echo $rs_sales[nama_marketing];?></option>
         <?php
		 }
		 ?>
         
	  </select>&nbsp;<input type="hidden" name="kode_kita" id="kode_kita" style="width: 42%; background-color:#CCFF99;" value="O396"></td>
</tr>
<tr class="medium">
	<td height="18" ><div align="left">ITEM
	  <input type="hidden" style="width: 100%; background-color:#FFFFCC;" name="itemh" id="singleBirdRemote2" onClick="javascript:get_nol_item(this.parentNode, this.form);showCustomer(this.value)">
	</div></td>
    <td><div align="left"><select name="item" style="width: 100%; background-color:#CCFF99;" >
	<option value="00000000000000000000" selected="selected">--- Isi Item ---</option>
	  	<?php
			$sql_item=mysql_query("SELECT tbl_produk.kode_produk, tbl_produk.nama_produk FROM tbl_produk ORDER BY tbl_produk.nama_produk ASC");
			while($item = mysql_fetch_assoc($sql_item)){
		?>
		<option value="<?php echo $item[kode_produk];?>"><?php echo strtoupper($item[nama_produk]);?></option>
		<?php
			}
		?>
	  </select></div></td>
    <td width="12%" height="18" ><div align="left">JUMLAH / HARGA</div></td>
	<td><input name="jumlah" type="text" style="width: 25%; background-color:#FFFFCC;" onClick="javascript:get_nol_jumlah(this.parentNode, this.form);showCustomer(this.value)" onKeyPress="return goodchars(event,'0123456789.',this)"/>&nbsp;&nbsp;/&nbsp;&nbsp;<input name="harga_jual" type="text" style="width: 65%; background-color:#FFFFCC;" onClick="javascript:get_nol_harga(this.parentNode, this.form);showCustomer(this.value)" onKeyPress="return goodchars(event,'0123456789.',this)"/></td>
	<td ><div align="center">
    <input type="button" value="BOOKING" style="width: 100%;" onClick="check_ppn(ppn.value,'registrasi_ppn.php','hslcek2')" >
	</div></td>
      <td ><div align="left">
        <select name="order_type" id="order_type" style="width: 60%; background-color:#CCFF99;">
	  	 <option value="1" selected="selected">RE ORDER</option>
         <option value="0" >NEW OUTLET</option>
         
	  </select>
	  </div></td>
	</tr>
<tr class="medium">
	<td colspan="6" ><div align="center">
	  <input type="hidden" name="input_time" value="<?php echo $lengkap;?>">
	  <input type="hidden" name="input_account" value="<?php echo $session_user;?>">
	  <input class="inputbutton" type="hidden" name="button2" value="POST" onClick="javascript:get(this.parentNode, this.form);showCustomer(this.value)" />
      </div></td>
	</tr>
<tr class="medium">
	<td colspan="6" id="hslcek1"><div align="center"></div></td>
	</tr>
</table>
</form>
<form name="myform1" id="myform1"  method="post" >
<span name="myspan" id="myspan">
</form>
<script language=Javascript>
function Inint_AJAX() {
   try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
   try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
   try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
   alert("XMLHttpRequest not supported");
   return null;
};
</script>
</body>
</html>
