<?php
include('../include/conn.php');
include('../include/tanggal.php');

$sql_data="SELECT
tbl_buyer.id_buyer,
tbl_buyer.nama_buyer,
tbl_buyer.due_day,
tbl_so.kode_so_int,
tbl_so.kode_so
FROM
tbl_buyer
Inner Join tbl_so ON tbl_so.id_buyer_FK = tbl_buyer.id_buyer
";
echo $sql_data;
$qry_data = mysql_query($sql_data);
while($data = mysql_fetch_assoc($qry_data)){
	$sql_update="UPDATE `db_knm`.`tbl_so` SET `due_day`='$data[due_day]' WHERE  `kode_so_int`='$data[kode_so_int]';";
	mysql_query($sql_update);
	echo $sql_update."<br>";
}

?>
  
