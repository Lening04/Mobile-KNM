<?php
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";
$session_user=$_SESSION['user_name'];
function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma1($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 1, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 1, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
$kode_so_int=trim($_POST[kode_so_int]);

$tgl_pemesanan = $_POST[tgl_pemesanan];
list($day, $month, $year) = split('[/.-]', $tgl_pemesanan);
$tgl_pemesanan = $year."-".$month."-".$day;

$tgl_kirim = $_POST[tgl_kirim];
list($day, $month, $year) = split('[/.-]', $tgl_kirim);
$tgl_kirim = $year."-".$month."-".$day;

// MENCARI id_satuan_FK
$sql_digt=mysql_query("select 
kode_produk,kode_produk_buyer,
nama_produk,nama_faktur_pajak,
nama_lain, id_sbu_FK,ppn,id_satuan_FK 
from tbl_produk 
where kode_produk = '$_POST[item]'");
$digit=mysql_fetch_assoc($sql_digt);
//mencari id_buyer_grup_FK
$sql_buyer_grup_FK=mysql_query("select id_buyer_grup_FK from tbl_buyer where id_buyer = '$_POST[pemesan]'");
$buyer_grup_FK=mysql_fetch_assoc($sql_buyer_grup_FK);
//mencari id_company_FK
$sql_company_FK=mysql_query("select id_company_FK from tbl_buyer_grup where id_buyer_grup = '$buyer_grup_FK[id_buyer_grup_FK]'");
$company_FK=mysql_fetch_assoc($sql_company_FK);

//mencari harga terakhir
$sql_hrg=mysql_query("select harga_jual 
from tbl_harga 
where id_buyer_grup_FK = '$buyer_grup_FK[id_buyer_grup_FK]' 
and aktif = 'YES' 
and kode_produk_FK ='$_POST[item]'");
$hrg=mysql_fetch_assoc($sql_hrg);

if($_POST[input]=='1'){
	$input="INSERT INTO `tbl_so` (
	`kode_so_int`, `kode_so`, `tanggal_so`, `tanggal_kirim`, `id_satuan_FK`, 
	`mc`, `harga_jual`, `jumlah`, `kode_produk_FK`, 
	`id_buyer_FK`, `posting_so_si`, `id_company_FK`, `val_ppn`, `input_account`, `input_time`
	) VALUES (
	'$_POST[kode_so_int]', '$_POST[no_pemesanan]', '$tgl_pemesanan', '$tgl_kirim', '$digit[id_satuan_FK]', 
	'', '$_POST[harga]', '$_POST[jumlah]', '$_POST[item]',
	'$_POST[pemesan]', '', '$company_FK[id_company_FK]', '$_POST[value_ppn]', '$session_user', '$lengkap');";
	mysql_query($input);
	//echo $input."<br>";
}
if($_POST[del]=='1'){
	$dele="DELETE FROM `tbl_so` WHERE `id_so`='$_POST[id_so]'";
	mysql_query($dele);
	//echo $dele."<br>";
}
if($_POST[status]=='1'){
	$ganti_buyer="UPDATE `db_knm`.`tbl_so` SET `id_buyer_FK`='$_POST[pemesan]' WHERE  `kode_so_int`='$_POST[kode_so_int]';";
	mysql_query($ganti_buyer);
}
if($_POST[status]=='2'){
	$ganti_buyer="UPDATE `db_knm`.`tbl_so` SET `tanggal_kirim`='$tgl_kirim' WHERE  `kode_so_int`='$_POST[kode_so_int]';";
	mysql_query($ganti_buyer);
}
if($_POST[status]=='3'){
	$ganti_buyer="UPDATE `db_knm`.`tbl_so` SET `tanggal_so`='$tgl_pemesanan' WHERE  `kode_so_int`='$_POST[kode_so_int]';";
	mysql_query($ganti_buyer);
}
if($_POST[status]=='4'){
	$ganti_buyer="UPDATE `db_knm`.`tbl_so` SET `val_ppn`='$_POST[value_ppn]' WHERE  `kode_so_int`='$_POST[kode_so_int]';";
	mysql_query($ganti_buyer);
}
if($_POST[status]=='5'){
	$ganti_buyer="UPDATE `db_knm`.`tbl_so` SET `kode_so`='$_POST[no_pemesanan]' WHERE  `kode_so_int`='$_POST[kode_so_int]';";
	mysql_query($ganti_buyer);
}
if($_POST[ganti_jumlah]=='1'){
	$ganti_jumlah="UPDATE `db_knm`.`tbl_so` SET `jumlah`='$_POST[jumlah]' WHERE  `id_so`='$_POST[id_so]';";
	mysql_query($ganti_jumlah);
	//echo $ganti_jumlah;
}
if($_POST[ganti_harga]=='1'){
	$ganti_harga="UPDATE `db_knm`.`tbl_so` SET `harga_jual`='$_POST[harga]' WHERE  `id_so`='$_POST[id_so]';";
	mysql_query($ganti_harga);
	//echo $ganti_jumlah;
}

?>
<link href="../include/styles00.css" rel="stylesheet" type="text/css">
<title>BC.4.0 FG</title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<table width="100%" cellspacing="0" class="sort-table" id="table-1">
<thead>
  <tr >
    <td width="48" class="dr2"><div align="center">No</div></td>
    <td width="144" class="dr2"><div align="center">Barcode</div></td>
    <td width="652" class="dr2"><div align="center">Nama Barang</div></td>
	<td width="84" class="dr2"><div align="center">Satuan</div></td>
	<td width="124" class="dr2"><div align="center">Jumlah</div></td>
    <td width="125" class="dr2"><div align="center">Harga/Satuan</div></td>
	<td width="125" class="dr2"><div align="center">Total</div></td>
    <td width="38" class="dr2"><div align="center">Del</div></td>
  </tr>
</thead>
<tbody>
<?php
	$sql_data="SELECT
	tbl_so.id_so,
	tbl_so.kode_so_int,
	tbl_so.kode_so,
	tbl_so.id_satuan_FK,
	tbl_so.harga_jual,
	tbl_so.jumlah,
	tbl_so.kode_produk_FK,
	tbl_so.id_buyer_FK,
	tbl_produk.kode_produk_buyer,
	tbl_produk.nama_produk,
	tbl_satuan.nama_satuan
	FROM
	tbl_so
	INNER JOIN tbl_produk ON tbl_produk.kode_produk = tbl_so.kode_produk_FK
	INNER JOIN tbl_satuan ON tbl_satuan.id_satuan = tbl_so.id_satuan_FK
	WHERE
	tbl_so.kode_so_int = '$kode_so_int'";
	//echo $sql_data;
	$qry_data = mysql_query($sql_data);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#9DC5E6";
		}else{
	   		$warna ="#BCDADA";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#FFFFB0'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  ><div align="center"><?php echo $i; ?></div></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "  width="144" ><div align="left"><?php echo $data[kode_produk_buyer];?>
	  <input name="id_so<?php echo $i;?>" type="hidden" value="<?php echo $data[id_so];?>" />
	</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  ><?php echo $data[nama_produk];?></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo $data[nama_satuan];?></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><input name="jumlah<?php echo $i;?>" type="text" style="width: 100%; background-color:#FFFFCC;" value="<?php echo $data[jumlah]; $total_jumlah+=$data[jumlah];?>" onChange="get_ganti_jumlah(this.form, <?php echo $i;?>);" /></div></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><input name="harga<?php echo $i;?>" type="text" style="width: 100%; background-color:#FFFFCC;" value="<?php echo $data[harga_jual];?>" onChange="get_ganti_harga(this.form, <?php echo $i;?>);"/></div>	</td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php $total_harga=$data[harga_jual]*$data[jumlah]; 
	echo comma0($total_harga); $sumharga+=$total_harga;?></div>	</td>
    <td width="38"  style="color: windowtext; border-right: .5pt solid windowtext; ">
	  <div align="center"><input type="checkbox" name="del" onclick="get_del(this.form, <?php echo $i;?>);" /></div>
	</a></td>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; " colspan="4"><div align="center">
    <input type="hidden" name="pemesan" value="<?php echo $_POST[pemesan];?>" />
    <input type="hidden" name="no_pemesanan" value="<?php echo $_POST[no_pemesanan];?>" />
    <input type="hidden" name="tgl_pemesanan" value="<?php echo $_POST[tgl_pemesanan];?>" />
    <input type="hidden" name="tgl_kirim" value="<?php echo $_POST[tgl_kirim];?>" />
    <input type="hidden" name="item" value="<?php echo $_POST[item];?>" />
    <input type="hidden" name="jumlah" value="<?php echo $_POST[jumlah];?>" />
	<input type="hidden" name="value_ppn" value="<?php echo $_POST[value_ppn];?>" />
	<input type="hidden" name="kode_so_int" value="<?php echo $_POST[kode_so_int];?>" /></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma1($total_jumlah);?></strong></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sumharga);?></strong></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;</td>
   </tr>
   </tbody>
</table>
<script type="text/javascript">
//<![CDATA[
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
//]]>
</script>
