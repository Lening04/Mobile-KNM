<?php
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('login.php', '_parent');</script>";
}
$levelku=$_SESSION['user_level'];
//echo $levelku;
include('include/conn.php');
include('include/tanggal.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<link href='images/knmlogo.png' rel='shortcut icon' type='image/x-icon'/>
<title>:: KNM ::</title>


    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">


    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body>

<div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
			 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index_log.php" ><?php echo " ".ucwords(strtoupper($_SESSION["user_name"]));?></a>
				
            </div>

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="so/index.php" ><i class="fa fa-files-o fa-fw"></i> Sales Order </a>
                        </li>
						 <li>
                            <a href="r_so/index.php" ><i class="fa fa-files-o fa-fw"></i> Status Order</a>
                        </li>
						 <li>
                            <a href="omz2/index.php" ><i class="fa fa-files-o fa-fw"></i> Rencana dan Realisasi Pengiriman</a>
                        </li>
						 <li>
                            <a href="logout.php" ><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
	
	
	<div >

<?php
	$session_user=$_SESSION['user_name'];
	//echo $session_user."<br>";
	$session_level=$_SESSION['user_level'];
	//echo $session_level."<br>";
	$session_warehouse=$_SESSION['warehouse']; 	
	//echo $session_warehouse."<br>";
	//MENCARI SO YANG SUDAH DI APPROVE
	$sql_f=mysql_query("SELECT
	tbl_so.kode_so_int,
	tbl_so.kode_so,
	tbl_so.tanggal_so,
	tbl_so.tanggal_kirim,
	tbl_so.id_buyer_FK,
	tbl_so_aprove.id_so_aprove
	FROM
	tbl_so
	Inner Join tbl_so_aprove ON tbl_so_aprove.kode_so_int_FK = tbl_so.kode_so_int
	where tbl_so_aprove.aprove_account = 'FA'
	group by tbl_so.kode_so_int
	");
	
	$sql_m=mysql_query("SELECT
	tbl_so.kode_so_int,
	tbl_so.kode_so,
	tbl_so.tanggal_so,
	tbl_so.tanggal_kirim,
	tbl_so.id_buyer_FK,
	tbl_so_aprove.id_so_aprove
	FROM
	tbl_so
	Inner Join tbl_so_aprove ON tbl_so_aprove.kode_so_int_FK = tbl_so.kode_so_int
	where tbl_so_aprove.aprove_account = 'MKT'
	group by tbl_so.kode_so_int
	");
	//menentukan username login start
	if($session_level=='FA'){
		$sql=$sql_f;
		while($rs=mysql_fetch_assoc($sql_f)){
			$kode_cari="AND kode_so_int <> '".$rs[kode_so_int]."'";
			//echo $kode_cari."<br>";
		}
		
	}else if($session_level=='MKT'){
		$sql=$sql_m;
		while($rs=mysql_fetch_assoc($sql_m)){
			$kode_cari="AND kode_so_int <> '".$rs[kode_so_int]."'";
		}
	}
	//menentukan username login end
	$sql_alert_1="select id_so,kode_so_int from tbl_so where kode_so_int <> '' ";
	$sql_alert=$sql_alert_1." ".$kode_cari;
	//echo $sql_alert;
	$qry_alert=mysql_query($sql_alert);
?></div>

<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
		<h2 class="page-header">Sales Inventory System Kelola Niaga Makmur (KNM)</h2>
		</div>
	</div>
</div>
</div>
 <script src="bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>
</body>


</html>

