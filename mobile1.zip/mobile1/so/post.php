<?php
session_start();
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
$tgl_pemesanan1 = $_POST[tgl_pemesanan1];
list($day, $month, $year) = split('[/.-]', $tgl_pemesanan1);
$tgl_pemesanan1 = $year."-".$month."-".$day;

$tgl_pemesanan2 = $_POST[tgl_pemesanan2];
list($day, $month, $year) = split('[/.-]', $tgl_pemesanan2);
$tgl_pemesanan2 = $year."-".$month."-".$day;

$tgl_kirim1 = $_POST[tgl_kirim1];
list($day, $month, $year) = split('[/.-]', $tgl_kirim1);
$tgl_kirim1 = $year."-".$month."-".$day;

$tgl_kirim2 = $_POST[tgl_kirim2];
list($day, $month, $year) = split('[/.-]', $tgl_kirim2);
$tgl_kirim2 = $year."-".$month."-".$day;

				  
if($_POST[del]=='1'){
	$dele="DELETE FROM `db_knm`.`tbl_so` WHERE  `kode_so_int`='$_POST[id]';";
	//echo $dele;
	mysql_query($dele);
	$gmt=date("Z");
	$session_time=date("U");
	$session_id=session_id();
	$ipaddress=$_SERVER['REMOTE_ADDR'];
	$ip= $REMOTE_ADDR;
	$host_name = GetHostByName($ip);
	$aktivitas="DELETE SO ".$_POST[id];
	$menu="SALES";
	$session_user=$_SESSION['user_name'];
	$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
	$url = $_SERVER['REQUEST_URI'];
	mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");
}
///////////////////////////////////
$batasan = 30;  
 	if(isset($_POST["batas"])){   
  		$batas = $_POST["batas"];  
 	}  
 	else if(isset($_GET["batas"])){   
  		$batas = $_GET["batas"];   
 	}else{  
		$batas = $batasan;   
 	}  
 	if(isset($_POST["halaman"])){   
  		$halaman = $_POST["halaman"];  
 	}else{ 
		$halaman = $_GET["halaman"]; 
	}  
	if(empty($halaman)){  
  		$posisi = 0;  
  		$halaman = 1;  
 	}else{  
		$posisi = intval(($halaman-1) * $batas);  
 	}  
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<style type="text/css">
<!--
.style1 {color: #F0F0F0}
-->
</style>
<input type="hidden" name="halaman" value="<?php echo $halaman;?>" />  
<?php  
 	if(empty($batas)){
		$batas = intval($batasan);  
	}else{
		$batas=intval($batas);
	}
?>  
<head>

<!-- Bootstrap Core CSS -->

    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


<link href="../admin/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
</head>
<form class="form-inline" action="" method="POST">
<div class="panel-body">
<div class="table-responsive">
<table class="table table-bordered table-hover table-striped" id="dataTable-example">
<thead>
  <tr >
    <th width="38" rowspan="2">NO</th>
    <th rowspan="2">KODE SO<span class="style1"> </span>INTERNAL</th>
	<th rowspan="2">NO.<span class="style1">.</span>SO<span class="style1">.</span>/<span class="style1">.</span>CDT </th>
    <th rowspan="2">PEMESAN</th>
    <th rowspan="2">NILAI</th>
	<th colspan="2">TANGGAL</th>
    <th rowspan="2">APPROVAL</th>
    <th rowspan="2">EDIT</th>
    <th rowspan="2">DEL</th>
  </tr>
  <tr >
    <th width="79" >PESAN</th>
    <th width="77" >KIRIM</th>
	</tr>
  </thead>
<tbody>
<?php

if($_POST[pemesan]<>'00000000000000000000'){
	$pemesan="AND tbl_so.id_buyer_FK = '$_POST[pemesan]'";
}
if(!empty($_POST[no_pemesanan])){
	$no_pemesanan="AND tbl_so.kode_so like '%$_POST[no_pemesanan]%'";
}
$limit="LIMIT $posisi,$batas";
$groupby="group by tbl_so.kode_so_int";
$sql_data="SELECT
tbl_so.kode_so_int,
tbl_so.kode_so,
tbl_so.id_satuan_FK,
sum(tbl_so.harga_jual*tbl_so.jumlah) as sumharga,
tbl_so.kode_produk_FK,
tbl_so.id_buyer_FK,
tbl_produk.kode_produk_buyer,
tbl_produk.nama_produk,
tbl_satuan.nama_satuan,
tbl_buyer.nama_buyer,
tbl_so.tanggal_so,
tbl_so.tanggal_kirim
FROM
tbl_so
INNER JOIN tbl_produk ON tbl_produk.kode_produk = tbl_so.kode_produk_FK
INNER JOIN tbl_satuan ON tbl_satuan.id_satuan = tbl_so.id_satuan_FK
INNER JOIN tbl_buyer ON tbl_buyer.id_buyer = tbl_so.id_buyer_FK
WHERE tbl_so.tanggal_so between '$tgl_pemesanan1' and '$tgl_pemesanan2'
AND tbl_so.tanggal_kirim between '$tgl_kirim1' and '$tgl_kirim2'
";
	$sql_data1=$sql_data." ".$pemesan." ".$no_pemesanan." ".$groupby." ".$limit;
	//echo $sql_data1;
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$sql_count_edit=mysql_query("select count(kode_so_int_FK) from tbl_so_aprove where kode_so_int_FK = '$data[kode_so_int]'");
		//echo "select count(kode_so_int_FK) from tbl_so_aprove where kode_so_int_FK = '$data[kode_so_int]'"."<br>";
		$rs_count_edit=mysql_fetch_row($sql_count_edit);
		//echo $rs_count_edit[0]."<br>";
		
		
		$i++;
		$x=$batasan*($halaman-1)+$i;
		if($x=='0'){
			$z=$i;
		}else{
			$z=$x;
		}
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#E8FFFF";
		}else{
	   		$warna ="#B0D8FF";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#CCFF99'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <th style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "  class="dr1"><div align="center"><?php echo $x; ?></div></th>
    <th width="235"  class="dr1" style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-bottom: medium none; "><div align="left"><?php echo $data[kode_so_int];?></div></th>
<th width="229"  class="dr1" style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "><div align="left"><?php echo $data[kode_so];?>
<input name="id<?php echo $i;?>" type="hidden" value="<?php echo $data[kode_so_int];?>" /></div></th>
	<th style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "  width="216" class="dr1"><div align="left"><?php echo $data[nama_buyer];?></div></th>
    <th style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "  width="185" class="dr1"><div align="right"><?php echo comma0($data[sumharga]);?></div></th>
    <th style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "  width="79" class="dr1"><div align="center"><?php echo tampil_tgl($data[tanggal_so]);?></div></th>
    <th style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "  width="77" class="dr1"><div align="center"><?php echo tampil_tgl($data[tanggal_kirim]);?></div></th>
	<th class="dr1" style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "><div align="center"><img src="../images/check.ico" width="16" onclick="javascript:MM_openBrWindow1('../input_so/apr.php?id=<?PHP echo $data[kode_so_int];?>')" /></div></th>
	<th width="34"  class="dr1" style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "><div align="center">
	<?php
		if($rs_count_edit[0]=='0'){
			echo "<img src=../images/edit.ico border=0 width=16 onclick=javascript:MM_openBrWindow1('../input_so/ed.php?id=$data[kode_so_int]') title=EDIT PURCHASE ORDER [ $data[kode_so]]/>";
		}else{
			echo "";
		}
	?>
	</div></th>
    <th width="34"  class="dr1" style="color: windowtext; border-left: medium none; border-right: .5pt solid windowtext; border-top: medium none; border-bottom: medium none; "><div align="center">
	<?php
		if($rs_count_edit[0]=='0'){
			echo "<input type=checkbox name=del onclick='get_del(this.form, $i)'/>";
		}else{
			echo "";
		}
	?>
	</div></th>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<th colspan="10">
    <input type="hidden" name="pemesan" value="<?php echo $_POST[pemesan];?>" />
    <input type="hidden" name="no_pemesanan" value="<?php echo $_POST[no_pemesanan];?>" />
    <input type="hidden" name="tgl_pemesanan1" value="<?php echo $_POST[tgl_pemesanan1];?>" />
    <input type="hidden" name="tgl_pemesanan2" value="<?php echo $_POST[tgl_pemesanan2];?>" />
    <input type="hidden" name="tgl_kirim1" value="<?php echo $_POST[tgl_kirim1];?>" />
    <input type="hidden" name="tgl_kirim2" value="<?php echo $_POST[tgl_kirim2];?>" /></th>
   </tr>
   </tbody>
</table>
</div>
</div>
<?php
	echo"<div align=\"center\">"; 
	$sql_tampil2="SELECT
tbl_so.id_so,
tbl_so.tanggal_kirim
FROM
tbl_so
INNER JOIN tbl_produk ON tbl_produk.kode_produk = tbl_so.kode_produk_FK
INNER JOIN tbl_satuan ON tbl_satuan.id_satuan = tbl_so.id_satuan_FK
INNER JOIN tbl_buyer ON tbl_buyer.id_buyer = tbl_so.id_buyer_FK
WHERE tbl_so.tanggal_so between '$tgl_pemesanan1' and '$tgl_pemesanan2'
AND tbl_so.tanggal_kirim between '$tgl_kirim1' and '$tgl_kirim2'
";
	$sql_data1=$sql_tampil2." ".$pemesan." ".$no_pemesanan." ".$groupby;
	//echo "$sql_data1"."<br>";
	$tampil2 = mysql_query($sql_data1);  
	$jmldata = mysql_num_rows($tampil2);  
	$jmlhalaman = ceil($jmldata/$batas);  
	if($halaman > 1){  
		$previous=$halaman-1;  
?>  
	<input type="button" value="<<" onClick="javascript:get_first(this.parentNode, this.form, <?php echo "1";?>);">&nbsp;|&nbsp;
	<input type="button" value="<" onClick="javascript:get_prev(this.parentNode, this.form, <?php echo $previous;?>);">&nbsp;|&nbsp;
<?php  
 	}else{
?>
		<input type="button" value="<<" >&nbsp;|&nbsp;
		<input type="button" value="<" >&nbsp;|&nbsp;
<?php
	}  
 	$angka=($halaman > 3 ? " ... " : " ");  
 	for($i=$halaman-2;$i<$halaman;$i++){  
  	if($i < 1)  
   		continue;  
  		//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";
		$angka .=$i;
 	}  
 	$angka .= " <b>$halaman</b> ";  
 	for($i=$halaman+1;$i<($halaman+3);$i++){  
  		if($i > $jmlhalaman)  
   			break;  
			//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";  
			$angka .=$i;  
 		}  
		$angka .=($halaman+2<$jmlhalaman ?"...$jmlhalaman ":""); 
		//$angka .= ($halaman+2<$jmlhalaman ? " ... <a href=?halaman=$jmlhalaman&batas=$batas class=linka>$jmlhalaman</a> " : " ");  
 		echo"$angka";  
 		if($halaman < $jmlhalaman){  
  			$next=$halaman+1;
			?>
  			|&nbsp;<input type="button" value=">" onClick="javascript:get_next(this.parentNode, this.form, <?php echo $next;?>);">&nbsp;|&nbsp;
			<input type="button" value=">>" onClick="javascript:get_last(this.parentNode, this.form, <?php echo $jmlhalaman;?>);">
			<?php
 		}else{ ?>
 			<input type="button" value=">">&nbsp;|&nbsp;<input type="button" value=">>" >
		<?php
 		}  
 		echo"Total : <b>$jmldata</b>";   
?>
</form>

<script type="text/javascript">
//<![CDATA[
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
//]]>
</script>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
</html>