<?php
include('../include/conn.php');
include('../include/tanggal.php');
?>
<style type="text/css">
<!--
.style1 {color: #F0F0F0}
-->
</style>

<link href="../admin/styles00.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<table width="100%" cellspacing="0" >

<?php
	$kode_buyer="CL.H0027";	
	echo $kode_buyer."<br>";
	$sql_data="select id_so, kode_marketing, id_buyer_FK from tbl_so where id_buyer_FK = '$kode_buyer' order by id_so ASC";
	//echo $sql_data."<br>";
	$qry_data = mysql_query($sql_data);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		
?>

  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#CCFF99'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    
	<td width="1186" style="color: windowtext; border-right: .5pt solid windowtext;" ><div align="left">
    <?php
		$update="UPDATE `db_knm`.`tbl_so` SET `kode_marketing`='MK.S003' WHERE  `id_so`='$data[id_so]';";
		echo $update."<br>";
    	mysql_query($update);
	?></div></td>
  </tr>
<?php
}
?>
</table>
