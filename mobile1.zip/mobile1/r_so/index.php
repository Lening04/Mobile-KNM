<?php 
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
$levelku=$_SESSION['user_level'];
include('../include/conn.php');
include('../include/tanggal.php');
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$aktivitas="REPORT SALES";
$menu="SALES";
$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
$url = $_SERVER['REQUEST_URI'];
mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");

function tampil_tgl($tgl){
  		list($year, $month ,$day ) = split('[/.-]', $tgl);
		$tgl_view=$day."/".$month."/".$year;
  		return $tgl_view;
	}
$awal_bulan="01/".substr($tgl_inihari,3);
?>
<!DOCTYPE html>
<html lang="en">
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="../images/detail1.ico" rel='shortcut icon' type='image/x-icon'/>
<title>STATUS SALES ORDER</title>

<!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<script type="text/javascript" language="javascript">
  function MM_openBrWindow1(theURL,winName,features) { //v2.0
  		var width  = 900;
		var height = 400;
		window.open(theURL,winName,'toolbar=no,menubar=no,resizable=no,scrollbars=yes,status=no,location=no,width='+width+',height='+height);
	}
</script>
<link type="text/css" href="../admin/styles00.css" rel="stylesheet" />
<link type="text/css" rel="stylesheet" href="../include/dhtmlgoodies_calendar.css?random=20051112" media="screen"></LINK>
<SCRIPT type="text/javascript" src="../include/dhtmlgoodies_calendar.js?random=20060118"></script>
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<script type="text/javascript" language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<!-------------data  autocomplet--->
<script type="text/javascript">
	$().ready(function() {
	
		function findValueCallback(event, data, formatted) {
			$("<li>").html( !data ? "No match!" : "Selected: " + formatted).appendTo("#result");
		}
		function formatItem(row) {
			return row[0] + " (<strong>id: " + row[1] + "</strong>)";
		}

		function formatResult(row) {
			return row[0].replace(/(<.+?>)/gi, '');
		}
		
		$("#singleBirdRemote1").autocomplete("barcode.php", {
		width: 221,
		selectFirst: false
		});
		$("#singleBirdRemote1").result(function(event, data, formatted) {
			if (data)
				$(this).parent().next().find("input").val(data[1]);
		});
		$("#singleBirdRemote2").autocomplete("produk.php", {
		width: 400,
		selectFirst: false
		});
		$("#singleBirdRemote2").result(function(event, data, formatted) {
			if (data)
				$(this).parent().next().find("input").val(data[1]);
		});
	});
	function changeOptions(){
		var max = parseInt(window.prompt('Please type number of items to display:', jQuery.Autocompleter.defaults.max));
		if (max > 0) {
			$("#suggest1").setOptions({
				max: max
			});
		}
	}
	function changeScrollHeight() {
		var h = parseInt(window.prompt('Please type new scroll height (number in pixels):', jQuery.Autocompleter.defaults.scrollHeight));
		if(h > 0) {
			$("#suggest1").setOptions({
				scrollHeight: h
			});
		}
	}
	function changeToMonths(){
		$("#suggest1")
			// clear existing data
			.val("")
			// change the local data to months
			.setOptions({data: months})
			// get the label tag
			.prev()
			// update the label tag
			.text("Month (local):");
	}
	var http_request = false;
   function makePOSTRequest(url, parameters) {
      http_request = false;
      if (window.XMLHttpRequest) { // Mozilla, Safari,...
         http_request = new XMLHttpRequest();
         if (http_request.overrideMimeType) {
            http_request.overrideMimeType('text/html');
         }
      } else if (window.ActiveXObject) { // IE
         try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
         } catch (e) {
            try {
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
         }
      }
      if (!http_request) {
         alert('Cannot create XMLHTTP instance');
         return false;
      }
      http_request.onreadystatechange = alertContents;
      http_request.open('POST', url, true);
      http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      http_request.setRequestHeader("Content-length", parameters.length);
      http_request.setRequestHeader("Connection", "close");
      http_request.send(parameters);
   }
   function alertContents() {
      if (http_request.readyState == 4) {
         if (http_request.status == 200) {
            result = http_request.responseText;
            document.getElementById('myspan').innerHTML = result;            
         } else {
            alert('There was a problem with the request.');
         }
      }
   }


function get_exc(obj, df) { 
	var poststr = "?pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan1=" + encodeURI(df['tgl_pemesanan1'].value)+
				  "&tgl_pemesanan2=" + encodeURI(df['tgl_pemesanan2'].value)+
				  "&tgl_kirim2=" + encodeURI(df['tgl_kirim2'].value)+
				  "&tgl_kirim1=" + encodeURI(df['tgl_kirim1'].value);
	window.location='ecx.php'+poststr;  
}
function get_view(obj, df) { 
	var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan1=" + encodeURI(df['tgl_pemesanan1'].value)+
				  "&tgl_pemesanan2=" + encodeURI(df['tgl_pemesanan2'].value)+
				  "&tgl_kirim2=" + encodeURI(df['tgl_kirim2'].value)+
				  "&tgl_kirim1=" + encodeURI(df['tgl_kirim1'].value);
	makePOSTRequest('post.php', poststr);
}
function get_load(){
	var x=document.getElementById("myform"); 
	var poststr = "pemesan=" + encodeURI(x.elements['pemesan'].value)+
		"&no_pemesanan=" + encodeURI(x.elements['no_pemesanan'].value)+
		"&tgl_pemesanan1=" + encodeURI(x.elements['tgl_pemesanan1'].value)+
		"&tgl_pemesanan2=" + encodeURI(x.elements['tgl_pemesanan2'].value)+
		"&tgl_kirim2=" + encodeURI(x.elements['tgl_kirim2'].value)+
		"&tgl_kirim1=" + encodeURI(x.elements['tgl_kirim1'].value);
	makePOSTRequest('post.php', poststr); 
}
function get_del(df, val) { 
if (confirm('Apakah anda ingin menghapus data ?')) {
		//return true; 
	var poststr = "del=1"+  //alert('tes');
				  "&pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&id=" + encodeURI(df['id'+val].value)+
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan1=" + encodeURI(df['tgl_pemesanan1'].value)+
				  "&tgl_pemesanan2=" + encodeURI(df['tgl_pemesanan2'].value)+
				  "&tgl_kirim2=" + encodeURI(df['tgl_kirim2'].value)+
				  "&tgl_kirim1=" + encodeURI(df['tgl_kirim1'].value);				  
	makePOSTRequest('post.php', poststr);
}else {
		return false;
 	}
}
function get_next(obj, df, hal) { 
      var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan1=" + encodeURI(df['tgl_pemesanan1'].value)+
				  "&tgl_pemesanan2=" + encodeURI(df['tgl_pemesanan2'].value)+
				  "&tgl_kirim2=" + encodeURI(df['tgl_kirim2'].value)+
				  "&tgl_kirim1=" + encodeURI(df['tgl_kirim1'].value)+
				  "&halaman="+ encodeURI(hal);
      makePOSTRequest('post.php', poststr);
   }
   function get_last(obj, df, hal) {
      var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan1=" + encodeURI(df['tgl_pemesanan1'].value)+
				  "&tgl_pemesanan2=" + encodeURI(df['tgl_pemesanan2'].value)+
				  "&tgl_kirim2=" + encodeURI(df['tgl_kirim2'].value)+
				  "&tgl_kirim1=" + encodeURI(df['tgl_kirim1'].value)+
				  "&halaman="+ encodeURI(hal);
      makePOSTRequest('post.php', poststr);
   }
   function get_first(obj, df, hal) {
      var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan1=" + encodeURI(df['tgl_pemesanan1'].value)+
				  "&tgl_pemesanan2=" + encodeURI(df['tgl_pemesanan2'].value)+
				  "&tgl_kirim2=" + encodeURI(df['tgl_kirim2'].value)+
				  "&tgl_kirim1=" + encodeURI(df['tgl_kirim1'].value)+
				  "&halaman="+ encodeURI(hal);
      makePOSTRequest('post.php', poststr);
   }
   function get_prev(obj, df, hal) {
      var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_pemesanan=" + encodeURI(df['no_pemesanan'].value)+
				  "&tgl_pemesanan1=" + encodeURI(df['tgl_pemesanan1'].value)+
				  "&tgl_pemesanan2=" + encodeURI(df['tgl_pemesanan2'].value)+
				  "&tgl_kirim2=" + encodeURI(df['tgl_kirim2'].value)+
				  "&tgl_kirim1=" + encodeURI(df['tgl_kirim1'].value)+
				  "&halaman="+ encodeURI(hal);
      makePOSTRequest('post.php', poststr);
   }
</script>
<style type="text/css">
<!--
.style1 {font-weight: bold}
-->
</style>
</head>
<body>
<div id="wrapper">
 <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
			 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index_log.php" ><?php echo " ".ucwords(strtoupper($_SESSION["user_name"]));?></a>
				
            </div>

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="../so/index.php" ><i class="fa fa-files-o fa-fw"></i> Sales Order </a>
                        </li>
						 <li>
                            <a href="index.php" ><i class="fa fa-files-o fa-fw"></i> Status Order</a>
                        </li>
						 <li>
                            <a href="../omz2/index.php" ><i class="fa fa-files-o fa-fw"></i> Rencana dan Realisasi Pengiriman</a>
                        </li>
						 <li>
                            <a href="../logout.php" ><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
<div id="page-wrapper">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
                           STATUS SALES || ORDER
         </div>
<form action="javascript:get(document.getElementById('myform'));" name="myform" id="myform">

<div class="panel-body">
<div class="table-responsive">
<table class="table table-bordered table-hover table-striped" id="dataTables-example">
<thead>
<tr>
<tr>
<th>
<div align="center">PEMESAN</div>
</th>
<th>
<div align="center">NO. SO / CDT</div>
</th>
</tr>

<tr>
<th width="33%" height="18" ><select name="pemesan" style="width: 100%; background-color:#CCFF99;" onChange="javascript:get_view(this.parentNode, this.form);showCustomer(this.value)">
	  	<option value="00000000000000000000" selected="selected">--- ALL ---</option>
	  	<?php
			$sql_sup=mysql_query("SELECT tbl_buyer.id_buyer, tbl_buyer.nama_buyer FROM tbl_buyer ORDER BY tbl_buyer.nama_buyer ASC");
			while($sup = mysql_fetch_assoc($sql_sup)){
		?>
		<option value="<?php echo $sup[id_buyer];?>"><?php echo $sup[nama_buyer];?></option>
		<?php
			}
		?>
	  </select></th>
 <th width="27%"><input name="no_pemesanan" type="text" style="width: 100%; background-color:#FFFFCC;" onChange="javascript:get_view(this.parentNode, this.form);showCustomer(this.value)"/></th>
</tr>
</tr>
</thead>

<thead>
<tr>
<th colspan="2"><strong><div align="center"> TANGGAL PEMESANAN</div>
    </strong></th>
</tr>

<tr>
  <th><input type="text" style="width: 100%; background-color:#CCFF99;" name="tgl_pemesanan1" onClick="displayCalendar(document.forms[0].tgl_pemesanan1,'dd/mm/yyyy',this)" onChange="javascript:get_view(this.parentNode, this.form);showCustomer(this.value)" value="<?php echo $awal_bulan; ?>" readonly></th>
    <th><input type="text" style="width: 100%; background-color:#CCFF99;" name="tgl_pemesanan2" onClick="displayCalendar(document.forms[0].tgl_pemesanan2,'dd/mm/yyyy',this)" onChange="javascript:get_view(this.parentNode, this.form);showCustomer(this.value)" value="<?php echo $tgl_inihari; ?>" readonly></th>
</tr>

<tr>
 <th colspan="2"><strong>
      <div align="center">TANGGAL KIRIM
        <input  class="inputbutton" type="hidden" name="button" value="EXCEL" onClick="javascript:get_exc(this.parentNode, this.form);showCustomer(this.value)" title="CONVERT TO .XLS" />
        <input  class="inputbutton" type="hidden" name="button2" value="VIEW" onClick="javascript:get_view(this.parentNode, this.form);showCustomer(this.value)" />
      </div>
    </strong></th>
</tr>

<tr>

    <th><input name="tgl_kirim1" type="text" style="width: 100%; background-color:#CCFF99;" onClick="displayCalendar(document.forms[0].tgl_kirim1,'dd/mm/yyyy',this)" onChange="javascript:get_view(this.parentNode, this.form);showCustomer(this.value)" value="<?php echo $awal_bulan; ?>" readonly/></th>
    <th>
      <input name="tgl_kirim2" type="text" style="width: 100%; background-color:#CCFF99;" onClick="displayCalendar(document.forms[0].tgl_kirim2,'dd/mm/yyyy',this)" onChange="javascript:get_view(this.parentNode, this.form);showCustomer(this.value)" value="<?php echo $tgl_inihari; ?>" readonly/></th>
</tr>
</thead>
  
  </table>
  </div>
  </div>
</form>
<form name="myform1" id="myform1"  method="post" >
<span name="myspan" id="myspan">
</form>
<script language=Javascript>
function Inint_AJAX() {
   try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
   try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
   try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
   alert("XMLHttpRequest not supported");
   return null;
};
window.onLoad=get_load();
</script>
</div>
</div>
</div>
</div>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>
</html>
