<?php
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
$tgl_pemesanan1 = $_POST[tgl_pemesanan1];
list($day, $month, $year) = split('[/.-]', $tgl_pemesanan1);
$tgl_pemesanan1 = $year."-".$month."-".$day;

$tgl_pemesanan2 = $_POST[tgl_pemesanan2];
list($day, $month, $year) = split('[/.-]', $tgl_pemesanan2);
$tgl_pemesanan2 = $year."-".$month."-".$day;

$tgl_kirim1 = $_POST[tgl_kirim1];
list($day, $month, $year) = split('[/.-]', $tgl_kirim1);
$tgl_kirim1 = $year."-".$month."-".$day;

$tgl_kirim2 = $_POST[tgl_kirim2];
list($day, $month, $year) = split('[/.-]', $tgl_kirim2);
$tgl_kirim2 = $year."-".$month."-".$day;

///////////////////////////////////
$batasan = 30;  
 	if(isset($_POST["batas"])){   
  		$batas = $_POST["batas"];  
 	}  
 	else if(isset($_GET["batas"])){   
  		$batas = $_GET["batas"];   
 	}else{  
		$batas = $batasan;   
 	}  
 	if(isset($_POST["halaman"])){   
  		$halaman = $_POST["halaman"];  
 	}else{ 
		$halaman = $_GET["halaman"]; 
	}  
	if(empty($halaman)){  
  		$posisi = 0;  
  		$halaman = 1;  
 	}else{  
		$posisi = intval(($halaman-1) * $batas);  
 	}  
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<style type="text/css">
<!--
.style1 {color: #F0F0F0}
-->
</style>

<!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
<?php /*<input type="hidden" name="halaman" value="<?php echo $halaman;?>" />  
?><?php  
 	if(empty($batas)){
		$batas = intval($batasan);  
	}else{
		$batas=intval($batas);
	}
?>  <?php */?>
<link href="../admin/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<form class="form-inline" action="" method="POST">
<div class="panel-body">
<div class="table-responsive">
<table class="table table-bordered table-hover table-striped" id="dataTable-example">
<thead>
  <tr >
    <th width="43" rowspan="2" ><div align="center">NO</div></th>
	<th rowspan="2" >NO.<span class="style1">.</span>SO<span class="style1">.</span>/<span class="style1">.</span>CDT</th>
    <th rowspan="2" >PEMESAN</th>
    <th rowspan="2" >PRODUK</th>
	<th colspan="2" >JUMLAH ITEM </th>
	<th colspan="2" >TANGGAL</th>
    <th rowspan="2" >STATUS</th>
  </tr>
  <tr >
    <th width="31" >SO</th>
    <th width="84" >TERKIRIM</th>
	<th width="60" >PESAN</th>
    <th width="56" >KIRIM</th>
	</tr>
  </thead>
<tbody>
<?php

if($_POST[pemesan]<>'00000000000000000000'){
	$pemesan="AND tbl_so.id_buyer_FK = '$_POST[pemesan]'";
}
if(!empty($_POST[no_pemesanan])){
	$no_pemesanan="AND tbl_so.kode_so like '%$_POST[no_pemesanan]%'";
}
$limit="LIMIT $posisi,$batas";
$groupby="ORDER BY tbl_so.kode_so_int ASC";
$sql_data="SELECT
tbl_so.kode_so_int,
tbl_so.kode_so,
tbl_so.id_satuan_FK,
tbl_so.harga_jual,
tbl_so.jumlah,
tbl_so.kode_produk_FK,
tbl_so.id_buyer_FK,
tbl_produk.kode_produk_buyer,
tbl_produk.nama_produk,
tbl_satuan.nama_satuan,
tbl_buyer.nama_buyer,
tbl_so.tanggal_so,
tbl_so.tanggal_kirim
FROM
tbl_so
INNER JOIN tbl_produk ON tbl_produk.kode_produk = tbl_so.kode_produk_FK
INNER JOIN tbl_satuan ON tbl_satuan.id_satuan = tbl_so.id_satuan_FK
INNER JOIN tbl_buyer ON tbl_buyer.id_buyer = tbl_so.id_buyer_FK
WHERE tbl_so.tanggal_so between '$tgl_pemesanan1' and '$tgl_pemesanan2'
AND tbl_so.tanggal_kirim between '$tgl_kirim1' and '$tgl_kirim2'
";
	$sql_data1=$sql_data." ".$pemesan." ".$no_pemesanan." ".$groupby." ".$limit;
	//echo $sql_data1."<br>";
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$sql_count_edit=mysql_query("select count(kode_so_int_FK) from tbl_so_aprove where kode_so_int_FK = '$data[kode_so_int]'");
		$rs_count_edit=mysql_fetch_row($sql_count_edit);
		
		$sql_count=mysql_query("select count(kode_so_int) from tbl_so where kode_so_int = '$data[kode_so_int]'");
		$rs_count=mysql_fetch_row($sql_count);
		$count=$rs_count[0];
		//echo $count."<br>";
		
		$sql_terkirim=mysql_query("select kode_produk_FK, qty from tbl_si where kode_so_int_FK = '$data[kode_so_int]' and kode_produk_FK = '$data[kode_produk_FK]'");
		$sum_terkirim=mysql_fetch_row($sql_terkirim);
		
		$i++;/*
		$x=$batasan*($halaman-1)+$i;
		if($x=='0'){
			$z=$i;
		}else{
			$z=$x;
		}*/
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#E8FFFF";
		}else{
	   		$warna ="#B0D8FF";
		}
?>
<?php
      if($data_stop!= $data[kode_so_int] && !empty($data_stop)){
   ?>
   <tr >
   	<th colspan="4" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; border-left: .5pt solid windowtext;"><div align="right"><strong>Subtotal&nbsp;&nbsp;&nbsp;&nbsp;</strong></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext;"><div align="right"><strong><?php echo comma0($sum_jiso[$data_stop]);?></strong></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext;"><div align="right"><strong><?php echo comma0($sum_jit[$data_stop]);?></strong></div></th>
    <th colspan="3" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext;"><div align="center"></div></th>
    </tr>
   <?php 
   }
   ?>

  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#CCFF99'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <th style="color: windowtext; border-right: .5pt solid windowtext; border-left: .5pt solid windowtext; "  ><div align="center"><?php echo $i; ?></div></th>
<th width="102"   style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[kode_so];?>
<input name="id<?php echo $i;?>" type="hidden" value="<?php echo $data[kode_so_int];?>" /></div></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext;" width="215" ><div align="left"><?php echo $data[nama_buyer];?></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext;" width="398" ><div align="left"><?php echo $data[nama_produk];?></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext;" width="31" ><div align="right"><?php echo comma0($data[jumlah]); $jiso+=$data[jumlah]; $sum_jiso[$data[kode_so_int]]+=$data[jumlah];?></div></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext;" width="84" ><div align="right"><?php echo comma0($sum_terkirim[1]);$jit+=$sum_terkirim[1]; $sum_jit[$data[kode_so_int]]+=$sum_terkirim[1];?></div></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext;" width="60" ><div align="center"><?php echo tampil_tgl($data[tanggal_so]);?></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext;" width="56" ><div align="center"><?php echo tampil_tgl($data[tanggal_kirim]);?></div></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext;"><div align="center"><?php $selisih=$data[jumlah]-$sum_terkirim[1];  //echo $selisih."<br>";
	if($selisih <> '0'){
		echo "OUT STANDING";
	}else{
		echo "FINISH";
	}?></div></th>
  </tr>
    <?php
   $data_stop = $data[kode_so_int];
   }
  ?>
   <?php
      if($data_stop!= $data[kode_so_int] && !empty($data_stop)){
   ?>
   <tr >
   	<th colspan="4" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext;"><div align="right"><strong>Subtotal&nbsp;&nbsp;&nbsp;&nbsp;</strong></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sum_jiso[$data_stop]);?></strong></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sum_jit[$data_stop]);?></strong></div></th>
    <th colspan="3" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"></div></th>
    </tr>
   <?php 
   }
   ?>
   <tr >
   	<th colspan="4" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext;border-bottom: .5pt solid windowtext;"><div align="right"><?php /*?>
    <input type="hidden" name="pemesan" value="<?php echo $_POST[pemesan];?>" />
    <input type="hidden" name="no_pemesanan" value="<?php echo $_POST[no_pemesanan];?>" />
    <input type="hidden" name="tgl_pemesanan1" value="<?php echo $_POST[tgl_pemesanan1];?>" />
    <input type="hidden" name="tgl_pemesanan2" value="<?php echo $_POST[tgl_pemesanan2];?>" />
    <input type="hidden" name="tgl_kirim1" value="<?php echo $_POST[tgl_kirim1];?>" />
    <input type="hidden" name="tgl_kirim2" value="<?php echo $_POST[tgl_kirim2];?>" /><?php */?>&nbsp;<strong>Grand Total&nbsp;&nbsp;&nbsp;&nbsp;</strong></div></th>
	<th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom:.5pt solid windowtext; "><div align="right"><strong><?php echo comma0($jiso); ?></strong></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom:.5pt solid windowtext; "><div align="right"><strong><?php echo comma0($jit);?></strong></div></th>
    <th colspan="3" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom:.5pt solid windowtext;"><div align="right"></div></th>
   </tr>
   </tbody>
</table>
</div>
</div>
<?php /*?><?php
///////////paging///////////////////////
	echo"<div align=\"center\">"; 
	$sql_tampil2="SELECT
tbl_so.id_so,
tbl_so.tanggal_kirim
FROM
tbl_so
INNER JOIN tbl_produk ON tbl_produk.kode_produk = tbl_so.kode_produk_FK
INNER JOIN tbl_satuan ON tbl_satuan.id_satuan = tbl_so.id_satuan_FK
INNER JOIN tbl_buyer ON tbl_buyer.id_buyer = tbl_so.id_buyer_FK
WHERE tbl_so.tanggal_so between '$tgl_pemesanan1' and '$tgl_pemesanan2'
AND tbl_so.tanggal_kirim between '$tgl_kirim1' and '$tgl_kirim2'
";
	$sql_data1=$sql_tampil2." ".$pemesan." ".$no_pemesanan." ".$groupby;
	//echo "$sql_data1"."<br>";
	$tampil2 = mysql_query($sql_data1);  
	$jmldata = mysql_num_rows($tampil2);  
	$jmlhalaman = ceil($jmldata/$batas);  
	if($halaman > 1){  
		$previous=$halaman-1;  
?>  
	<input type="button" value="<<" onClick="javascript:get_first(this.parentNode, this.form, <?php echo "1";?>);">&nbsp;|&nbsp;
	<input type="button" value="<" onClick="javascript:get_prev(this.parentNode, this.form, <?php echo $previous;?>);">&nbsp;|&nbsp;
<?php  
 	}else{
?>
		<input type="button" value="<<" >&nbsp;|&nbsp;
		<input type="button" value="<" >&nbsp;|&nbsp;
<?php
	}  
 	$angka=($halaman > 3 ? " ... " : " ");  
 	for($i=$halaman-2;$i<$halaman;$i++){  
  	if($i < 1)  
   		continue;  
  		//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";
		$angka .=$i;
 	}  
 	$angka .= " <b>$halaman</b> ";  
 	for($i=$halaman+1;$i<($halaman+3);$i++){  
  		if($i > $jmlhalaman)  
   			break;  
			//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";  
			$angka .=$i;  
 		}  
		$angka .=($halaman+2<$jmlhalaman ?"...$jmlhalaman ":""); 
		//$angka .= ($halaman+2<$jmlhalaman ? " ... <a href=?halaman=$jmlhalaman&batas=$batas class=linka>$jmlhalaman</a> " : " ");  
 		echo"$angka";  
 		if($halaman < $jmlhalaman){  
  			$next=$halaman+1;
			?>
  			|&nbsp;<input type="button" value=">" onClick="javascript:get_next(this.parentNode, this.form, <?php echo $next;?>);">&nbsp;|&nbsp;
			<input type="button" value=">>" onClick="javascript:get_last(this.parentNode, this.form, <?php echo $jmlhalaman;?>);">
			<?php
 		}else{ ?>
 			<input type="button" value=">">&nbsp;|&nbsp;<input type="button" value=">>" >
		<?php
 		}  
 		echo"Total : <b>$jmldata</b>";   
?><?php */?>
</form>

<script type="text/javascript">
//<![CDATA[
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
//]]>
</script>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
</html>