<?php
include('include/conn.php');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
   

    <title>Signin :: KNM ::</title>
	
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
<link href="cover.css" rel="stylesheet">
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
 <link href="examples/signin/signin.css" rel="stylesheet">
 <script src="assets/js/ie-emulation-modes-warning.js"></script>
 <script type="text/javascript" language="javascript">

	function get_login() {
	var x=document.getElementById("myform1");
		if(x.elements['username'].value=="admin" && x.elements['password'].value=="admin"){
			window.location = 'index_log.php';
		}else{
			alert("password salah");
		}
	}

</script>
<script type="text/javascript" src="jquery.tools.min.js"></script>
<script>flashembed("circle", "circle.swf");</script>
<div id="circle"></div>
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF
}
.style3 {color: #FFFFFF; font-weight: bold; }
-->
</style>
  </head>

  <body style="vertical-align:bottom" onLoad="document.myform1.username.focus()" >
<div align="center" >
<link href="images/knmlogo.png" rel='shortcut icon' type='image/x-icon'/>
<div id="form_login">
    <div class="container" >

      <form class="form-signin" action="cek_login.php" name="myform1" id="myform1" method="post">
		 <script type="text/javascript" src="swfobject.js"></script>
 
<script type="text/javascript">
swfobject.embedSWF("images/circle.swf", "flashcontent", "700", "400", "9");
</script>
<style media="screen" type="text/css">
#flashcontent {visibility: hidden}
</style>
 </head>
 
<body>
<object 
        data="images/logo_knm.jpg" 
        height="197" 
        width="238">
</object>

	  <h2 class="form-signin-heading">Login Form</h2>
        <label for="username" class="sr-only">Username</label>
        <input type="text" name="username" class="form-control" placeholder="username" required autofocus>
        <label for="password" class="sr-only">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password" required>
		<select class="form-control">
		<option value="00" class="style1">-- Pilih Warehouse --</option>
		 <?php
			$sql_warh=mysql_query("select id_gudang, nama_gudang from tbl_gudang order by nama_gudang asc");
			while($rs_warh=mysql_fetch_assoc($sql_warh)){
			?>
            <option value="<?php echo $rs_warh[id_gudang];?>"><?php echo $rs_warh[nama_gudang];?></option>
            <?php
			}
			?>
		</select>
	<label></label>
        <button class="btn btn-lg btn-primary btn-block" name="Masuk" value="Masuk" onclick="submit">Sign in</button>
      </form>

    </div> <!-- /container -->
</div> 
</div> 

    
  </body>
</html>
