<?php
session_start();
include('include/conn.php');
include('include/tanggal.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="include/styles00.css">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>content</title>
 <link href="dist/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
<!--
.style4 {font-weight: bold}
-->
</style>
</head>
<body>
<div >

<?php
	$session_user=$_SESSION['user_name'];
	//echo $session_user."<br>";
	$session_level=$_SESSION['user_level'];
	//echo $session_level."<br>";
	$session_warehouse=$_SESSION['warehouse']; 	
	//echo $session_warehouse."<br>";
	//MENCARI SO YANG SUDAH DI APPROVE
	$sql_f=mysql_query("SELECT
	tbl_so.kode_so_int,
	tbl_so.kode_so,
	tbl_so.tanggal_so,
	tbl_so.tanggal_kirim,
	tbl_so.id_buyer_FK,
	tbl_so_aprove.id_so_aprove
	FROM
	tbl_so
	Inner Join tbl_so_aprove ON tbl_so_aprove.kode_so_int_FK = tbl_so.kode_so_int
	where tbl_so_aprove.aprove_account = 'FA'
	group by tbl_so.kode_so_int
	");
	
	$sql_m=mysql_query("SELECT
	tbl_so.kode_so_int,
	tbl_so.kode_so,
	tbl_so.tanggal_so,
	tbl_so.tanggal_kirim,
	tbl_so.id_buyer_FK,
	tbl_so_aprove.id_so_aprove
	FROM
	tbl_so
	Inner Join tbl_so_aprove ON tbl_so_aprove.kode_so_int_FK = tbl_so.kode_so_int
	where tbl_so_aprove.aprove_account = 'MKT'
	group by tbl_so.kode_so_int
	");
	//menentukan username login start
	if($session_level=='FA'){
		$sql=$sql_f;
		while($rs=mysql_fetch_assoc($sql_f)){
			$kode_cari="AND kode_so_int <> '".$rs[kode_so_int]."'";
			//echo $kode_cari."<br>";
		}
		
	}else if($session_level=='MKT'){
		$sql=$sql_m;
		while($rs=mysql_fetch_assoc($sql_m)){
			$kode_cari="AND kode_so_int <> '".$rs[kode_so_int]."'";
		}
	}
	//menentukan username login end
	$sql_alert_1="select id_so,kode_so_int from tbl_so where kode_so_int <> '' ";
	$sql_alert=$sql_alert_1." ".$kode_cari;
	//echo $sql_alert;
	$qry_alert=mysql_query($sql_alert);
?></div>
<script src="dist/jquery.min.js"></script>
<script src="dist/js/bootstrap.min.js"></script>
</body>
</html>