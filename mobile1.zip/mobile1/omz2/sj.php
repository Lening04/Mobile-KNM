<?php
session_start();
include('admin/conn.php');
include('admin/tanggal.php');

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}

$nota = $_REQUEST[sj];
?>
<html>
<head>
  
  <title>NOTA TIMBANG I</title>
  
<SCRIPT LANGUAGE="JavaScript">

<!-- Begin
function Check(chk)
{
if(document.myform.Check_ctr.checked==true){
for (i = 0; i < chk.length; i++)
chk[i].checked = true ;
}else{

for (i = 0; i < chk.length; i++)
chk[i].checked = false ;
}
}

// End -->
</script>
<link type="text/css" rel="StyleSheet" href="css/sortabletable.css" />
<style type="text/css">

body {
	font-family:	Verdana, Helvetica, Arial, Sans-Serif;
	font:			Message-Box;
}

code {
	font-size:	1em;
}


</style>
  <script type="text/javascript" src="themplete/datepickercontrol.js"></script>
  <script language="JavaScript">
     if (navigator.platform.toString().toLowerCase().indexOf("linux") != -1){
	 	document.write('<link type="text/css" rel="stylesheet" href="themplete/datepickercontrol_lnx.css">');
	 }
	 else{
	 	document.write('<link type="text/css" rel="stylesheet" href="themplete/datepickercontrol.css">');
	 }
  </script>  
<script src="selectuser.js"></script>
<link href="../bpsd.css" rel="stylesheet" type="text/css">	
<script type="text/javascript">
function add_commas(nStr)
{
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}


</script>
<style type="text/css">
<!--
.style1 {font-family: Arial, Helvetica, sans-serif}
.style3 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; }
.style12 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; }
.style13 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style26 {font-family: Arial, Helvetica, sans-serif; font-size: small; }
.style28 {text-decoration:underline; font-family:Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold;}
-->
</style>
</head>
<body id="theme1">

  <span class="style3 style1">
  <input type="hidden" id="DPC_TODAY_TEXT" value="today">
  <input type="hidden" id="DPC_BUTTON_TITLE" value="Open calendar...">
  <input type="hidden" id="DPC_MONTH_NAMES" value="['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']">
  <input type="hidden" id="DPC_DAY_NAMES" value="['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']">
  </span>
		<table width="789" height="114" border="1"  cellpadding="0" cellspacing="0" bordercolor="#000000" style=" border-collapse:collapse">
          <tr>
            <td width="18%" rowspan="4" bgcolor="#FFFFFF" valign="middle"><div align="center"><img src="kml.jpg" alt="e" width="107" height="67" align="middle" /></div>	</td>
			<?php
  			  $sql_master="select a.no_nota, a.kode_supplier, b.nama, b.grup_wilayah_ikan,c.nama, a.tgl_pembelian, c.id_grup_suplier_ikan_FK, d.nama, a.total, a.adm, a.ket_sup from tbl_pembelian_rm a, tbl_suplier_ikan b, tbl_grup_wilayah c, tbl_grup_suplier_ikan d where a.no_nota = '$nota' and a.kode_supplier = b.kode_rm and b.grup_wilayah_ikan = c.kode and c.id_grup_suplier_ikan_FK = d.id_grup";
			  //echo $sql_master."<br>";
              $qry_master = mysql_query($sql_master);
              $hsl_master = mysql_fetch_row($qry_master);	  
			  ?>
            <td width="48%" rowspan="4" bgcolor="#FFFFFF">
			<div align="center"><strong>NOTA TIMBANG I</strong></div>
			<div align="center" class="style26">Nomor Nota : <?php echo ucwords(strtolower($hsl_master[0]))?></div>			</td>
            <td width="15%" height="20" bgcolor="#FFFFFF"><span class="style13">Doc. No</span></td>
            <td width="19%" bgcolor="#FFFFFF"><span class="style13">&nbsp;FF/FG/III-04.01.01</span></td>
          </tr>
          <tr>
            <td height="20" bgcolor="#FFFFFF"><span class="style13">Rev. / Issued</span></td>
            <td bgcolor="#FFFFFF"><span class="style13">&nbsp;1 / 1</span></td>
          </tr>
          <tr>
            <td height="16" bgcolor="#FFFFFF"><span class="style13">Date</span></td>
            <td bgcolor="#FFFFFF"><span class="style13">&nbsp;01-07-12</span></td>
          </tr>
          <tr>
            <td height="16" bgcolor="#FFFFFF"><span class="style13">Page</span></td>
			<td height="16" bgcolor="#FFFFFF"><span class="style13">&nbsp;1 dari 1 </span></td>
          </tr>
		  <tr>
		<td height="20" colspan="2" align="left" valign="middle"><div align="left" class="style13">&nbsp;&nbsp;ISO 22000:2005 pasal 7.4; 8.3.3</div></td>
		<td height="20" colspan="2" align="left" valign="middle"><div align="left" class="style13">BRC - Pasal 3.5 </div></td>
	</tr>
</table>
<table width="789" border="1"  cellpadding="0" cellspacing="0" bordercolor="#000000" style=" border-collapse:collapse">
<tr>
            <td width="440" height="20" bgcolor="#FFFFFF"><span class="style12">&nbsp;Suplier&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</span>
			  <span class="style13">
	        &nbsp;<?php echo ucwords(strtolower($hsl_master[2]))?>&nbsp;&nbsp;<?php echo ucwords(strtolower($hsl_master[10]))?></span></td>
    <td width="344" height="20" bgcolor="#FFFFFF"><span class="style12">&nbsp;Tanggal</span><span class="style13">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>:</strong>&nbsp;&nbsp;<?php echo tampil_tgl($hsl_master[5])?></span></td>
  </tr>
		   <tr>
            <td height="20" bgcolor="#FFFFFF"><span class="style12">&nbsp;Kode&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</span><span class="style13">&nbsp;&nbsp;<?php echo ucwords(strtolower($hsl_master[1]))?></span></td>
            <!--<td height="26" bgcolor="#FFFFFF"><div id="txtHint"></div></td>-->
            <td height="20" bgcolor="#FFFFFF"><span class="style12">&nbsp;Area Tangkap </span><span class="style13">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>:</strong>&nbsp;&nbsp;<?php echo ucwords(strtolower($hsl_master[4]))?></span></td>
			</tr>
  </table>       
<table width="789" height="71" border="1"  cellpadding="0" cellspacing="0" bordercolor="#000000" style=" border-collapse:collapse">
  
  <tr>
    
    <td width="172" height="17" align="left" valign="middle" bgcolor="#999999"><div align="center" class="style13">Jenis Ikan</div></td>
	<td width="136" align="left" valign="middle" bgcolor="#999999"><div align="center" class="style13">Size</div></td>
    <td colspan="2" align="left" valign="middle" bgcolor="#999999"><div align="center" class="style13"><b>Berat</b> (Kg) </div></td>
    <td width="188" align="left" valign="middle" bgcolor="#999999"><div align="center" class="style13"><b>Jumlah</b> (Kg)</div></td>
  </tr>

  	<?php 
	
	$query = "SELECT a.id, a.no_nota, a.kode_ikan, b.jenis, c.ukuran, a.jumlah, a.harga, a.total, a.desk, a.telly FROM tbl_pembelian_rm_det a, tbl_fish b, tbl_size_rm c WHERE a.no_nota='$nota' and a.kode_ikan = b.id_fish and c.id_size_rm = a.size order by a.id"; 
    //echo $query;
	$hasil = mysql_query($query); 
	$tot=0;
	while($data = mysql_fetch_row($hasil)){  
		$sql_count="SELECT a.id, a.no_nota, a.kode_ikan, count(a.kode_ikan) FROM tbl_pembelian_rm_det a WHERE a.no_nota='$nota' and a.kode_ikan='$data[2]' group by kode_ikan ";
		$qry_count=mysql_query($sql_count);
		$count=mysql_fetch_row($qry_count);
	?>
    <tr onMouseover="this.style.backgroundColor='#D8D8D8'" onMouseout="this.style.backgroundColor='#CCFF99'" BGCOLOR="#CCFF99">
	<?php
	if(empty($data_uakhir) || $data_uakhir != $data[2]){
	?>
	<td height="21" bgcolor="#FFFFFF" rowspan="<?php echo $count[3];?>"><span class="style13">&nbsp;<?php echo ucwords(strtolower($data[3]));?></span></td>
	<?php
			}
		?>
	<td height="21" bgcolor="#FFFFFF"><span class="style13">&nbsp;<?php echo $data[4];?></span></td>
	<td height="21" colspan="2" align="right" bgcolor="#FFFFFF">
    <?php
		  $st=substr_count($data[9],"|");
		  $col=$st/10;
		  $cols=floor($col);
		  ?>
    <textarea style="font-family:Arial, Helvetica, sans-serif; font-size:10px; border:thin;" name="berat" cols="66" rows="
		  <?php 
		  if($cols=='0'){
		  echo "1";
		  }else{
		  echo $cols;
		  }
		  ?>" readonly><?php 
	if(empty($data[9])){
	echo '';
	}else{
	echo $data[9];
	}
	?></textarea></td>
    <td height="21" align="right" bgcolor="#FFFFFF"><span class="style13"><?php 
	if(empty($data[5])){
	echo '';
	}else{
	echo number_format($data[5], 2, ',', '.');}
	?></span>&nbsp;</td>
  </tr>
 
  <?php
  $data_uakhir = $data[2];
  }
  ?>
  
  <tr>
 	<td height="20" colspan="4" bgcolor="#FFFFFF">
	<div align="right" class="style12">Total&nbsp;</div></td>
	<td height="20" align="right" bgcolor="#FFFFFF"><span class="style12">
	<?php 
	$sql_jumlah="SELECT a.no_nota, a.jumlah, sum(jumlah) FROM tbl_pembelian_rm_det a WHERE a.no_nota='$nota' ";
	//echo $sql_jumlah;
	$qry_jumlah=mysql_query($sql_jumlah);
	$jumlah=mysql_fetch_row($qry_jumlah);
	echo number_format ($jumlah[2], 2, ',', '.'); 
	?></span>&nbsp;</td>
  </tr>
</table>
<table width="789" border="1"  cellpadding="0" cellspacing="0" bordercolor="#000000" style=" border-collapse:collapse">
  <tr bgcolor="#336699">
    <td width="202" rowspan="3" align="left" valign="top" bgcolor="#FFFFFF"><div class="style28">Catatan : </div></td>
    <td height="20" colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><div align="center" class="style12">Supplier</div></td>
    <td width="249" align="left" valign="middle" bgcolor="#FFFFFF"><div align="center" class="style12">Bagian Pembelian </div>      <div align="center" class="style12"></div></td>
    <td width="210" align="left" valign="middle" bgcolor="#FFFFFF"><div align="center" class="style12">Adm. Penerimaan </div></td>
  </tr>
  <tr>
    
    <td height="66" colspan="2" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    <td align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
	<td c align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
	

  <tr bgcolor="#336699">
    <td height="20" colspan="2" align="left" valign="middle" bgcolor="#FFFFFF"><div align="center" class="style12"><span class="style13"><?php echo ucwords(strtolower($hsl_master[2]))?></span></div></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><div align="center" class="style12">....................................</div>      <div align="center" class="style12"></div></td>
    <td align="left" valign="middle" bgcolor="#FFFFFF"><div align="center" class="style12"><span class="style13"><?php echo ucwords(strtolower($hsl_master[9]))?></span></div></td>
  </tr>
  <tr>
    <td height="20" colspan="5" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="6" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;</td>
	</tr>
</table>
  </td>
</body>
</html>