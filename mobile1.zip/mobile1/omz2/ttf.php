<?php 
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$aktivitas="EDIT TUKAR FAKTUR ".$_REQUEST[id];
$menu="REPORT SALES";
$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
//echo $session_user."<br>";
//echo $session_level."<br>";
//echo $session_warehouse."<br>";
$url = $_SERVER['REQUEST_URI'];
mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");
function tampil_tgl($tgl){
  		list($year, $month ,$day ) = split('[/.-]', $tgl);
		$tgl_view=$day."/".$month."/".$year;
  		return $tgl_view;
	}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EDIT</title>
<link type="text/css" href="../admin/styles00.css" rel="stylesheet" />
<link type="text/css" rel="stylesheet" href="../calender/dhtmlgoodies_calendar.css?random=20051112" media="screen"></LINK>
<link type="text/css" rel="stylesheet" href="../admin/jquery.autocomplete.css" />
<link type="text/css" rel="stylesheet" href="../admin/thickbox.css" />

<SCRIPT type="text/javascript" src="../calender/dhtmlgoodies_calendar.js?random=20060118"></script>
<script type="text/javascript" src="../admin/jquery.js"></script>
<script type="text/javascript" src="../admin/menu.js"></script>
<script type="text/javascript" src="../admin/sortabletable.js"></script>
<script type="text/javascript" src="../admin/numberksorttype.js"></script>
<script type="text/javascript" src="../admin/uscurrencysorttype.js"></script>
<script type="text/javascript" src="../admin/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="../admin/thickbox-compressed.js"></script>
<script type="text/javascript" src="../admin/jquery.autocomplete.js"></script>
<script type="text/javascript" src="../admin/localdata.js"></script>
<script type="text/javascript" src="../admin/selectjenis.js"></script>
<script type="text/javascript" language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<!-------------data  autocomplet--->
<script type="text/javascript">
	$().ready(function() {
	
		function findValueCallback(event, data, formatted) {
			$("<li>").html( !data ? "No match!" : "Selected: " + formatted).appendTo("#result");
		}
		function formatItem(row) {
			return row[0] + " (<strong>id: " + row[1] + "</strong>)";
		}

		function formatResult(row) {
			return row[0].replace(/(<.+?>)/gi, '');
		}
		$("#singleBirdRemote").autocomplete("cdt.php", {
		width: 221,
		selectFirst: false
		});
		$("#singleBirdRemote").result(function(event, data, formatted) {
			if (data)
				$(this).parent().next().find("input").val(data[1]);
		});
	});
	function changeOptions(){
		var max = parseInt(window.prompt('Please type number of items to display:', jQuery.Autocompleter.defaults.max));
		if (max > 0) {
			$("#suggest1").setOptions({
				max: max
			});
		}
	}
	function changeScrollHeight() {
		var h = parseInt(window.prompt('Please type new scroll height (number in pixels):', jQuery.Autocompleter.defaults.scrollHeight));
		if(h > 0) {
			$("#suggest1").setOptions({
				scrollHeight: h
			});
		}
	}
	function changeToMonths(){
		$("#suggest1")
			// clear existing data
			.val("")
			// change the local data to months
			.setOptions({data: months})
			// get the label tag
			.prev()
			// update the label tag
			.text("Month (local):");
	}
	var http_request = false;
   function makePOSTRequest(url, parameters) {
      http_request = false;
      if (window.XMLHttpRequest) { // Mozilla, Safari,...
         http_request = new XMLHttpRequest();
         if (http_request.overrideMimeType) {
            http_request.overrideMimeType('text/html');
         }
      } else if (window.ActiveXObject) { // IE
         try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
         } catch (e) {
            try {
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
         }
      }
      if (!http_request) {
         alert('Cannot create XMLHTTP instance');
         return false;
      }
      http_request.onreadystatechange = alertContents;
      http_request.open('POST', url, true);
      http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      http_request.setRequestHeader("Content-length", parameters.length);
      http_request.setRequestHeader("Connection", "close");
      http_request.send(parameters);
   }
   function alertContents() {
      if (http_request.readyState == 4) {
         if (http_request.status == 200) {
            result = http_request.responseText;
            document.getElementById('myspan').innerHTML = result;            
         } else {
            alert('There was a problem with the request.');
         }
      }
   }

function get_load(){
	var x=document.getElementById("myform"); 
	var poststr = "tgl_kirim=" + encodeURI(x.elements['tgl_kirim'].value);
	makePOSTRequest('ttf_post.php', poststr); 
}

function get_update(df, val) {
		var poststr = "update=1"+  
				  "&supir=" + encodeURI(df['supir'].value)+ 
				  "&jenis_kendaraan=" + encodeURI(df['jenis_kendaraan'].value)+ 
				  "&nopol=" + encodeURI(df['nopol'].value)+ 
				  "&tgl_kirim=" + encodeURI(df['tgl_kirim'].value);			  
		makePOSTRequest('ttf_post.php', poststr);
}

</script>
</head>
<body><form action="javascript:get(document.getElementById('myform'));" name="myform" id="myform">
<div align="left" style="font-size:11px; color:#FF0000;">REPORT SALES || TTF || TUKAR FAKTUR</div>
  <strong><?php echo tampil_tgl($_REQUEST[id]);?></strong>
  <input name="tgl_kirim" type="hidden" value="<?php echo tampil_tgl($_REQUEST[id]);?>"/>
  <table width="100%" border="1" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">

  </table>
</form>
<form name="myform1" id="myform1"  method="post" >
<span name="myspan" id="myspan">
</form>
<script language=Javascript>
function Inint_AJAX() {
   try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
   try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
   try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
   alert("XMLHttpRequest not supported");
   return null;
};
window.onLoad=get_load();
</script>
</body>
</html>
