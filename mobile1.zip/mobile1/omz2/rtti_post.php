<?php
include('../include/conn.php');
include('../include/tanggal.php');
print_r($_POST); echo "<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}

$tgl_kirim = $_POST[tgl_kirim];
list($day, $month, $year) = split('[/.-]', $tgl_kirim);
$tgl_kirim = $year."-".$month."-".$day;

$tgl_kirim1 = $_POST[tgl_kirim1];
list($day, $month, $year) = split('[/.-]', $tgl_kirim1);
$tgl_kirim1 = $year."-".$month."-".$day;

///////////////////////////////////
$batasan = 30;  
 	if(isset($_POST["batas"])){   
  		$batas = $_POST["batas"];  
 	}  
 	else if(isset($_GET["batas"])){   
  		$batas = $_GET["batas"];   
 	}else{  
		$batas = $batasan;   
 	}  
 	if(isset($_POST["halaman"])){   
  		$halaman = $_POST["halaman"];  
 	}else{ 
		$halaman = $_GET["halaman"]; 
	}  
	if(empty($halaman)){  
  		$posisi = 0;  
  		$halaman = 1;  
 	}else{  
		$posisi = intval(($halaman-1) * $batas);  
 	}  
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<style type="text/css">
<!--
.style1 {color: #F0F0F0}
-->
</style>

<input type="hidden" name="halaman" value="<?php echo $halaman;?>" />  
<?php  
 	if(empty($batas)){
		$batas = intval($batasan);  
	}else{
		$batas=intval($batas);
	}
?>  
<head>

<!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../admin/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
</head>
<form class="form-inline" action="" method="POST">
<div class="panel-body">
<div class="table-responsive">
<table class="table table-bordered table-hover table-striped" id="dataTable-example">
<thead>
  <tr >
    <th rowspan="2" ><div align="center">No</div></th>
	<th rowspan="2" ><div align="center">Tanggal</div></th>
    <th rowspan="2" ><div align="center">Supir</div></th>
    <th rowspan="2" ><div align="center">Jenis Kendaraan</div></th>
    <th rowspan="2" ><div align="center">NOPOL</div></th>
    <th rowspan="2" ><div align="center">Dikirim Dari</div></td>
    <th colspan="3" ><div align="center">Report</div></th>
     </tr>
  <tr >
    <th width="119" ><div align="center">Rencana</div></th>
    <th width="119" ><div align="center">Revisi</div></th>
    <th width="120" ><div align="center">Realisasi</div></th>
  </tr>
  </thead>
<tbody>
<?php
if(!empty($_POST[dikirim_dari])){
	$dikirim_dari="AND tbl_omzet.dikirim = '$_POST[dikirim_dari]'";
}else{
	$dikirim_dari='';
}

$order="ORDER BY tbl_omzet.tgl_tti DESC";
$grup="GROUP BY
tbl_omzet.supir,
tbl_omzet.jenis_kendaraan,
tbl_omzet.nopol,
tbl_omzet.dikirim";

$limit="LIMIT $posisi,$batas";
$sql_data="SELECT
tbl_omzet.id_tti,
tbl_omzet.tgl_tti,
tbl_omzet.kode_so_int_FK,
tbl_omzet.kode_so_FK,
tbl_omzet.jumlah,
tbl_omzet.id_buyer_FK,
tbl_omzet.nama_buyer,
tbl_omzet.supir,
tbl_omzet.jenis_kendaraan,
tbl_omzet.nopol,
tbl_omzet.dikirim,
tbl_omzet.kode_do_int
FROM
tbl_omzet
WHERE tbl_omzet.tgl_tti BETWEEN '$tgl_kirim' AND '$tgl_kirim1'
";
	//echo $sql_data;
	$sql_data1=$sql_data." ".$dikirim_dari." ".$grup." ".$order." ".$limit;
	//echo $sql_data1;
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		
		$sql_posting="select sum(posting) from tbl_omzet where tgl_tti = '$data[tgl_tti]' AND supir = '$data[supir]' AND nopol = '$data[nopol]';";
		//echo $sql_posting."<br>";
		$q_posting=mysql_query($sql_posting);
		$rs_posting=mysql_fetch_row($q_posting);
		
		$i++;
		$x=$batasan*($halaman-1)+$i;
		if($x=='0'){
			$z=$i;
		}else{
			$z=$x;
		}
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#E8FFFF";
		}else{
	   		$warna ="#B0D8FF";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#CCFF99'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <th style="color: windowtext; border-right: .5pt solid windowtext; "  class="dr1"><div align="center"><?php echo $x; ?></div></th>
    <th class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo tampil_tgl($data[tgl_tti]);?>
	<input type="text" name="kode_do_int<?php echo $i;?>" value="<?php echo $data[kode_do_int];?>" /></th>
    <th class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo $data[supir];?></th>
    <th class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo $data[jenis_kendaraan];?></th>
    <th class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo $data[nopol];?></th>
    <th class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[dikirim];?></div>	</th>
    <th width="119"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><img src="../images/<?php 
	if($rs_posting[0]>='1'){
		echo "yes.ico";
	}else{
		echo "view_choose.png";
	}?>" border="0" width="16" height="16" onClick="javascript:MM_openBrWindow1('rpt_tti_x.php?id=<?php echo $data[tgl_tti];?>&&supir=<?php echo $data[supir];?>&&nopol=<?php echo $data[nopol];?>&&jenis_kendaraan=<?php echo $data[jenis_kendaraan];?>')" title="RENCANA PENGIRIMAN [<?php echo tampil_tgl($data[tgl_tti]);?>]"/></div></th>
    <th width="119"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><img src="../images/<?php 
	if($rs_posting[0]>='1'){
		echo "yes.ico";
	}else{
		echo "view_choose.png";
	}?>" border="0" width="16" height="16" onClick="javascript:MM_openBrWindow1('rev.php?tgl=<?php echo $data[tgl_tti];?>&&supir=<?php echo $data[supir];?>&&nopol=<?php echo $data[nopol];?>&&jenis_kendaraan=<?php echo $data[jenis_kendaraan];?>')" title="REVISI PENGIRIMAN"/></div></th>
    <th width="120"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><img src="../images/<?php 
	if($rs_posting[0]>='1'){
		echo "yes.ico";
	}else{
		echo "view_choose.png";
	}?>" border="0" width="16" height="16" onClick="javascript:MM_openBrWindow1('cek.php?tgl=<?php echo $data[tgl_tti];?>&&supir=<?php echo $data[supir];?>&&nopol=<?php echo $data[nopol];?>&&jenis_kendaraan=<?php echo $data[jenis_kendaraan];?>')" title="REALISASI"/></div></th>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<th colspan="5" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;
    <input type="hidden" name="tgl_kirimx" value="<?php echo $_POST[tgl_kirim];?>" />
	<input type="hidden" name="tgl_kirim1x" value="<?php echo $_POST[tgl_kirim1];?>" />
    <input type="hidden" name="cdt" value="<?php echo $_POST[cdt];?>" /><input type="hidden" name="dikirim_darix" value="<?php echo $_POST[dikirim_dari];?>" />    <div align="right"></div></th>
    <th style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php echo comma2($sum_tot);?></div>	</th>
	<th colspan="3" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"></div></th>
   </tr>
   </tbody>
</table>
</div>
</div>
<?php
	echo"<div align=\"center\">"; 
	$sql_tampil2="SELECT
tbl_omzet.id_tti,
tbl_omzet.tgl_tti,
tbl_omzet.kode_so_int_FK,
tbl_omzet.kode_so_FK,
tbl_omzet.jumlah,
tbl_omzet.id_buyer_FK,
tbl_omzet.nama_buyer,
tbl_omzet.supir,
tbl_omzet.jenis_kendaraan,
tbl_omzet.nopol,
tbl_omzet.dikirim
FROM
tbl_omzet
WHERE tbl_omzet.tgl_tti BETWEEN '$tgl_kirim' AND '$tgl_kirim1'
";
	//$sql_data1=$sql_data."".$tgl_tti_post." ".$dikirim_dari." ".$grup." ".$order." ".$limit;
	$sql_data2=$sql_tampil2." ".$grup;
	//echo $sql_data2."<br>";
	$tampil2 = mysql_query($sql_data2);  
	$jmldata = mysql_num_rows($tampil2);  
	$jmlhalaman = ceil($jmldata/$batas);  
	if($halaman > 1){  
		$previous=$halaman-1;  
?>  
	<input type="button" value="<<" onClick="javascript:get_first(this.parentNode, this.form, <?php echo "1";?>);">&nbsp;|&nbsp;
	<input type="button" value="<" onClick="javascript:get_prev(this.parentNode, this.form, <?php echo $previous;?>);">&nbsp;|&nbsp;
<?php  
 	}else{
?>
		<input type="button" value="<<" >&nbsp;|&nbsp;
		<input type="button" value="<" >&nbsp;|&nbsp;
<?php
	}  
 	$angka=($halaman > 3 ? " ... " : " ");  
 	for($i=$halaman-2;$i<$halaman;$i++){  
  	if($i < 1)  
   		continue;  
  		//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";
		$angka .=$i;
 	}  
 	$angka .= " <b>$halaman</b> ";  
 	for($i=$halaman+1;$i<($halaman+3);$i++){  
  		if($i > $jmlhalaman)  
   			break;  
			//$angka .= "<a href=?halaman=$i&batas=$batas class=linka>$i</a> ";  
			$angka .=$i;  
 		}  
		$angka .=($halaman+2<$jmlhalaman ?"...$jmlhalaman ":""); 
		//$angka .= ($halaman+2<$jmlhalaman ? " ... <a href=?halaman=$jmlhalaman&batas=$batas class=linka>$jmlhalaman</a> " : " ");  
 		echo"$angka";  
 		if($halaman < $jmlhalaman){  
  			$next=$halaman+1;
			?>
  			|&nbsp;<input type="button" value=">" onClick="javascript:get_next(this.parentNode, this.form, <?php echo $next;?>);">&nbsp;|&nbsp;
			<input type="button" value=">>" onClick="javascript:get_last(this.parentNode, this.form, <?php echo $jmlhalaman;?>);">
			<?php
 		}else{ ?>
 			<input type="button" value=">">&nbsp;|&nbsp;<input type="button" value=">>" >
		<?php
 		}  
 		echo"<strong>Total</strong> : <b>$jmldata</b>";
?></form>
<script type="text/javascript">
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
</script>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
</html>