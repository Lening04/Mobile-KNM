<?php
session_start();

	class cek_rtr {
		function createConnection() {
			require_once "../include/conn.php";
			mysql_select_db($database_conn);
		}
		
		function cek_rtr1($kode_retur) {
			$session_user=$_SESSION['user_name'];
			$sql_location=mysql_query("SELECT location FROM tbl_user WHERE username = '$session_user'");
			$rs_location=mysql_fetch_assoc($sql_location);
			$location=$rs_location[location];
			
			$tgl_now=date("d/m/Y", mktime ($month,$day,$year));
			$str_mm_yyyy=substr($tgl_now,3);
			$str_1="/DO/".$location."/".$str_mm_yyyy;
			//echo $str_1;
			$sql="select max(distinct kode_booking) from tbl_booking_do where kode_booking like '%$str_1' ORDER BY CAST(kode_booking AS SIGNED) DESC";
			//echo "select max(distinct kode_retur) from tbl_booking_retur where kode_retur like '%$str_1' ORDER BY CAST(kode_retur AS SIGNED) DESC";
			$qry = mysql_query($sql);
			$rs = mysql_fetch_row($qry);
			$str=$rs[0];
			$id_str=substr($str,0,4);
			$ids0 = sprintf("%04d", $id_str+1);
			$sip= $ids0."/DO/".$location."/".$str_mm_yyyy;
			//echo $sip;
			$tgl_input=date("Y-m-d", mktime ($month,$day,$year));
			$insert_booking_number="INSERT INTO `db_knm`.`tbl_booking_do` (`kode_booking`, `tanggal_booking`) VALUES ('$sip', '$tgl_input');";
			mysql_query($insert_booking_number);
		}		
	}
	
	$kode_retur = $_GET['x'];
	cek_rtr::createConnection();
	cek_rtr::cek_rtr1($kode_retur);
?>
