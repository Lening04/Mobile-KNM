<?php
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}

$tgl_kirim=$_POST[tgl_kirim];
list($day, $month, $year)=split('[/.-]',$tgl_kirim);
$tgl_kirim=$year."-".$month."-".$day;

if($_POST[update]=='1'){
	$update="UPDATE `tbl_omzet` SET `supir`='$_POST[supir]', `jenis_kendaraan`='$_POST[jenis_kendaraan]', `nopol`='$_POST[nopol]' WHERE `tgl_tti`='$tgl_kirim';";
	//echo $update."<br>";
	mysql_query($update);
	$aktivitas="ADD SUPIR JENIS KENDARAAN NOPOL".$_POST[id];
	$menu="REPORT SALES";
	$session_user=$_SESSION['user_name'];
	$session_level=$_SESSION['user_level'];
	$session_warehouse=$_SESSION['warehouse'];
	$url = $_SERVER['REQUEST_URI'];
	mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");
}

?>
<link href="../include/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<form name="form_tr" action="" method="POST">
<table width="100%" cellspacing="0" class="sort-table" id="table-1">
<thead>
  <tr >
    <td width="39" class="dr2"><div align="center">NO</div></td>
	<td width="142" class="dr2"><div align="center">NAMA PELANGGAN</div></td>
    <td width="228" class="dr2"><div align="center">WILAYAH</div></td>
    <td width="213" class="dr2"><div align="center">NAMA BARANG</div></td>
    <td width="213" class="dr2"><div align="center">SATUAN</div></td>
    <td width="229" class="dr2"><div align="center">KEMASAN</div></td>
    <td width="229" class="dr2"><div align="center">MC</div></td>
    <td width="229" class="dr2"><div align="center">KG</div></td>
  </tr>
  </thead>
<tbody>
<?php
$grup="GROUP BY tbl_omzet.tgl_tti";
$sql_data="SELECT
tbl_omzet.id_tti,
tbl_omzet.tgl_tti,
tbl_omzet.kode_so_FK,
tbl_omzet.kode_so_int_FK,
tbl_omzet.jumlah,
tbl_omzet.id_buyer_FK,
tbl_omzet.nama_buyer
FROM
tbl_omzet
WHERE
tbl_omzet.tgl_tti = '$tgl_kirim'
";
	$sql_data1=$sql_data;
	//echo $sql_data1;
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#E8FFFF";
		}else{
	   		$warna ="#B0D8FF";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#FFFFB0'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  class="dr1"><div align="center"><?php echo $i; ?></div></td>
<td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo tampil_tgl($data[tgl_tti]);?></td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[kode_so_int_FK];?></div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[kode_so_FK];?></div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[jumlah]);$sum_tot+=$data[jumlah];?></div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[nama_buyer];?></div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[nama_buyer];?></div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left"><?php echo $data[nama_buyer];?></div>	</td>
  </tr>
   <?php
   }
	   $sql_data2="SELECT
		tbl_omzet.tgl_tti,
		tbl_omzet.supir,
		tbl_omzet.jenis_kendaraan,
		tbl_omzet.nopol
		FROM
		tbl_omzet
		WHERE
		tbl_omzet.tgl_tti = '$tgl_kirim'
		GROUP BY tbl_omzet.tgl_tti
		";
		//echo $sql_data2;
		$qry_data2 = mysql_query($sql_data2);
		$data2=mysql_fetch_assoc($qry_data2)
   ?>
   <tr >
   	<td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">
    <input type="hidden" name="tgl_kirim" value="<?php echo $_POST[tgl_kirim];?>" />SUPIR</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">
      <input type="TEXT" name="supir"  style="width: 90%; background-color:#FFFFCC;" value="<?PHP echo $data2[supir];?>"/>
   	</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">JENIS KENDARAAN</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">
      <input type="TEXT" name="jenis_kendaraan"  style="width: 90%; background-color:#FFFFCC;" value="<?PHP echo $data2[jenis_kendaraan];?>"/>
   	</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">NOPOL</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><input type="TEXT" name="nopol" style="width: 90%; background-color:#FFFFCC;" value="<?PHP echo $data2[nopol];?>"/></div></td>
    <td colspan="2" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">
      <input type="BUTTON" value="SIMPAN" onClick="javascript:get_update(this.form, <?php echo $i;?>)"  /></div></td>
    </tr>
    </tr>
   </tbody>
</table>
</form>
<script type="text/javascript">
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
</script>