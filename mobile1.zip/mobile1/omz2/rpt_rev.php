<?php 
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
//print_r($_POST); echo "<br>";
include('../include/conn.php');
include('../include/tanggal.php');
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$aktivitas="OPEN REVISI PENGIRIMAN ".$_REQUEST[id];
$menu="REPORT SALES";
$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
//echo $session_user."<br>";
//echo $session_level."<br>";
//echo $session_warehouse."<br>";
$url = $_SERVER['REQUEST_URI'];
mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");
//echo "INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');";

$realisasi_r=str_replace(",","",$_POST[realisasi]);
//echo $realisasi_r."<br>";
$tgl_x=$_POST[tgl_x];
$supir_x=$_POST[supir_x];
$nopol_x=$_POST[nopol_x];
$jenis_kend_x=$_POST[jenis_kend_x];
function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function  tanggal_format_indonesia($tgl){
$tanggal  =  substr($tgl,8,2);
$bulan  =  getBulan(substr($tgl,5,2));
$tahun  =  substr($tgl,0,4);
return  $tanggal.' '.$bulan.' '.$tahun;
}
 
function  getBulan($bln){
switch  ($bln){
case  1:
return  "JANUARI";
break;
case  2:
return  "FEBRUARI";
break;
case  3:
return  "MARET";
break;
case  4:
return  "APRIL";
break;
case  5:
return  "MEI";
break;
case  6:
return  "JUNI";
break;
case  7:
return  "JULI";
break;
case  8:
return  "AGUSTUS";
break;
case  9:
return  "SEPTEMBER";
break;
case  10:
return  "OKTOBER";
break;
case  11:
return  "NOVEMBER";
break;
case  12:
return  "DESEMBER";
break;
}
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
/*$sql_status_rev="select status_rev 
from tbl_omzet
WHERE tbl_omzet.tgl_tti = '$tgl_x'
AND tbl_omzet.nopol = '$nopol_x'
AND tbl_omzet.supir = '$supir_x'
AND tbl_omzet.jenis_kendaraan = '$jenis_kend_x'
";
$qry_status_rev=mysql_query($sql_status_rev);
$rs_status_rev=mysql_fetch_row($qry_status_rev);
$status_rev=$rs_status_rev[0];
echo $sql_status_rev."<br>";*/

$sql_data="SELECT
tbl_omzet.id_tti,
tbl_omzet.tgl_tti,
tbl_omzet.kode_so_int_FK,
tbl_omzet.kode_so_FK,
tbl_omzet.jumlah,
tbl_omzet.id_buyer_FK,
tbl_omzet.nama_buyer,
tbl_omzet.supir,
tbl_omzet.jenis_kendaraan,
tbl_omzet.nopol,
tbl_omzet.dikirim,
tbl_sj.kode_sj,
tbl_sj.tanggal_sj,
tbl_sj.id_satuan_FK,
tbl_sj.id_size_FK,
tbl_sj.mc,
tbl_sj.qty,
tbl_sj.harga_jual,
tbl_sj.jumlah,
tbl_sj.kode_produk_FK,
tbl_produk.nama_produk,
tbl_omzet.realisasi,
tbl_sj.id_sj,
tbl_omzet.status_rev
FROM
tbl_omzet
Inner Join tbl_sj ON tbl_sj.kode_so_int_FK = tbl_omzet.kode_so_int_FK
Inner Join tbl_produk ON tbl_produk.kode_produk = tbl_sj.kode_produk_FK
WHERE tbl_omzet.tgl_tti = '$tgl_x'
AND tbl_omzet.nopol = '$nopol_x'
AND tbl_omzet.supir = '$supir_x'
AND tbl_omzet.jenis_kendaraan = '$jenis_kend_x'
ORDER BY tbl_omzet.kode_so_int_FK ASC
";
//echo $sql_data."<br>";
/////////////////////////////status REVISI
$qry_status_rev=mysql_query($sql_data);
$rs_status_rev=mysql_fetch_assoc($qry_status_rev);
$status_rev=$rs_status_rev[status_rev];
//echo $status_rev."<br>";
if($_POST[del]=='1'){
	$update_real="DELETE FROM `tbl_omzet` WHERE `id_tti`='$rs_status_rev[kode_so_int_FK]';";
	mysql_query($update_real);
	//echo $update_real;
}


/*$sql_id_sj="SELECT
tbl_omzet.id_tti,
tbl_sj.id_sj,
tbl_sj.kode_produk_FK
FROM
tbl_omzet
Inner Join tbl_sj ON tbl_sj.kode_so_int_FK = tbl_omzet.kode_so_int_FK
WHERE tbl_omzet.tgl_tti = '$tgl_x' AND tbl_omzet.nopol = '$nopol_x' AND tbl_omzet.supir = '$supir_x' AND tbl_omzet.jenis_kendaraan = '$jenis_kend_x'
AND tbl_omzet.id_tti = '$_POST[id]'";
echo $sql_id_sj."<br>";
$qry_id_sj = mysql_query($sql_id_sj);
$rs_id_sj = mysql_fetch_row($qry_id_sj);*/
$id_sj=$_POST[id_sj];

//////////////////////////////ganti MC
if($_POST[ganti_mc]=='1'){
	$update_ganti_mc="UPDATE `db_knm`.`tbl_sj` SET `mc`='$_POST[mc]' WHERE `id_sj`='$id_sj';";
	mysql_query($update_ganti_mc);
	//echo $update_ganti_mc."<br>";
}

//////////////////////////////ganti KEMASAN
if($_POST[ganti_kemasan]=='1'){
	$update_ganti_kemasan="UPDATE `db_knm`.`tbl_sj` SET `qty`='$_POST[kemasan]' WHERE `id_sj`='$id_sj';";
	mysql_query($update_ganti_kemasan);
	//echo $update_ganti_kemasan."<br>";
}
//////////////////////////////POSTING
if($_POST[posting]=='1' && empty($status_rev)){
//if($_POST[posting]=='1'){
	$sql_posting=$sql_data;
	$qry_posting = mysql_query($sql_posting);
	while($rs_posting = mysql_fetch_assoc($qry_posting)){
		$posting_ra="UPDATE `db_knm`.`tbl_ra` SET `ra_revisi_status`='1', `qty_ra`='$rs_posting[qty]' 
		WHERE tbl_ra.kode_so_int_FK = '$rs_posting[kode_so_int_FK]' AND tbl_ra.kode_produk_FK = '$rs_posting[kode_produk_FK]';";
		//mysql_query($posting_ra);
		//echo $posting_ra."<br>";
		$posting_omzet="UPDATE `db_knm`.`tbl_omzet` SET `status_rev`='1', `realisasi`='$realisasi_r'
		WHERE tbl_omzet.kode_so_int_FK = '$rs_posting[kode_so_int_FK]' AND tbl_omzet.id_tti = '$rs_posting[id_tti]';";
		//mysql_query($posting_omzet);
		//echo $posting_omzet."<br>";
	}
	//echo $sql_posting."<br>";
	$sql_inv="SELECT
	tbl_omzet.kode_so_int_FK
	FROM
	tbl_omzet
	Inner Join tbl_sj ON tbl_sj.kode_so_int_FK = tbl_omzet.kode_so_int_FK
	Inner Join tbl_produk ON tbl_produk.kode_produk = tbl_sj.kode_produk_FK
	WHERE tbl_omzet.tgl_tti = '$tgl_x'
	AND tbl_omzet.nopol = '$nopol_x'
	AND tbl_omzet.supir = '$supir_x'
	AND tbl_omzet.jenis_kendaraan = '$jenis_kend_x'
	GROUP BY tbl_omzet.kode_so_int_FK ASC";
	//echo $sql_inv."<br>";
	$qr_inv=mysql_query($sql_inv);
	while($rs_inv = mysql_fetch_assoc($qr_inv)){
		$kode_pajak=substr($rs_inv[kode_so_int_FK],5,3);
		echo $rs_inv[kode_so_int_FK]."----".$kode_pajak."<br>";
		
	}
		
	$gmt=date("Z");
	$session_time=date("U");
	$session_id=session_id();
	$ipaddress=$_SERVER['REMOTE_ADDR'];
	$ip= $REMOTE_ADDR;
	$host_name = GetHostByName($ip);
	$aktivitas="POSTING REVISI PENGIRIMAN ".$tgl_x." ".$nopol_x." ".$supir_x." ".$jenis_kend_x;
	$menu="REPORT SALES";
	$session_user=$_SESSION['user_name'];
	$session_level=$_SESSION['user_level'];
	$session_warehouse=$_SESSION['warehouse'];
	
	//mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");
	echo "INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');";
	//mencari nilai invoice
	/*$sq_inv="select nilai_so, ppn, biaya_pengiriman, diskon, nilai_invoice from tbl_inv where kode_so_int_FK = '$rs1_posting[kode_so_int_FK]'";
	$qy_inv=mysql_query($sq_inv);
	$rs_inv=mysql_fetch_assoc($qy_inv);
	echo $sq_inv."<br>";
	$nilai_ppn_round= ($rs_inv[ppn]/$rs_inv[nilai_so])*100;
	echo "($rs_inv[ppn]"."/"."$rs_inv[nilai_so])"."*"."100"."<br>";
	$nilai_ppn=round($nilai_ppn_round,0,PHP_ROUND_HALF_UP)."<br>";
	echo $nilai_ppn;*/
	
	//$total_dibayar=$_POST[nilai_soh]+$_POST[ppnh]+$_POST[biaya_kirim]-$_POST[diskon];
	
	//$total_dibayar=$_POST[nilai_soh]+$_POST[ppnh]+$_POST[biaya_kirim]-$_POST[diskon];
	//echo "UPDATE `db_knm`.`tbl_inv` SET `nilai_so`='', `nilai_invoice`='' WHERE  `kode_so_int_FK`='$rs1_posting[kode_so_int_FK]';"."<br>";
}
?>
<link href="../include/stylesinv.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<script type="text/javascript">
/////////////MEMBEDAKAN HURUF DAN ANGKA START/////////////////
function getkey(e)
{
if (window.event)
   return window.event.keyCode;
else if (e)
   return e.which;
else
   return null;
}
function goodchars(e, goods, field)
{
var key, keychar;
key = getkey(e);
if (key == null) return true;
 
keychar = String.fromCharCode(key);
keychar = keychar.toLowerCase();
goods = goods.toLowerCase();
 
// check goodkeys
if (goods.indexOf(keychar) != -1)
    return true;
// control keys
if ( key==null || key==0 || key==8 || key==9 || key==27 )
   return true;
    
if (key == 13) {
    var i;
    for (i = 0; i < field.form.elements.length; i++)
        if (field == field.form.elements[i])
            break;
    i = (i + 1) % field.form.elements.length;
    field.form.elements[i].focus();
    return false;
    };
// else return false
return false;
}
/////////////MEMBEDAKAN HURUF DAN ANGKA END/////////////////
</script>
<table width="1024" align="center" cellpadding="0" cellspacing="0" >
  <tr class="medium" >
    <td height="16" colspan="5" ><div align="left">REVISI PENGIRIMAN <?PHP echo tanggal_format_indonesia($tgl_x);?></div></td>
  </tr>
  <tr class="medium">
    <td height="16" ><div align="left">PT. KELOLA NIAGA MAKMUR</div></td>
    <td width="651" colspan="4" ><div align="right"></div></td>
  </tr>
  <tr class="medium">
    <td height="16" ><div align="left">NO. POL KENDARAAN : <?php echo $nopol_x;?></div></td>
    <td width="651" colspan="4" ><div align="left"><?php echo $jenis_kend_x;?></div></td>
  </tr>
</table>  
<table width="1024" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr class="medium" >
    <td width="34" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>NO</strong></div></td>
	<td width="349" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>NAMA PELANGGAN</strong></div></td>
    <td width="349" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>KODE SO</strong></div></td>
    <td width="97" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>WILAYAH</strong></div></td>
    <td width="351" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>NAMA BARANG</strong></div></td>
    <td width="46" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>SATUAN</strong></div></td>
    <td width="54" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>KEMASAN</strong></div></td>
    <td width="49" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>MC</strong></div></td>
    <td width="42" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>KG</strong></div></td>
    <td width="42" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext;"><div align=center><strong>DEL</strong></div></td>
  </tr>
<?php

	$sql_data1=$sql_data;
	//echo $sql_data1."<br>";
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		
		///mencari wilayah start
		$sql_wil="SELECT tbl_buyer.id_buyer, tbl_area.nama_area FROM tbl_buyer Inner Join tbl_area ON tbl_area.id_area = tbl_buyer.area
 WHERE tbl_buyer.id_buyer = '$data[id_buyer_FK]'";
 		//echo $sql_wil."<br>";
		$qry_wil=mysql_query($sql_wil);
		$wil=mysql_fetch_assoc($qry_wil);
		///mencari wilayah end
		
		///mencari satuan start
		$sql_satu="select id_satuan, nama_satuan from tbl_satuan where id_satuan = '$data[id_satuan_FK]'";
		$qry_satu=mysql_query($sql_satu);
		$satu=mysql_fetch_assoc($qry_satu);
		///mencari satuan end
		
		//mencari konversi kg start
		//echo $data[kode_produk_FK]."<br>";
		$konv=substr($data[kode_produk_FK],18,3);
		
		$sql_nilai_konv="select konv, nama_produk from tbl_produk where kode_produk = '$data[kode_produk_FK]'";
		//echo $sql_nilai_konv."<br>";
		$qry_nilai_konv=mysql_query($sql_nilai_konv);
		$rs_nilai_konv=mysql_fetch_row($qry_nilai_konv);
		$nilai_konv=$rs_nilai_konv[0];
		//echo $data[kode_produk_FK]."< >".$konv."< >".$nilai_konv."< >".$rs_nilai_konv[1]."<br>";
		//mencari konversi kg end
		$i++;
?>

  <tr class="medium" >
    <td style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "  ><div align="center"><?php echo $i; ?></div></td>
<td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; " ><div align="left">&nbsp;<?php echo $data[nama_buyer];?>
<input type="hidden"  name="id<?php echo $i;?>" value="<?php echo $data[id_tti];?>"/>
<input type="hidden"  name="id_sj<?php echo $i;?>" value="<?php echo $data[id_sj];?>"/></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo strtoupper($data[kode_so_FK])."<>".$data[kode_so_int_FK];?></div></td>
    
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo $wil[nama_area];?></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo $data[nama_produk];?><input type="hidden"  name="kode_produk<?php echo $i;?>" value="<?php echo $data[kode_produk_FK];?>"/></div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><?php echo $satu[nama_satuan];?></div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right">
	<input type="text" name="kemasan<?php echo $i;?>" value="<?php 
	echo comma0($data[qty]);
	$sum_qty+=$data[qty];
	?>" onChange="get_ganti_kemasan(this.form, <?php echo $i;?>);"
	<?php
		if($status_rev=="1"){
			echo "readonly";
		}
	?>
	 style="width: 100%; background-color:#<?php
		if($status_rev=="1"){
			echo "CCFF99";
		}else{
			echo "FFFFCC";
		}
	?>; text-align:right;"></div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right">
	<input type="text" name="mc<?php echo $i;?>" value="<?php echo comma0($data[mc]);$sum_mc+=$data[mc];?>" onChange="get_ganti_mc(this.form, <?php echo $i;?>);" 
	<?php
		if($status_rev=="1"){
			echo "readonly";
		}
	?>
	style="width: 100%; background-color:#<?php
		if($status_rev=="1"){
			echo "CCFF99";
		}else{
			echo "FFFFCC";
		}
	?>; text-align:right;"></div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php $kkg=$data[qty]*$nilai_konv; echo comma2($kkg);$sum_jumlah+=$kkg;?>
    </div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext;";><div align="center"><input type="checkbox" name="del<?php echo $i;?>" onClick="get_del(this.form, <?php echo $i;?>);"  /></div></td>
  </tr>
   <?php
   }
   ?>
   <tr class="medium" >
    <td colspan="5" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "  ><div align="center"></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sum_qty);?></strong></div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sum_mc);?></strong></div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext;border-right: .5pt solid windowtext;  border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="right"><strong><?php echo comma2($sum_jumlah);?></strong></div>	</td>
    <td width=42 style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext;"><div align=center><strong>&nbsp;</strong></div></td>
  </tr>
</table>
<br />
<table width="1024" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr class="medium" >
    <td width="412" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>NAMA BARANG</strong></div></td>
	<td width="54" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>KEMASAN</strong></div></td>
    <td width="65" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>MC</strong></div></td>
    <td width="51" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>KG</strong></div></td>
    <td width="440" style="color: windowtext; border-left: .5pt solid windowtext;"><div align="center"></div></td>
  </tr>
  <?php
	$sql2="SELECT
tbl_sj.kode_produk_FK,
tbl_produk.nama_produk,
tbl_sj.id_satuan_FK,
tbl_sj.id_size_FK,
sum(tbl_sj.mc) as mc,
sum(tbl_sj.qty) as qty,
sum(tbl_sj.jumlah) as jumlah
FROM tbl_omzet Inner Join tbl_sj ON tbl_sj.kode_so_int_FK = tbl_omzet.kode_so_int_FK Inner Join tbl_produk ON tbl_produk.kode_produk = tbl_sj.kode_produk_FK
WHERE tbl_omzet.tgl_tti = '$tgl_x' AND tbl_omzet.nopol = '$nopol_x' AND tbl_omzet.supir = '$supir_x' AND tbl_omzet.jenis_kendaraan = '$jenis_kend_x'
GROUP  BY tbl_sj.kode_produk_FK
";
//echo $sql2;
	$qry2 = mysql_query($sql2);
	while($data2 = mysql_fetch_assoc($qry2)){
	
		//$konv2=substr($data2[kode_produk_FK],18,3);
		
		$sql_nilai_konv2="select konv from tbl_produk where kode_produk = '$data2[kode_produk_FK]'";
		$qry_nilai_konv2=mysql_query($sql_nilai_konv2);
		$rs_nilai_konv2=mysql_fetch_row($qry_nilai_konv2);
		$nilai_konv2=$rs_nilai_konv2[0];
?>

  <tr class="medium" >
    <td style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "  ><div align="left">&nbsp;<?php echo $data2[nama_produk]; ?></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; " ><div align="right"><?php echo comma0($data2[qty]);?></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php echo comma0($data2[mc]);?></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php 
	$xkg=$data2[qty]*$nilai_konv2;
	echo comma2($xkg);?></div>	</td>
     
    <td colspan="4"  style="color: windowtext; border-left: .5pt solid windowtext; "><div align="center"></div>	</td>
  </tr>
   <?php
   }
   ?>
  
    
   
   <tr class="medium" >
     <td style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "  ><div align="center"><strong>Grand Total</strong></div></td>
    <td colspan="1" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "  ><div align="right"><strong><?php echo comma0($sum_qty);?></strong></div></td>
	<td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sum_mc);?></strong></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="right"><strong><?php echo comma2($sum_jumlah);?></strong></div>	</td>
	<td colspan="4"  style="color: windowtext; border-left: .5pt solid windowtext; "><div align="center"></div></td>
  </tr>
  
   <tr class="medium"> 
   	 <td height="50" colspan="4"><div align="center">Realisai Rp.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <?php
	 $sql_real="select realisasi from tbl_omzet where tgl_tti = '$tgl_x' and supir = '$supir_x' and nopol = '$nopol_x' and jenis_kendaraan = '$jenis_kend_x'"; 
	 //echo  $sql_real."<br>";
	 $qry_real= mysql_query($sql_real);
	 $rs_real=mysql_fetch_assoc($qry_real);
	 //echo $rs_real[realisasi];
	 ?>
     <INPUT type="text" name="realisasi" 
	 <?php
		if($status_rev=="1"){
			echo "readonly";
		}
	?>
	 style="width: 20%; background-color:#<?php
		if($status_rev=="1"){
			echo "CCFF99";
		}else{
			echo "FFFFCC";
		}
	?>;" value="<?PHP echo comma0($rs_real[realisasi]);?>" onKeyPress="return goodchars(event,'0123456789.',this);"  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      <input name="posting" type="<?php 
	  if($status_rev=='1'){
		echo "hidden";
		//echo "button";
	  }else{
	  	echo "button";
	  }
	  ?>" value="POSTING" onClick="get_posting(this.form, <?php echo $i;?>); "/></div></td>
     <td colspan="2" >
     <input name="tgl_x" type="hidden" value="<?php echo $tgl_x;?>" />
    <input name="supir_x" type="hidden" value="<?php echo $supir_x;?>"  />
    <input name="nopol_x" type="hidden" value="<?php echo $nopol_x;?>"  />
    <input name="jenis_kend_x" type="hidden" value="<?php echo $jenis_kend_x;?>"  /></td>
  </tr>
  </table>
  <table width="1024" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
    <tr class="small">
    <td height="18" colspan="2"><div align="center"><?php echo ucwords(strtoupper($supir_x))?></div></td>
    <td height="18" style="text-decoration:underline" ></div></td>
    <td height="18" style="text-decoration:underline" ><div align="center"><?php echo ucwords(strtoupper($data[kuasa]));?></div></td>
  </tr>
   <tr class="medium">
   <td colspan="2"><div align="center">Driver</div></td>
   <td ><div align="center">PPIC</div></td>
   <td ><div align="center">Stuffing</div></td>
  </tr>
</table>
