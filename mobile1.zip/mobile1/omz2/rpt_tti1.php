<?php 
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$aktivitas="PRINT TTF ".$_REQUEST[id];
$menu="REPORT SALES";
$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
//echo $session_user."<br>";
//echo $session_level."<br>";
//echo $session_warehouse."<br>";
$url = $_SERVER['REQUEST_URI'];
mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");
//echo "INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function  tanggal_format_indonesia($tgl){
$tanggal  =  substr($tgl,8,2);
$bulan  =  getBulan(substr($tgl,5,2));
$tahun  =  substr($tgl,0,4);
return  $tanggal.' '.$bulan.' '.$tahun;
}
 
function  getBulan($bln){
switch  ($bln){
case  1:
return  "JANUARI";
break;
case  2:
return  "FEBRUARI";
break;
case  3:
return  "MARET";
break;
case  4:
return  "APRIL";
break;
case  5:
return  "MEI";
break;
case  6:
return  "JUNI";
break;
case  7:
return  "JULI";
break;
case  8:
return  "AGUSTUS";
break;
case  9:
return  "SEPTEMBER";
break;
case  10:
return  "OKTOBER";
break;
case  11:
return  "NOVEMBER";
break;
case  12:
return  "DESEMBER";
break;
}
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
$sql_data="SELECT
tbl_tti.id_tti,
tbl_tti.tgl_tti,
tbl_tti.kode_so_int_FK,
tbl_tti.kode_so_FK,
tbl_tti.jumlah,
tbl_tti.id_buyer_FK,
tbl_tti.nama_buyer,
tbl_tti.tgl_ttf,
tbl_tti.tgl_diterima,
tbl_tti.scan,
tbl_so.sbu,
tbl_so.kode_so_new,
tbl_buyer.kode_store
FROM
tbl_tti
Inner Join tbl_so ON tbl_so.kode_so_int = tbl_tti.kode_so_int_FK
Inner Join tbl_buyer ON tbl_buyer.id_buyer = tbl_tti.id_buyer_FK
WHERE tbl_tti.tgl_tti = '$_REQUEST[id]'
GROUP BY tbl_tti.kode_so_int_FK
";
//echo $sql_data."<BR>";
$sql_tg=mysql_query($sql_data);
$tg=mysql_fetch_row($sql_tg);
?>
<link href="../include/stylesinv.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<table width="690" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr >
    <td height="16" colspan="3" ><div align="center" style="font-size:20px;"><em>TANDA TERIMA (INVOICE LOTTE)</em></div></td>
  </tr>
  <tr >
    <td width="293" height="16" ><div align="left"></div></td>
	<td width="78" >&nbsp;</td>
    <td width="651" >&nbsp;</td>
  </tr>
  <tr >
    <td width="293" height="16" ><div align="left"></div></td>
	<td width="78" >&nbsp;</td>
    <td width="651" >&nbsp;</td>
  </tr>
</table>  
<table width="690" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr class="medium" >
    <td width="58" height="16" ><div align="center"></div></td>
	<td colspan="5" ><div align="left"></div>	  <div align="left"></div>	  <div align="left"></div></td>
  </tr>
  <tr class="medium" >
    <td height="16" ><div align="left">Kepada</div></td>
	<td width="117" ><div align="right">:</div></td>
    <td height="16" colspan="4" ><div align="left">&nbsp;<?PHP 
	if($tg[10]=='O396'){
		echo "PT. KELOLA NIAGA MAKMUR";
	}else{
		echo "PT. KELOLA MINA LAUT";
	}?></div>      <div align="left"></div>      <div align="left"></div>      <div align="left"></div></td>
  </tr>
  <tr class="medium" >
    <td height="16" ><div align="left"></div></td>
	<td width="117" ><div align="right"></div></td>
    <td height="16" colspan="4" ><div align="left">&nbsp;Jl. Inspeksi Kalimalang No. 99</div>      
    <div align="left"></div>    <div align="left"></div>    <div align="left"></div></td>
  </tr>
  <tr class="medium" >
   <td height="16" ><div align="left"></div></td>
	<td width="117" ><div align="right"></div></td>
    <td height="16" colspan="4" ><div align="left">&nbsp;Jakarta Timur</div>      
    <div align="left"></div>    <div align="left"></div>    <div align="left"></div></td>
  </tr>
  <tr class="medium" >
    <td height="16" ><div align="left">Tanggal</div></td>
    <td ><div align="right">:</div></td>
    <td height="16" colspan="4" ><div align="left">&nbsp;<?php echo tanggal_format_indonesia($tg[1]);?></div>
        <div align="left"></div>
      <div align="left"></div>      <div align="left"></div></td>
  </tr>
  <tr class="medium" >
    <td height="37" colspan="6" style="color: windowtext; border-left: medium none; "><div align="left"></div></td>
  </tr>
  <tr class="medium" >
    <td width="58" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"><strong>NO</strong></div></td>
	<td width="117" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"><strong>KODE<BR>
    STORE</strong></div></td>
    <td width="207" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"><strong>INVOICE RECEIPT<BR>
      NO BARCODE<BR>
    PROFORMA INV</strong></div></td>
    <td width="138" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"><strong>JUMLAH<BR>
    AMOUNT</strong></div></td>
    <td width="168" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"><strong>TOKO<BR>
    STORE</strong></div></td>
  </tr>
<?php

	$sql_data1=$sql_data;
	//echo $sql_data1;
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_row($qry_data)){
		$i++;
?>

  <tr class="medium" >
    <td style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "  ><div align="center"><?php echo $i; ?></div></td>
<td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; " ><div align="center"><?php echo $data[12];?></div></td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="CENTER"><?php 
	if(!empty($data[11])){
		echo $data[11];
	}else{
		echo $data[3];
	}
	?></div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php echo comma2($data[4]); $sum_tot+=$data[4];?>&nbsp;</div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo $data[6];?></div>	</td>
  </tr>
   <?php
   }
   ?>
   <tr class="medium" >
    <td colspan="3" style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "  ><div align="center"></div></td>
<td  style="color: windowtext; border-left: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma2($sum_tot);?></strong>&nbsp;</div>	</td>
    <td  style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="left">&nbsp;</div>	</td>
  </tr>
   <tr class="medium" >
   	<td colspan="5" style="color: windowtext; border-left: medium none; border-top: .5pt solid windowtext; "><div align="left"></div></td>
  </tr>
</table>
