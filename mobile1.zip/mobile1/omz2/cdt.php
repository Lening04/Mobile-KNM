<?php
include('../include/conn.php');
include('../include/tanggal.php');
$q = strtolower($_GET["q"]);
if (!$q) return;
$sql_sup="SELECT
tbl_so.kode_so
FROM
tbl_so
Inner Join tbl_inv ON tbl_inv.kode_so_int_FK = tbl_so.kode_so_int
where tbl_inv.scan =''
group by tbl_so.kode_so";
$query_sup = mysql_query($sql_sup);
while(list($kode,$nama) = mysql_fetch_row($query_sup)){
  $tampil = $nama;
  $items[$tampil] =$kode;
}
foreach ($items as $tampil=>$kode) {
	if (strpos(strtolower($tampil), $q) !== false) {
		echo "$tampil\n";
	}
}
?>