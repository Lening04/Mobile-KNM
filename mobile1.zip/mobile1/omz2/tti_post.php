<?php
include('../include/conn.php');
include('../include/tanggal.php');
print_r($_POST); echo "<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}

$tgl_kirim1 = $_POST[tgl_kirim];
list($day, $month, $year) = split('[/.-]', $tgl_kirim1);
$tgl_kirim1 = $year."-".$month."-".$day;

if($_POST[del]=='1'){
	$dele="DELETE FROM `tbl_omzet` WHERE `id_tti`='$_POST[id]'";
	//echo $dele."<br>";
	mysql_query($dele);
	//$update_inv1="UPDATE `db_knm`.`tbl_inv` SET `scan`='' WHERE  `kode_so_int_FK`='$_POST[kode_so_int_FK]';";
	//echo $update_inv1."<br>";
	//mysql_query($update_inv1);
}
if($_POST[insert]=='1'){
	$sql_nilai="SELECT
tbl_buyer.nama_buyer,
tbl_sj.harga_jual,
tbl_sj.jumlah,
tbl_sj.id_buyer_FK,
tbl_sj.kode_so_int_FK,
tbl_so.kode_so
FROM
tbl_buyer
Inner Join tbl_sj ON tbl_sj.id_buyer_FK = tbl_buyer.id_buyer
Inner Join tbl_so ON tbl_so.kode_so_int = tbl_sj.kode_so_int_FK
WHERE
tbl_sj.kode_so_int_FK = '$_POST[kode_so]'
GROUP BY tbl_sj.kode_so_int_FK
	";
	$qry_nilai=mysql_query($sql_nilai);
	$nilai=mysql_fetch_assoc($qry_nilai);
	$xxx=$nilai[harga_jual]*$nilai[jumlah];
	//echo $sql_nilai."<br>";
	
	$insert="INSERT INTO `tbl_omzet` (`tgl_tti`, `kode_so_int_FK`, `kode_so_FK`, `jumlah`, `id_buyer_FK`, `nama_buyer`, `supir`, `jenis_kendaraan`, `nopol`, `dikirim`) VALUES ('$tgl_kirim1', '$_POST[kode_so]', '$nilai[kode_so]', '$xxx', '$nilai[id_buyer_FK]', '$nilai[nama_buyer]', '$_POST[supir]', '$_POST[jenis_kend]','$_POST[nopol]', '$_POST[dikirim_dari]');";
	//echo $insert."<br>";
	mysql_query($insert);
}
///////////////////////////////////
?>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>

<link href="../include/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<form name="form_tr" action="" method="POST">
<table width="100%" cellspacing="0" class="sort-table" id="table-1">
<thead>
  <tr >
    <td width="38" class="dr2"><div align="center">No</div></td>
	<td width="231" class="dr2"><div align="center">TANGGAL</div></td>
    <td width="229" class="dr2"><div align="center">KODE SO INTERNAL</div></td>
    <td width="229" class="dr2"><div align="center">KODE SO</div></td>
    <td width="321" class="dr2"><div align="center">TOTAL HARGA</div></td>
    <td width="364" class="dr2"><div align="center">CUSTOMER</div></td>
    <td width="34" class="dr2"><div align="center">DEL</div></td>
  </tr>
  </thead>
<tbody>
<?php
	$tgl_tti_post="$tgl_kirim1";
$order="ORDER BY tbl_omzet.tgl_tti DESC";
$sql_data="SELECT tbl_omzet.id_tti, 
tbl_omzet.tgl_tti, 
tbl_omzet.kode_so_FK, 
tbl_omzet.kode_so_int_FK, 
tbl_omzet.jumlah, 
tbl_omzet.id_buyer_FK, 
tbl_omzet.nama_buyer, 
tbl_omzet.supir,
tbl_omzet.jenis_kendaraan,
tbl_omzet.nopol,
tbl_omzet.dikirim
FROM tbl_omzet 
WHERE tbl_omzet.tgl_tti = '$tgl_tti_post'
AND tbl_omzet.supir = '$_POST[supir]'
AND tbl_omzet.nopol = '$_POST[nopol]'
AND tbl_omzet.jenis_kendaraan = '$_POST[jenis_kend]'
AND tbl_omzet.dikirim = '$_POST[dikirim_dari]'
";
	$sql_data1=$sql_data." ".$order;
	//echo $sql_data1;
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#9DC5E6";
		}else{
	   		$warna ="#BCDADA";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#FFFFB0'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  class="dr1"><div align="center"><?php echo $i; ?></div></td>
<td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;<?php echo tampil_tgl($data[tgl_tti]);?>
  <input name="id<?php echo $i;?>" type="hidden" value="<?php echo $data[id_tti];?>" />
  <input name="kode_so_int_FK<?php echo $i;?>" type="hidden" value="<?php echo $data[kode_so_int_FK];?>" /></td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo $data[kode_so_int_FK];?></div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left">&nbsp;<?php 
	if(!empty($data[kode_so_new])){
		echo $data[kode_so_new];
	}else{
		echo $data[kode_so_FK];
	}
	?></div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[jumlah]);$sum_tot+=$data[jumlah];?>&nbsp;</div>	</td>
    <td  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo $data[nama_buyer];?></div>	</td>
    <td width="34"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><input type="checkbox" name="del<?php echo $i;?>" onClick="get_del(this.form, <?php echo $i;?>);" ></div></td>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<td colspan="7" style="color: windowtext; border-top: .5pt solid windowtext; "><div align="center">
    <input type="hidden" name="tgl_kirimx" value="<?php echo $_POST[tgl_kirim];?>" />
    <input type="hidden" name="kode_so" value="<?php echo $_POST[kode_so];?>" />
    <input type="hidden" name="jenis_kend" value="<?php echo $_POST[jenis_kend];?>" />
    <input type="hidden" name="dikirim_dari" value="<?php echo $_POST[dikirim_dari];?>" />
    <input type="hidden" name="supir" value="<?php echo $_POST[supir];?>" />
    <input type="hidden" name="nopol" value="<?php echo $_POST[nopol];?>" />
	<input type="text" name="kode_do" value="<?php echo $_POST[kode_do];?>" />
    </div></td>
    </tr>
   </tbody>
</table>
</form>
<script type="text/javascript">
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
</script>