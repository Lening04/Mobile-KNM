<?php 
session_start();
if(empty($_SESSION['kdadmin'])){   
	echo "<script>location.href='login.php'</script>";   
	header("Location: login.php");
}else{  
	echo "<script>location.href='index_log.php'</script>";  
	header("Location: index.php");
}
?>