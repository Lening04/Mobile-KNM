<?php
//$link = mysql_connect("192.168.0.130", "luluk", "kanuragan");
$link = mysql_connect("localhost", "root", "");
//$link = mysql_connect("localhost", "root", "");
if (!$link) {
    die('tidak bisa konek database 86: ' . mysql_error());
}

$db_selected = mysql_select_db('db_knm', $link);
if (!$db_selected) {
    die ('Can\'t use db_knm : ' . mysql_error());
}
?>