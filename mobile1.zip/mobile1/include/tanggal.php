<?php
date_default_timezone_set('Asia/Jakarta');
$hour = gmdate("H");
$minute = gmdate("i");
$seconds = gmdate("s");
$day = gmdate("d");
$month = gmdate("m");
$year = gmdate("Y");
//echo $hour;
// This is the offset from the server time to Bangladesh time.
$hour = $hour + 7; 
$tgl_jam = date("h:i:s A Y-m-d", mktime ($hour,$minute,$seconds,$month,$day,$year));
$tgl_hariini=date("Ymd", mktime ($month,$day,$year));
$tgl_indonesia=date("Y-m-d", mktime ($month,$day,$year));
$tgl_inihari=date("d/m/Y", mktime ($month,$day,$year));
//echo $tgl_inihari;
$tgl_inihari_lagi =date("d/m/Y", mktime ($month,$day,$year));
$bln_kemaren = date("d/m/Y", mktime ($day,$month,$year));
$bln_kemaren1 = mktime($hour,$minute,$seconds,$month,$day,$year)-'30'*'24'*'60'*'60';
$bln_kemaren23 = date("d/m/Y", $bln_kemaren1 );
//$day1 = $day -"1";
$kemaren = mktime($hour,$minute,$seconds,$month,$day,$year)-'24'*'60'*'60';
$num_tanggal =date("d", mktime ($month,$day,$year));
$num_bulan =date("m", mktime ($month,$day,$year));
$num_tahun =date("Y", mktime ($month,$day,$year));
$num_tahun_dua =date("y", mktime ($month,$day,$year));
$tgl_indonesiakemaren=date("Y-m-d", $kemaren);
$tgl_kemaren_loh=date("d/m/Y", $kemaren);
$jam = date("H:i:s", mktime ($hour,$minute,$seconds));
$jam_h_m = date("H:i", mktime ($hour,$minute,$seconds));
$lengkap = date("Y-m-d h:i:s", mktime ($hour,$minute,$seconds,$month,$day,$year)); 
$full_indonesia = date("d-m-Y h:i:s", mktime ($hour,$minute,$seconds,$month,$day,$year)); 
$tgl_full= date("dmy", mktime ($month,$day,$year)); 
list($jam, $menit, $detik) = split('[:]', $jam);
//echo "<br> Jam: $jam; Menit: $menit; Detik: $detik<br />\n";

//print "Jam "waktu[1]" Menit "waktu[2]" Detik "waktu[3]
if ($jam>=0 && $jam<=10){
  $salam= "Selamat pagi ";
}elseif ($jam>=10 && $jam<=15){
  $salam=  "Selamat siang ";
}elseif ($jam>=15 && $jam<=19){
  $salam= "Selamat sore ";
}elseif ($jam>=19 && $jam<=24){
  $salam=  "Selamat malem ";
}		
			
	date("l F d, Y H:i:s A", mktime ($hour,$minute,$seconds,$month,$day,$year));
	switch (date("w"))
	{
	case "0" : $hari="Minggu";break;
	case "1" : $hari="Senin";break;
	case "2" : $hari="Selasa";break; 
	case "3" : $hari="Rabu";break;
	case "4" : $hari="Kamis";break;
	case "5" : $hari="Jumat";break;
	case "6" : $hari="Sabtu";break;
	}
	switch (date("m")) 
	{
	case "1" : $bulan="Januari";break;
	case "2" : $bulan="Februari";break;
	case "3" : $bulan="Maret";break;
	case "4" : $bulan="April";break;
	case "5" : $bulan="Mei";break;
	case "6" : $bulan="Juni";break;
	case "7" : $bulan="Juli";break;
	case "8" : $bulan="Agustus";break;
	case "9" : $bulan="September";break; 
	case "10" : $bulan="Oktober";break;
	case "11" : $bulan="November";break;
	case "12" : $bulan="Desember";break;
	}
	$indDate="$hari, ". date("d") ." $bulan". date(" Y ");
	//echo "<font size=1 face=verdana color=#66FFCC><b>hari ini : $indDate</b></font>";
	$hariini=getdate();
	$jam="$hariini[hours]:$hariini[minutes]:$hariini[seconds]";
?>	
