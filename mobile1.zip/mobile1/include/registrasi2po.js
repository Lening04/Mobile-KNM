var xmlHttp;
var id;

function check_ppn(val, serverPage, elementId) {
	id = elementId;
	xmlHttp = getXmlHttpRequest();
	if (xmlHttp==null) {
		alert("Browser tidak mendukung ajax!");
		return;
	}
	var url = serverPage;
	url = url+"?x="+val;
	url = url+"&sid="+Math.random();
	xmlHttp.open("GET", url, true);
	xmlHttp.onreadystatechange = stateChange;
	xmlHttp.send(null);
}

function getXmlHttpRequest() {
	var xmlHttp = null;
	try {
		// mozilla
		xmlHttp = new XMLHttpRequest();	
	} catch (e) {
		try {
				// ie 6.0 +
			xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (E) {
				// ie 5.5 +
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	return xmlHttp;
}

function stateChange() {
	//alert("test");
	var x=document.getElementById("myform");
	if(xmlHttp.readyState==4 && xmlHttp.status==200) {
		//document.getElementById(id).innerHTML = xmlHttp.responseText;/*"OOO";*/
		x.elements['kode_po_int'].value = xmlHttp.responseText;
	} else if (xmlHttp.readyState>0 && xmlHttp.readyState<4) {
		//document.getElementById(id).innerHTML = "CEK PPN";
		x.elements['kode_po_int'].value = "CEK PPN";
	}
}