<?php
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('login.php', '_parent');</script>";
}
include('include/conn.php');
include('include/tanggal.php');
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href='images/knmlogo.png' rel='shortcut icon' type='image/x-icon'/>
<title>:: KNM ::</title>
</head>

<frameset cols="185,*" frameborder="no" border="0" framespacing="0">
  <frame src="menu.php" name="leftFrame" scrolling="No" noresize="noresize" id="leftFrame" title="leftFrame" />
  <frame src="content.php" name="content" id="content" title="mainFrame" />
</frameset>
<noframes><body>
</body>
</noframes>

</html>

