<?php
include('../include/conn.php');
include('../include/tanggal.php');
$q = strtolower($_GET["q"]);
if (!$q) return;
$sql_sup="SELECT
tbl_buyer.id_buyer,
tbl_buyer.nama_buyer
FROM
tbl_buyer
ORDER BY
tbl_buyer.nama_buyer ASC";
$query_sup = mysql_query($sql_sup);
$test = '';
while(list($kode,$nama) = mysql_fetch_row($query_sup)){
  $tampil = "[".$kode."] ".$nama;
  $items[$tampil] =$kode;
}
foreach ($items as $tampil=>$kode) {
	if (strpos(strtolower($tampil), $q) !== false) {
		echo "$tampil\n";
	}
}
?>