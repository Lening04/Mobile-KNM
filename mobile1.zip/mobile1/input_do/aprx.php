<?php
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";
//$user_appr=$_SESSION['user_name'];
$session_user=$_SESSION['user_name'];
//echo $session_user."<br>";
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
//echo $session_level."<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}

function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}

$no_pemesanan=trim($_POST[no_pemesanan]);

if($_POST[del]=='1'){
	$aprove="INSERT INTO `db_knm`.`tbl_retur_aprove` (`kode_so_int_FK`, `aprove_account`, `aprove_time`, `aprove_note`, `aprove_level`) VALUES ('$_POST[id]', '$_POST[user_approve]', '$_POST[date_time]', '$_POST[notefa]', '$session_level');";
	//echo $aprove;
	mysql_query($aprove);
	
	$gmt=date("Z");
	$session_time=date("U");
	$session_id=session_id();
	$ipaddress=$_SERVER['REMOTE_ADDR'];
	$ip= $REMOTE_ADDR;
	$host_name = GetHostByName($ip);
	$aktivitas="APPROVED RETURN FA ".$_REQUEST[id];
	$menu="SALES";
	$session_user=$_SESSION['user_name'];
	//echo $session_user."<br>";
	$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
	//echo $session_level."<br>";
	$url = $_SERVER['REQUEST_URI'];
	mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");

}
if($_POST[del]=='2'){
	$aprove1="INSERT INTO `db_knm`.`tbl_retur_aprove` (`kode_so_int_FK`, `aprove_account`, `aprove_time`, `aprove_note`, `aprove_level`) VALUES ('$_POST[id]', '$_POST[user_approve]', '$_POST[date_time]', '$_POST[notemkt]', '$session_level');";
	//echo $aprove1;
	mysql_query($aprove1);
	
	$gmt=date("Z");
	$session_time=date("U");
	$session_id=session_id();
	$ipaddress=$_SERVER['REMOTE_ADDR'];
	$ip= $REMOTE_ADDR;
	$host_name = GetHostByName($ip);
	$aktivitas="APPROVED RETURN MKT ".$_REQUEST[id];
	$menu="SALES";
	$session_user=$_SESSION['user_name'];
	//echo $session_user."<br>";
	$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
	//echo $session_level."<br>";
	$url = $_SERVER['REQUEST_URI'];
	mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");

}
if($_POST[del]=='3'){
	$unaprove1="DELETE FROM `db_knm`.`tbl_retur_aprove` WHERE  `kode_so_int_FK`='$_POST[id]' AND aprove_level = '$session_level';";
	//echo $unaprove1;
	mysql_query($unaprove1);
	
	$gmt=date("Z");
	$session_time=date("U");
	$session_id=session_id();
	$ipaddress=$_SERVER['REMOTE_ADDR'];
	$ip= $REMOTE_ADDR;
	$host_name = GetHostByName($ip);
	$aktivitas="UNAPPROVED RETURN MKT ".$_REQUEST[id];
	$menu="SALES";
	$session_user=$_SESSION['user_name'];
	//echo $session_user."<br>";
	$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
	//echo $session_level."<br>";
	$url = $_SERVER['REQUEST_URI'];
	mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");

}
if($_POST[del]=='4'){
	$unaprove2="DELETE FROM `db_knm`.`tbl_retur_aprove` WHERE  `kode_so_int_FK`='$_POST[id]' AND aprove_level = '$session_level';";
	//echo $unaprove2;
	mysql_query($unaprove2);
	
	$gmt=date("Z");
	$session_time=date("U");
	$session_id=session_id();
	$ipaddress=$_SERVER['REMOTE_ADDR'];
	$ip= $REMOTE_ADDR;
	$host_name = GetHostByName($ip);
	$aktivitas="UNAPPROVED RETURN FA ".$_REQUEST[id];
	$menu="SALES";
	$session_user=$_SESSION['user_name'];
	//echo $session_user."<br>";
	$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
	//echo $session_level."<br>";
	$url = $_SERVER['REQUEST_URI'];
	mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");

}
?>
<link href="../include/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<table width="100%" cellspacing="0" class="sort-table" id="table-1">
<thead>
  <tr >
    <td width="48" class="dr2"><div align="center">No</div></td>
    <td width="144" class="dr2"><div align="center">Barcode</div></td>
    <td width="652" class="dr2"><div align="center">Nama Barang</div></td>
	<td width="84" class="dr2"><div align="center">Satuan</div></td>
	<td width="124" class="dr2"><div align="center">Jumlah</div></td>
    <td width="125" class="dr2"><div align="center">Harga/Satuan</div></td>
	<td width="125" class="dr2"><div align="center">Total</div></td>
    </tr>
</thead>
<tbody>
<?php
	$sql_data="SELECT
tbl_retur.kode_retur_int,
tbl_retur.kode_retur,
tbl_retur.harga_jual,
tbl_retur.jumlah,
tbl_retur.id_satuan_FK,
tbl_retur.kode_produk_FK,
tbl_produk.kode_produk_buyer,
tbl_produk.nama_produk,
tbl_satuan.nama_satuan,
tbl_kd_fg5size.nama_size
FROM
tbl_retur
Inner Join tbl_produk ON tbl_produk.kode_produk = tbl_retur.kode_produk_FK
Inner Join tbl_satuan ON tbl_satuan.id_satuan = tbl_produk.id_satuan_FK
Inner Join tbl_kd_fg5size ON tbl_kd_fg5size.id_size = tbl_retur.id_size_FK
	WHERE tbl_retur.kode_retur_int = '$_REQUEST[id]'";
	//echo $sql_data;
	$qry_data = mysql_query($sql_data);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#9DC5E6";
		}else{
	   		$warna ="#BCDADA";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#FFFFB0'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  ><div align="center"><?php echo $i; ?></div></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "  width="144" ><div align="left"><?php echo $data[kode_produk_buyer];?></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  ><?php echo $data[nama_produk];?></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo $data[nama_satuan];?></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[jumlah]); $total_jumlah+=$data[jumlah];?></div></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[harga_jual]);$sumharga+=$data[harga_jual];?></div>	</td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php $total_harga=$data[harga_jual]*$data[jumlah]; echo comma0($total_harga); $sumharga+=$total_harga;?></div>	</td>
    </tr>
   <?php
   }
   ?>
   <tr >
   	<td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; " colspan="4"><div align="center">
	<input name="no_pemesanan" type="hidden" value="<?php echo $_POST[no_pemesanan];?>" />
	<input name="user_approve" type="hidden" value="<?php echo $session_user;?>" />
	<input name="date_time" type="hidden" value="<?php echo $lengkap;?>" />
	<input name="id" type="hidden" value="<?php echo $_POST[id];?>" />
   	</div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($total_jumlah);?></strong></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sumharga);?></strong></div></td>
   </tr>
   <tr >
   	<td colspan="2" style="color: windowtext; border-top: .5pt solid windowtext; " ><div align="left"><strong>Approved</strong></div></td>
	<td style="color: windowtext; border-top: .5pt solid windowtext; " ><div align="center">Note </div></td>
	<td colspan="2" style="color: windowtext; border-top: .5pt solid windowtext; " ><div align="center">Sign Date </div></td>
   	<td col style="color: windowtext; border-top: .5pt solid windowtext; "><div align="center">Name PIC </div></td>
   	<td style="color: windowtext; border-top: .5pt solid windowtext; "><div align="center"></div></td>
   </tr>
   <?php
   	$sql_a=mysql_query("select input_account,input_time from tbl_retur where kode_retur_int = '$_POST[id]'");
	$rs_a=mysql_fetch_assoc($sql_a);
	
	$sql_f=mysql_query("select kode_so_int_FK,aprove_time,aprove_note,aprove_account from tbl_retur_aprove where kode_so_int_FK = '$_POST[id]' AND aprove_level='FA'");
	$rs_f=mysql_fetch_assoc($sql_f);
	
	$sql_m=mysql_query("select kode_so_int_FK,aprove_time,aprove_note,aprove_account from tbl_retur_aprove where kode_so_int_FK = '$_POST[id]' AND aprove_level='MKT'");
	$rs_m=mysql_fetch_assoc($sql_m);
	//echo $rs_m[kode_so_int_FK];
   ?>
   <tr >
   	<td colspan="2" style="color: windowtext; border-top: .5pt solid windowtext; " ><div align="left"><input type="checkbox" name="cek_adm" checked="checked" disabled="disabled"/> Administrasi </div></td>
	<td style="color: windowtext; border-top: .5pt solid windowtext; " ><div align="center"><input type="text" name="noteadm" style="width: 100%; background-color:#FFFFCC;" disabled="disabled" /></div></td>
	<td colspan="2" style="color: windowtext; border-top: .5pt solid windowtext; " ><div align="center"><input name="sign_dateadm" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $rs_a[input_time];?>" disabled="disabled"/></div></td>
   	<td style="color: windowtext; border-top: .5pt solid windowtext; "><div align="center"><input name="name_adm" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $rs_a[input_account];?>" disabled="disabled"/></div></td>
   	<td style="color: windowtext; border-top: .5pt solid windowtext; "><div align="center"></div></td>
   </tr>
   <tr >
   	<td colspan="2" style="color: windowtext; " ><div align="left"><input type="checkbox" name="cek_mkt" onclick="get_del2(this.form, <?php echo $i;?>);" 
	<?php
		if($session_level=='MKT'){
			echo "";
		}else{
			echo "disabled='disabled'";
		}
	?>
	<?php 
		if(empty($rs_m[kode_so_int_FK])){
			echo "";
		}else{
			echo "disabled='disabled' checked='checked'"; 
		}
	?>/> Marketing </div></td>
	  <td style="color: windowtext; " ><div align="center"><input type="text" name="notemkt" style="width: 100%; background-color:#FFFFCC;" value="<?php echo $rs_m[aprove_note];?>"
	  <?php
		if($session_level=='MKT' && empty($rs_m[aprove_note])){
			echo "";
		}else{
			echo "disabled='disabled'";
		}
	?> /><input type="hidden" name="notemkth" value="<?php echo $rs_m[aprove_note];?>" /></div></td>
	<td colspan="2" style="color: windowtext; " ><div align="center"><input name="sign_datemkt" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $rs_m[aprove_time];?>" disabled="disabled"/>
	</div></td>
   	<td style="color: windowtext; "><div align="center"><input name="name_mkt" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $rs_m[aprove_account];?>" disabled="disabled"/>
   	</div></td>
	
   	<td style="color: windowtext; "><div align="center">
   	  <input type="<?php 
		if(empty($rs_m[kode_so_int_FK]) or $session_level <> 'MKT'){
			echo "hidden";
		}else{
			echo "button";
		}
	?>" name="UnApprovedmkt" value="UnApproved" onclick="get_unprovmkt(this.form, <?php echo $i;?>);"/></div></td>
   </tr>
   <tr >
   	<td colspan="2" style="color: windowtext; " ><div align="left"><input type="checkbox" name="cek_fa" onclick="get_del(this.form, <?php echo $i;?>);"  
	<?php
		if($session_level=='FA'){
			echo "";
		}else{
			echo "disabled='disabled'";
		}
	?> 
	<?php 
		if(empty($rs_f[kode_so_int_FK])){
			echo "";
		}else{
			echo "disabled='disabled' checked='checked'"; 
		}
	?>/> Finance </div></td>
	  <td style="color: windowtext; " ><div align="center"><input type="text" name="notefa" style="width: 100%; background-color:#FFFFCC;" value="<?php echo $rs_f[aprove_note];?>"
	  <?php
		if($session_level=='FA' && empty($rs_f[aprove_note])){
			echo "";
		}else{
			echo "disabled='disabled'";
		}
	?>/><input type="hidden" name="notefah" value="<?php echo $rs_f[aprove_note];?>" /></div></td>
	<td colspan="2" style="color: windowtext; "><div align="center"><input name="sign_datefa" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $rs_f[aprove_time];?>" disabled="disabled"/>
	</div></td>
   	<td style="color: windowtext; "><div align="center"><input name="name_fa" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $rs_f[aprove_account];?>" disabled="disabled"/>
   	</div></td>
   	<td style="color: windowtext; "><div align="center"><input type="<?php 
		if(empty($rs_f[kode_so_int_FK]) or $session_level <> 'FA'){
			echo "hidden";
		}else{
			echo "button"; 
		}
	?>" name="UnApprovedfa" value="UnApproved" onclick="get_unprovfa(this.form, <?php echo $i;?>);"/></div></td>
   </tr>
   </tbody>
</table>
<script type="text/javascript">
//<![CDATA[
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
//]]>
</script>
