<?php
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
function tampil_tgl($tgl){
  		list($year, $month ,$day ) = split('[/.-]', $tgl);
		$tgl_view=$day."-".$month."-".$year;
  		return $tgl_view;
	}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function konversi($x){
$x = abs($x);
$angka = array ("","satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
$temp = "";

if($x < 12){
	$temp = " ".$angka[$x];
}else if($x<20){
	$temp = konversi($x - 10)." belas";
}else if ($x<100){
	$temp = konversi($x/10)." puluh". konversi($x%10);
}else if($x<200){
	$temp = " seratus".konversi($x-100);
}else if($x<1000){
	$temp = konversi($x/100)." ratus".konversi($x%100);
}else if($x<2000){
	$temp = " seribu".konversi($x-1000);
}else if($x<1000000){
	$temp = konversi($x/1000)." ribu".konversi($x%1000);
}else if($x<1000000000){
	$temp = konversi($x/1000000)." juta".konversi($x%1000000);
}else if($x<1000000000000){
	$temp = konversi($x/1000000000)." milyar".konversi($x%1000000000);
}

return $temp;
}


function tkoma($x){
$str = stristr($x,".");
$ex = explode('.',$x);

if(($ex[1]/10) >= 1){
	$a = abs($ex[1]);
}
$string = array("nol", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan",   "sembilan","sepuluh", "sebelas");
$temp = "";

$a2 = $ex[1]/10;
$pjg = strlen($str);
$i =1;


if($a>=1 && $a< 12){
	$temp .= " ".$string[$a];
}else if($a>12 && $a<20){
	$temp .= konversi($a - 10)." belas";
}else if ($a>20 && $a<100){
	$temp .= konversi($a/10)." puluh". konversi($a%10);
}else{
	if($a2<1){
		while ($i<$pjg){
			$char = substr($str,$i,1);
			$i++;
			$temp .= " ".$string[$char];
		}
	}
}
return $temp;
}

function terbilang($x){
if($x<0){
	$hasil = "minus ".trim(konversi(x));
}else{
	$poin = trim(tkoma($x));
	$hasil = trim(konversi($x));
}
if($poin){
	$hasil = $hasil." koma ".$poin;
}else{
	$hasil = $hasil;
}
	return $hasil;
} 
$sql_head="SELECT
tbl_retur.id_retur,
tbl_retur.kode_retur_int,
tbl_retur.kode_retur,
tbl_retur.tanggal_retur,
tbl_retur.id_buyer_FK,
tbl_retur.id_company_FK,
tbl_buyer.nama_buyer,
tbl_buyer.alamat as alamat_buyer,
tbl_company.nama,
tbl_company.alamat as alamat_company
FROM
tbl_retur
Inner Join tbl_buyer ON tbl_buyer.id_buyer = tbl_retur.id_buyer_FK
Inner Join tbl_company ON tbl_company.id_company = tbl_retur.id_company_FK
WHERE tbl_retur.kode_retur_int = '$_REQUEST[id]'";
//echo $sql_head."<br>";
$qry_head=mysql_query($sql_head);
$head=mysql_fetch_assoc($qry_head);

?>
<link type="text/css" rel="stylesheet" href="../include/style_sj.css"/>
<script type="text/javascript">
function printPage(){
	if (typeof(window.print) != 'undefined') {
	window.print();
	}
}
</script>
<title>RETUR </title>
<style type="text/css">
<!--
.style2 {
font-weight: bold;
font-size:24px;
}
-->
</style>
<table class="medium" width="80%" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr>
    <td width="102" height="66" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"><IMG src="../images/knmlogo.png" width="100" /></div>
    </td>
    <td width="869" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; "><div align="center"><span class="style2">NOTA RETUR</span><br />
    <?php 
		echo "KODE RETUR : ".strtoupper($head[kode_retur])."<br>"."KODE INTERNAL : ".strtoupper($head[kode_retur_int])."<br>"."TANGGAL RETUR : ".tampil_tgl($head[tanggal_retur]);
	?></div></td>
  </tr>
</table>
  <table class="medium" width="80%" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr>
    <td width="512" height="17" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; " >&nbsp;DITERIMA OLEH</td>
    <td width="459" style="color: windowtext; border-right: .5pt solid windowtext; " >&nbsp;RETUR DARI</td>
    </tr>
  <tr >
    <td height="19" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; vertical-align:top; " >&nbsp;<?php echo $head[nama];?></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; vertical-align:top; " >&nbsp;<?php echo strtoupper($head[nama_buyer]);?></td>
    </tr>
  <tr >
    <td height="19" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; vertical-align:top; " >&nbsp;<?php echo str_replace("#","<br>&nbsp;",$head[alamat_company]);?></td>

    <td style="color: windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; vertical-align:top; ">&nbsp;<?php echo strtoupper(str_replace("#","<br>&nbsp;",$head[alamat_buyer]));?></td>
    </tr>
</table>
<table class="medium" width="80%" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr height="19">
  	<td height="38" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext; "><div align="center">NO</div></td>
    <td width="75" height="38" style="color: windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext; "><div align="center">BARCODE</div></td>
    <td width="487" style="color: windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext; "><div align="center">NAMA BARANG</div></td>
    <td width="69" height="38" style="color: windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext; "><div align="center">SIZE</div></td>
    <td width="50" height="38" style="color: windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext; "><div align="center">SATUAN</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext;"><div align="center">JUMLAH</div>
    <div align="center"></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext;"><div align="center">HARGA/UNIT</div> </td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: double windowtext; border-bottom: double windowtext;"><div align="center">TOTAL</div> </td>
  </tr>
  
  <?php
	$sql_data="SELECT
tbl_retur.kode_retur_int,
tbl_retur.kode_retur,
tbl_retur.harga_jual,
tbl_retur.jumlah,
tbl_retur.id_satuan_FK,
tbl_retur.kode_produk_FK,
tbl_produk.nama_produk,
tbl_satuan.nama_satuan,
tbl_kd_fg5size.nama_size
FROM
tbl_retur
Inner Join tbl_produk ON tbl_produk.kode_produk = tbl_retur.kode_produk_FK
Inner Join tbl_satuan ON tbl_satuan.id_satuan = tbl_produk.id_satuan_FK
Inner Join tbl_kd_fg5size ON tbl_kd_fg5size.id_size = tbl_retur.id_size_FK
	WHERE tbl_retur.kode_retur_int = '$_REQUEST[id]'";
	//echo $sql_data;
	$qry_data = mysql_query($sql_data);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		//$kodesize=substr($data[kode_produk_FK],10,3);
		//echo $kodesize."<br>";
		//mencari kode zize
		//$sql_size=mysql_query("select nama_size from tbl_kd_fg5size where id_size = '$kodesize'");
		//$rs_size=mysql_fetch_row($sql_size);
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#9DC5E6";
		}else{
	   		$warna ="#BCDADA";
		}
?>
  <tr height="19">
    <td height="19" width="36" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><?php echo $i;?></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">&nbsp;<?php echo $data[kode_produk_FK];?></div></td>
    <td width="487" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;<?php echo $data[nama_produk];?></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center">&nbsp;<?php echo $data[nama_size];?></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><?php echo $data[nama_satuan];?></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php echo $data[jumlah];$sum_jumlah+=$data[jumlah];?>&nbsp;</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[harga_jual]);?>&nbsp;</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><?php $total=$data[jumlah]*$data[harga_jual]; echo comma0($total); $sum_total+=$total;?>&nbsp;</div></td>
  </tr>
  <?php
  }
  ?>
  <tr height="29">
    <td height="19" colspan="5" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="center"><strong>GRAND TOTAL</strong></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sum_jumlah);?>&nbsp;</strong></div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sum_total);?></strong>&nbsp;</div></td>
  </tr>
  </table>
  <table class="medium" width="80%" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr height="11">
    <td height="19" colspan="8"  style="color: windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  
  <tr height="17">
    <td colspan="7" rowspan="4" style="color: windowtext; border-left: .5pt solid windowtext; border-bottom: .5pt solid windowtext; vertical-align:top; ">&nbsp;REMARK :</td>
    <td width="63" height="17" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  <tr height="17" style="color: windowtext; border-right: .5pt solid windowtext; ">
    <td height="17" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  <tr height="17" style="color: windowtext; border-right: .5pt solid windowtext; ">
    <td height="17" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  <tr height="4" >
    <td height="4" style="color: windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
</table>
<table class="medium" width="80%" border="0" align="center" cellpadding="0" cellspacing="0" style=" border-collapse:collapse">
  <tr height="7">
    <td height="40" colspan="8" style="color: windowtext; ">&nbsp;TERBILANG  ; <?php echo ucwords(strtoupper(terbilang($sum_total)));?> RUPIAH</td>
  </tr>
  <tr height="19">
    <td width="282" height="19" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;DISIAPKAN OLEH</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;DIKETAHUI OLEH</td>
    <td width="284" style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;DISETUJUI OLEH</td>
  </tr>
  <tr height="19">
    <td height="19" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;TGL :</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;TGL :</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;TGL :</td>
  </tr>
  <tr height="19">
    <td height="19" style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;JAM :</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;JAM :</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;JAM :</td>
  </tr>
  <tr >
    <td style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
    <td width="232" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  <tr >
    <td style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
    <td width="232" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  <tr >
    <td style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
    <td width="232" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  <tr>
    <td style="color: windowtext; border-left: .5pt solid windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;</td>
    <td width="232" style="color: windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;</td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; border-bottom: .5pt solid windowtext; ">&nbsp;</td>
  </tr>
  <tr>
    <td style="color: windowtext; "><div align="right"><?php echo "";?></div></td>
	<td style="color: windowtext; "><div align="right"><em><?php echo "Tanggal Cetak";?></em></div></td>
	<td style="color: windowtext; "><div align="right"><em><?php echo $lengkap;?></em></div></td>
  </tr>
</table>
