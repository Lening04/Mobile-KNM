<?php
include('../include/conn.php');
include('../admin/tanggal.php');
$q = strtolower($_GET["q"]);
if (!$q) return;
$sql_sup="SELECT barcode,nama_produk FROM tbl_produk ORDER BY nama_produk ASC
";
$query_sup = mysql_query($sql_sup);
$test = '';
while(list($kode,$nama) = mysql_fetch_row($query_sup)){
  $tampil = "[".$kode."] ".$nama;
  $items[$tampil] =$kode;
}
foreach ($items as $tampil=>$kode) {
	if (strpos(strtolower($tampil), $q) !== false) {
		echo "$tampil\n";
	}
}
?>