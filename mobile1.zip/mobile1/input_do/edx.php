<?php
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";
$session_user=$_SESSION['user_name'];
$session_warehouse=$_SESSION['warehouse'];
function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}

$kode_so_int=trim($_POST[kode_retur]);

$tgl_return = $_POST[tgl_return];
list($day, $month, $year) = split('[/.-]', $tgl_return);
$tgl_return = $year."-".$month."-".$day;

// MENCARI id_satuan_FK
$sql_digt=mysql_query("select 
kode_produk,kode_produk_buyer,
nama_produk,nama_faktur_pajak,
nama_lain, id_sbu_FK,ppn,id_satuan_FK 
from tbl_produk 
where kode_produk = '$_POST[item]'");
$digit=mysql_fetch_assoc($sql_digt);
// MENCARI id_size_FK
$id_size_FK=substr($_POST[item],10,3);
//mencari id_buyer_grup_FK
$sql_buyer_grup_FK=mysql_query("select id_buyer_grup_FK from tbl_buyer where id_buyer = '$_POST[pemesan]'");
$buyer_grup_FK=mysql_fetch_assoc($sql_buyer_grup_FK);
//mencari id_company_FK
$sql_company_FK=mysql_query("select id_company_FK from tbl_buyer_grup where id_buyer_grup = '$buyer_grup_FK[id_buyer_grup_FK]'");
$company_FK=mysql_fetch_assoc($sql_company_FK);

//mencari harga terakhir
$sql_hrg=mysql_query("select harga_jual 
from tbl_harga 
where id_buyer_grup_FK = '$buyer_grup_FK[id_buyer_grup_FK]' 
and aktif = 'YES' 
and kode_produk_FK ='$_POST[item]'");
$hrg=mysql_fetch_assoc($sql_hrg);

if($_POST[status]=='3'){
	$input="INSERT INTO `tbl_retur` (
	`kode_retur_int`, `kode_retur`, `tanggal_retur`, `id_satuan_FK`, `id_size_FK`,
	`mc`, `harga_jual`, `jumlah`, `kode_produk_FK`, 
	`id_buyer_FK`, `id_company_FK`, `input_account`, `input_time`
	) VALUES (
	'$_POST[kode_retur]', '$_POST[no_return]', '$tgl_return', '$digit[id_satuan_FK]', '$id_size_FK',
	'', '$_POST[harga_jual]', '$_POST[jumlah]', '$_POST[item]',
	'$_POST[pemesan]', '$company_FK[id_company_FK]', '$_POST[input_account]', '$lengkap');";
	mysql_query($input);
	//echo $input."<br>";
	
	$insert_stok="INSERT INTO `db_knm`.`tbl_stok` (
	`kode_so_int_FK`, `tanggal_masuk`, `id_satuan_FK`, 
	`id_size_FK`, `mc`, `qty`, `kode_produk_FK`, `path_proses`, `id_gudang_FK`
	) VALUES (
	'$_POST[kode_retur]', '$tgl_return', '$digit[id_satuan_FK]', 
	'$id_size_FK', '', '$_POST[jumlah]', '$_POST[item]', 'RETURN', '$session_warehouse');";
	mysql_query($insert_stok);
	//echo $insert_stok."<br>";
}
if($_POST[del]=='1'){
	$dele="DELETE FROM `tbl_retur` WHERE `id_retur`='$_POST[id_retur]';";
	mysql_query($dele);
	//echo $dele."<br>";
	
	$del_stok="DELETE FROM `db_knm`.`tbl_stok` WHERE  `kode_so_int_FK`='$_POST[kode_retur]' AND `kode_produk_FK`='$_POST[kode_produk_FK]';";
	//echo $del_stok."<br>";
	mysql_query($del_stok);
}
if($_POST[status]=='1'){
	$ganti_buyer="UPDATE `db_knm`.`tbl_retur` SET `id_buyer_FK`='$_POST[pemesan]' WHERE  `kode_retur_int`='$_POST[kode_retur]';";
	mysql_query($ganti_buyer);
	//echo $ganti_buyer;
}
if($_POST[status]=='2'){
	$ganti_tanggal="UPDATE `db_knm`.`tbl_retur` SET `tanggal_retur`='$tgl_return' WHERE  `kode_retur_int`='$_POST[kode_retur]';";
	mysql_query($ganti_tanggal);
	//echo $ganti_tanggal."<br>";
	
	$ganti_tanggal1="UPDATE `db_knm`.`tbl_stok` SET `tanggal_masuk`='$tgl_return' WHERE  `kode_so_int_FK`='$_POST[kode_retur]';";
	mysql_query($ganti_tanggal1);
	//echo $ganti_tanggal1."<br>";
}
?>
<link href="../include/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<table width="100%" cellspacing="0" class="sort-table" id="table-1">
<thead>
  <tr >
    <td width="48" class="dr2"><div align="center">No</div></td>
    <td width="144" class="dr2"><div align="center">Barcode</div></td>
    <td width="652" class="dr2"><div align="center">Nama Barang</div></td>
	<td width="84" class="dr2"><div align="center">Satuan</div></td>
	<td width="124" class="dr2"><div align="center">Jumlah</div></td>
    <td width="125" class="dr2"><div align="center">Harga/Satuan</div></td>
	<td width="125" class="dr2"><div align="center">Total</div></td>
    <td width="38" class="dr2"><div align="center">Del</div></td>
  </tr>
</thead>
<tbody>
<?php
	$sql_data="SELECT
tbl_retur.id_retur,
tbl_retur.harga_jual,
tbl_retur.jumlah,
tbl_retur.id_satuan_FK,
tbl_produk.kode_produk_buyer,
tbl_retur.kode_produk_FK,
tbl_produk.nama_produk,
tbl_satuan.nama_satuan,
tbl_kd_fg5size.nama_size
FROM
tbl_retur
Inner Join tbl_produk ON tbl_produk.kode_produk = tbl_retur.kode_produk_FK
Inner Join tbl_satuan ON tbl_satuan.id_satuan = tbl_produk.id_satuan_FK
Inner Join tbl_kd_fg5size ON tbl_kd_fg5size.id_size = tbl_retur.id_size_FK
	WHERE tbl_retur.kode_retur_int = '$kode_so_int'";
	//echo $sql_data;
	$qry_data = mysql_query($sql_data);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#9DC5E6";
		}else{
	   		$warna ="#BCDADA";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#FFFFB0'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  ><div align="center"><?php echo $i; ?></div></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "  width="144" ><div align="left"><?php echo $data[kode_produk_buyer];?>
	  <input name="id_retur<?php echo $i;?>" type="hidden" value="<?php echo $data[id_retur];?>" />
      <input name="kode_produk_FK<?php echo $i;?>" type="hidden" value="<?php echo $data[kode_produk_FK];?>" />
	</div></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; "  ><?php echo $data[nama_produk];?></td>
    <td style="color: windowtext; border-right: .5pt solid windowtext; "><?php echo $data[nama_satuan];?></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[jumlah]); $total_jumlah+=$data[jumlah];?></div></td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[harga_jual]);$sumharga+=$data[harga_jual];?></div>	</td>
	<td style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php $total_harga=$data[harga_jual]*$data[jumlah]; echo comma0($total_harga); $sumharga+=$total_harga;?></div>	</td>
    <td width="38"  style="color: windowtext; border-right: .5pt solid windowtext; ">
	  <div align="center"><input type="checkbox" name="del" onclick="get_del(this.form, <?php echo $i;?>);" /></div>
	</a></td>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; " colspan="4"><div align="center">
    <input type="hidden" name="pemesan" value="<?php echo $_POST[pemesan];?>" />
    <input type="hidden" name="no_return" value="<?php echo $_POST[no_return];?>" />
    <input type="hidden" name="tgl_return" value="<?php echo $_POST[tgl_return];?>" />
    <input type="hidden" name="kode_retur" value="<?php echo $_POST[kode_retur];?>" /></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($total_jumlah);?></strong></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; "><div align="right"><strong><?php echo comma0($sumharga);?></strong></div></td>
   <td style="color: windowtext; border-right: .5pt solid windowtext; border-top: .5pt solid windowtext; ">&nbsp;</td>
   </tr>
   </tbody>
</table>
<script type="text/javascript">
//<![CDATA[
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
//]]>
</script>
