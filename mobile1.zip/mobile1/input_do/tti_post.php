<?php
include('../include/conn.php');
include('../include/tanggal.php');
//print_r($_POST); echo "<br>";

function tampil_tgl($tgl){
  list($year, $month ,$day ) = split('[/.-]', $tgl);
  $tgl_view=$day."/".$month."/".$year;
  return $tgl_view;
}
function comma2($rm){
  if(!empty($rm) || $rm!=0){
    $tmp = number_format($rm, 2, '.', ',');
  }else{
    $tmp = "-";
  }
  return $tmp;
}
function comma0($rm){
  if(!empty($rm)){
    if($rm < 0){
	   $rm = abs($rm);
	   $tmp = "(".number_format($rm, 0, '.', ',').")";
	}else{
	   $tmp = number_format($rm, 0, '.', ',');
	}
  }else{
    $tmp = "-";
  }
  return $tmp;
}

$tgl_return = $_POST[tgl_return];
list($day, $month, $year) = split('[/.-]', $tgl_return);
$tgl_return = $year."-".$month."-".$day;

if($_POST[del]=='1'){
	$dele="DELETE FROM `tbl_omzet` WHERE `id_tti`='$_POST[id]'";
	//echo $dele."<br>";
	mysql_query($dele);
	//$update_inv1="UPDATE `db_knm`.`tbl_inv` SET `scan`='' WHERE  `kode_so_int_FK`='$_POST[kode_so_int_FK]';";
	//echo $update_inv1."<br>";
	//mysql_query($update_inv1);
}
if($_POST[input]=='1'){
	$qry_gudang=mysql_query("select id_gudang, nama_gudang from tbl_gudang where id_gudang = '$_POST[dikirim_dari]'");
	//echo "select id_gudang, nama_gudang from tbl_gudang where id_gudang = '$_POST[dikirim_dari]'"."<br>";
	$rs_gudang=mysql_fetch_assoc($qry_gudang);
	
	$sql_nilai="SELECT
	tbl_buyer.nama_buyer,
	tbl_sj.harga_jual,
	tbl_sj.jumlah,
	tbl_sj.id_buyer_FK,
	tbl_sj.kode_so_int_FK,
	tbl_so.kode_so
	FROM
	tbl_buyer
	Inner Join tbl_sj ON tbl_sj.id_buyer_FK = tbl_buyer.id_buyer
	Inner Join tbl_so ON tbl_so.kode_so_int = tbl_sj.kode_so_int_FK
	WHERE
	tbl_sj.kode_so_int_FK = '$_POST[kode_so]'
	GROUP BY tbl_sj.kode_so_int_FK
	";
	$qry_nilai=mysql_query($sql_nilai);
	$nilai=mysql_fetch_assoc($qry_nilai);
	$xxx=$nilai[harga_jual]*$nilai[jumlah];
	//echo $sql_nilai."<br>";
	
	$insert="INSERT INTO `tbl_omzet` (
	`tgl_tti`, `kode_do_int`, `kode_so_int_FK`, `kode_so_FK`, `jumlah`, 
	`id_buyer_FK`, `nama_buyer`, `supir`, `jenis_kendaraan`, `nopol`, 
	`dikirim`, `id_gudang_FK`, `kasbon`, `realisasi`, `posting`,
	`revisi`, `status_rev`
	) VALUES (
	'$tgl_return', '$_POST[kode_retur]', '$_POST[kode_so]', '$nilai[kode_so]', '$xxx', 
	'$nilai[id_buyer_FK]', '$nilai[nama_buyer]', '$_POST[supir]', '$_POST[jenis_kend]','$_POST[nopol]', 
	'$rs_gudang[nama_gudang]', '$rs_gudang[id_gudang]', '$_POST[kasbon]', '0', '0',
	'0','0');";
	//echo $insert."<br>";
	mysql_query($insert);
}
///////////////////////////////////
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
<!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../admin/styles00.css" rel="stylesheet" type="text/css">
<title></title>
<link type="text/css" rel="StyleSheet" href="../include/sortabletable.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>


<form name="form_tr" action="" method="POST">
<div class="panel-body">
<div class="table-responsive">
<table class="table table-bordered table-hover table-striped" id="dataTable-example">
<thead>
  <tr >
    <th width="38" class="dr2"><div align="center">No</div></th>
	<th width="231" class="dr2"><div align="center">TANGGAL</div></th>
    <th width="229" class="dr2"><div align="center">KODE SO INTERNAL</div></th>
    <th width="229" class="dr2"><div align="center">KODE SO</div></th>
    <th width="321" class="dr2"><div align="center">TOTAL HARGA</div></th>
    <th width="364" class="dr2"><div align="center">CUSTOMER</div></th>
    <th width="34" class="dr2"><div align="center">DEL</div></th>
  </tr>
  </thead>
<tbody>
<?php
	$tgl_tti_post="$tgl_kirim1";
$order="ORDER BY tbl_omzet.tgl_tti DESC";
$sql_data="SELECT tbl_omzet.id_tti, 
tbl_omzet.tgl_tti, 
tbl_omzet.kode_so_FK, 
tbl_omzet.kode_so_int_FK, 
tbl_omzet.jumlah, 
tbl_omzet.id_buyer_FK, 
tbl_omzet.nama_buyer, 
tbl_omzet.supir,
tbl_omzet.jenis_kendaraan,
tbl_omzet.nopol,
tbl_omzet.dikirim
FROM tbl_omzet 
WHERE tbl_omzet.tgl_tti = '$tgl_return'
AND tbl_omzet.supir = '$_POST[supir]'
AND tbl_omzet.nopol = '$_POST[nopol]'
AND tbl_omzet.jenis_kendaraan = '$_POST[jenis_kend]'
AND tbl_omzet.id_gudang_FK = '$_POST[dikirim_dari]'
";
	$sql_data1=$sql_data." ".$order;
	//echo $sql_data1;
	$qry_data = mysql_query($sql_data1);
	$i='0';	
	while($data = mysql_fetch_assoc($qry_data)){
		$i++;
		$modulus = $i % 2; 
		if($modulus == '1'){
	   		$warna ="#9DC5E6";
		}else{
	   		$warna ="#BCDADA";
		}
?>
  <tr bgcolor="<?php echo $warna; ?>" onMouseover="this.style.backgroundColor='#FFFFB0'" onMouseout="this.style.backgroundColor='<?php echo $warna; ?>'">
    <th style="color: windowtext; border-right: .5pt solid windowtext; "  class="dr1"><div align="center"><?php echo $i; ?></div></th>
<th  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; ">&nbsp;<?php echo tampil_tgl($data[tgl_tti]);?>
  <input name="id<?php echo $i;?>" type="hidden" value="<?php echo $data[id_tti];?>" />
  <input name="kode_so_int_FK<?php echo $i;?>" type="hidden" value="<?php echo $data[kode_so_int_FK];?>" /></th>
    <th  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo $data[kode_so_int_FK];?></div>	</th>
    <th  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left">&nbsp;<?php 
	if(!empty($data[kode_so_new])){
		echo $data[kode_so_new];
	}else{
		echo $data[kode_so_FK];
	}
	?></div>	</th>
    <th  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="right"><?php echo comma0($data[jumlah]);$sum_tot+=$data[jumlah];?>&nbsp;</div>	</th>
    <th  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="left">&nbsp;<?php echo $data[nama_buyer];?></div>	</th>
    <th width="34"  class="dr1" style="color: windowtext; border-right: .5pt solid windowtext; "><div align="center"><input type="checkbox" name="del<?php echo $i;?>" onClick="get_del(this.form, <?php echo $i;?>);" ></div></th>
  </tr>
   <?php
   }
   ?>
   <tr >
   	<th colspan="7" style="color: windowtext; border-top: .5pt solid windowtext; "><div align="center">
    <input type="hidden" name="tgl_return" value="<?php echo $_POST[tgl_return];?>" />
    <input type="hidden" name="kode_so" value="<?php echo $_POST[kode_so];?>" />
    <input type="hidden" name="jenis_kend" value="<?php echo $_POST[jenis_kend];?>" />
    <input type="hidden" name="dikirim_dari" value="<?php echo $_POST[dikirim_dari];?>" />
    <input type="hidden" name="supir" value="<?php echo $_POST[supir];?>" />
    <input type="hidden" name="nopol" value="<?php echo $_POST[nopol];?>" />
	<input type="hidden" name="kode_retur" value="<?php echo $_POST[kode_retur];?>" />
    </div></th>
    </tr>
   </tbody>
</table>
</div>
</div>
</form>
<script type="text/javascript">
var st = new SortableTable( document.getElementById("table-1"),
	["NumberK", "String", "String", "String", "String", "String", "Date", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency", "UsCurrency"] );
st.sort( 1 );
</script>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
</html>