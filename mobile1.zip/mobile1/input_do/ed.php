<?php 
session_start();
if(empty($_SESSION[kdadmin])){
     echo "<script>window.open('../login.php', '_parent');</script>";
}
include('../include/conn.php');
include('../include/tanggal.php');
$gmt=date("Z");
$session_time=date("U");
$session_id=session_id();
$ipaddress=$_SERVER['REMOTE_ADDR'];
$ip= $REMOTE_ADDR;
$host_name = GetHostByName($ip);
$aktivitas="EDIT RETURN ".$_REQUEST[id];
$menu="SALES";
$session_user=$_SESSION['user_name'];
$session_level=$_SESSION['user_level'];
$session_warehouse=$_SESSION['warehouse'];
$url = $_SERVER['REQUEST_URI'];
mysql_query("INSERT INTO `sessions` ( `time`, `ip`, `page`, `session_id`, `session_visit`, `session_time`, `id_admin_FK`, `aktivitas`, `menu`, `warehouse`) VALUES ( '$lengkap', '$ipaddress', '$url', '$session_id', '$session_time', '$session_level', '$session_user','$aktivitas','$menu','$session_warehouse');");

function tampil_tgl($tgl){
  		list($year, $month ,$day ) = split('[/.-]', $tgl);
		$tgl_view=$day."/".$month."/".$year;
  		return $tgl_view;
	}
$sql_head=mysql_query("SELECT
tbl_retur.id_retur,
tbl_retur.kode_retur,
tbl_retur.kode_retur_int,
tbl_retur.tanggal_retur,
tbl_retur.id_satuan_FK,
tbl_retur.id_size_FK,
tbl_retur.harga_jual,
tbl_retur.jumlah,
tbl_retur.kode_produk_FK,
tbl_retur.id_buyer_FK,
tbl_buyer.nama_buyer
FROM
tbl_retur
Inner Join tbl_buyer ON tbl_buyer.id_buyer = tbl_retur.id_buyer_FK
WHERE tbl_retur.kode_retur_int='$_REQUEST[id]'
GROUP BY tbl_retur.kode_retur_int");	
$head=mysql_fetch_assoc($sql_head);
$status_ppn=substr($head[kode_so_int],5,2);

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EDIT</title>
<link type="text/css" rel="stylesheet" href="../include/styles00.css" />
<link type="text/css" rel="stylesheet" href="../include/dhtmlgoodies_calendar.css?random=20051112" media="screen"></LINK>
<link type="text/css" rel="stylesheet" href="../include/jquery.autocomplete.css" />
<link type="text/css" rel="stylesheet" href="../include/thickbox.css" />
<SCRIPT type="text/javascript" src="../include/dhtmlgoodies_calendar.js?random=20060118"></script>
<script type="text/javascript" src="../include/jquery.js"></script>
<script type="text/javascript" src="../include/menu.js"></script>
<script type="text/javascript" src="../include/sortabletable.js"></script>
<script type="text/javascript" src="../include/numberksorttype.js"></script>
<script type="text/javascript" src="../include/uscurrencysorttype.js"></script>
<script type="text/javascript" src="../include/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="../include/thickbox-compressed.js"></script>
<script type="text/javascript" src="../include/jquery.autocomplete.js"></script>
<script type="text/javascript" src="../include/localdata.js"></script>
<script type="text/javascript" src="../include/selectjenis.js"></script>
<script type="text/javascript" language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<!-------------data  autocomplet--->
<script type="text/javascript">
	$().ready(function() {
	
		function findValueCallback(event, data, formatted) {
			$("<li>").html( !data ? "No match!" : "Selected: " + formatted).appendTo("#result");
		}
		function formatItem(row) {
			return row[0] + " (<strong>id: " + row[1] + "</strong>)";

		}

		function formatResult(row) {
			return row[0].replace(/(<.+?>)/gi, '');
		}
		
		$("#singleBirdRemote1").autocomplete("pemesan.php", {
		width: 252,
		selectFirst: false
		});
		$("#singleBirdRemote1").result(function(event, data, formatted) {
			if (data)
				$(this).parent().next().find("input").val(data[1]);
		});
		/*$("#singleBirdRemote2").autocomplete("item.php", {
		width: 400,
		selectFirst: false
		});
		$("#singleBirdRemote2").result(function(event, data, formatted) {
			if (data)
				$(this).parent().next().find("input").val(data[1]);
		});*/
	});
	function changeOptions(){
		var max = parseInt(window.prompt('Please type number of items to display:', jQuery.Autocompleter.defaults.max));
		if (max > 0) {
			$("#suggest1").setOptions({
				max: max
			});
		}
	}
	function changeScrollHeight() {
		var h = parseInt(window.prompt('Please type new scroll height (number in pixels):', jQuery.Autocompleter.defaults.scrollHeight));
		if(h > 0) {
			$("#suggest1").setOptions({
				scrollHeight: h
			});
		}
	}
	function changeToMonths(){
		$("#suggest1")
			// clear existing data
			.val("")
			// change the local data to months
			.setOptions({data: months})
			// get the label tag
			.prev()
			// update the label tag
			.text("Month (local):");
	}
	var http_request = false;
   function makePOSTRequest(url, parameters) {
      http_request = false;
      if (window.XMLHttpRequest) { // Mozilla, Safari,...
         http_request = new XMLHttpRequest();
         if (http_request.overrideMimeType) {
            http_request.overrideMimeType('text/html');
         }
      } else if (window.ActiveXObject) { // IE
         try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
         } catch (e) {
            try {
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
         }
      }
      if (!http_request) {
         alert('Cannot create XMLHTTP instance');
         return false;
      }
      http_request.onreadystatechange = alertContents;
      http_request.open('POST', url, true);
      http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      http_request.setRequestHeader("Content-length", parameters.length);
      http_request.setRequestHeader("Connection", "close");
      http_request.send(parameters);
   }
   function alertContents() {
      if (http_request.readyState == 4) {
         if (http_request.status == 200) {
            result = http_request.responseText;
            document.getElementById('myspan').innerHTML = result;            
         } else {
            alert('There was a problem with the request.');
         }
      }
   }
function get_load(){
	var x=document.getElementById("myform"); 
	var poststr = "pemesan=" + encodeURI(x.elements['pemesan'].value)+
		"&no_return=" + encodeURI(x.elements['no_return'].value)+
		"&tgl_return=" + encodeURI(x.elements['tgl_return'].value)+
		"&kode_retur=" + encodeURI(x.elements['kode_retur'].value);
	makePOSTRequest('edx.php', poststr); 
}
function get_buyer(obj, df) { 
	var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_return=" + encodeURI(df['no_return'].value)+
				  "&tgl_return=" + encodeURI(df['tgl_return'].value)+
				  "&kode_retur=" + encodeURI(df['kode_retur'].value)+
				  "&item=" + encodeURI(df['item'].value)+
				  "&jumlah=" + encodeURI(df['jumlah'].value)+
				  "&harga_jual=" + encodeURI(df['harga_jual'].value)+
				  "&status=1";
	makePOSTRequest('edx.php', poststr);
}

function get_tglretur(obj, df) { 
	var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_return=" + encodeURI(df['no_return'].value)+
				  "&tgl_return=" + encodeURI(df['tgl_return'].value)+
				  "&kode_retur=" + encodeURI(df['kode_retur'].value)+
				  "&item=" + encodeURI(df['item'].value)+
				  "&jumlah=" + encodeURI(df['jumlah'].value)+
				  "&harga_jual=" + encodeURI(df['harga_jual'].value)+
				  "&status=2";
	makePOSTRequest('edx.php', poststr);
}

function get(obj, df) { 
	var poststr = "pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_return=" + encodeURI(df['no_return'].value)+
				  "&tgl_return=" + encodeURI(df['tgl_return'].value)+
				  "&kode_retur=" + encodeURI(df['kode_retur'].value)+
				  "&item=" + encodeURI(df['item'].value)+
				  "&jumlah=" + encodeURI(df['jumlah'].value)+
				  "&harga_jual=" + encodeURI(df['harga_jual'].value)+
				  "&input_account=" + encodeURI(df['input_account'].value)+
				  "&status=3";
	if(df['item'].value=='00000000000000000000'){
		alert ('Item Tolong Diisi');
	}else if(df['jumlah'].value==''){
		alert ('Jumlahnya Berapa ???');
	}else if(df['harga_jual'].value==''){
		alert ('Harganya Berapa ???');
	}else{
		makePOSTRequest('edx.php', poststr);
	}
}
function get_del(df, val) {  
if (confirm('Apakah anda ingin menghapus data ?')) {
	var poststr = "del=1"+  
				  "&pemesan=" + encodeURI(df['pemesan'].value)+ 
				  "&no_return=" + encodeURI(df['no_return'].value)+
				  "&tgl_return=" + encodeURI(df['tgl_return'].value)+
				  "&kode_retur=" + encodeURI(df['kode_retur'].value)+ 
				  "&kode_produk_FK=" + encodeURI(df['kode_produk_FK'+val].value)+ 
				  "&id_retur=" + encodeURI(df['id_retur'+val].value);
	makePOSTRequest('edx.php', poststr);
}else {
		return false;
 	}
}

function get_nol_jumlah(obj, df) {  
	df['jumlah'].value = '';
}

/////////////MEMBEDAKAN HURUF DAN ANGKA START/////////////////
function getkey(e)
{
if (window.event)
   return window.event.keyCode;
else if (e)
   return e.which;
else
   return null;
}
function goodchars(e, goods, field)
{
var key, keychar;
key = getkey(e);
if (key == null) return true;
 
keychar = String.fromCharCode(key);
keychar = keychar.toLowerCase();
goods = goods.toLowerCase();
 
// check goodkeys
if (goods.indexOf(keychar) != -1)
    return true;
// control keys
if ( key==null || key==0 || key==8 || key==9 || key==27 )
   return true;
    
if (key == 13) {
    var i;
    for (i = 0; i < field.form.elements.length; i++)
        if (field == field.form.elements[i])
            break;
    i = (i + 1) % field.form.elements.length;
    field.form.elements[i].focus();
    return false;
    };
// else return false
return false;
}
/////////////MEMBEDAKAN HURUF DAN ANGKA END/////////////////
</script>
<script type="text/javascript" src="../include/registrasi.js"></script>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
<form action="javascript:get(document.getElementById('myform'));" name="myform" id="myform">
<div align="left" style="font-size:11px; color:#FF0000;">SALES || RETURN || EDIT </div>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
<tr class="medium">
	<td width="12%" style="color: windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext; "><div align="left">&nbsp;PEMESAN
	  </div></td>
    <td width="29%" style="color: windowtext; border-top: .5pt solid windowtext; " ><div align="left">
      <select name="pemesan" style="width: 100%; background-color:#CCFF99;" onChange="javascript:get_buyer(this.parentNode, this.form);showCustomer(this.value)" >
	  	<option value="<?php echo $head[id_buyer_FK];?>" selected="selected"><?php echo $head[nama_buyer];?></option>
	  	<?php
			$sql_sup=mysql_query("SELECT tbl_buyer.id_buyer, tbl_buyer.nama_buyer FROM tbl_buyer WHERE tbl_buyer.id_buyer <> '$head[id_buyer_FK]' ORDER BY tbl_buyer.nama_buyer ASC");
			while($sup = mysql_fetch_assoc($sql_sup)){
		?>
		<option value="<?php echo $sup[id_buyer];?>"><?php echo $sup[nama_buyer];?></option>
		<?php
			}
		?>
	  </select>
    </div></td>
	<td width="22%" height="18" style="color: windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext; "><div align="left">&nbsp;TANGGAL<span class="style1">.</span>RETURN</div></td>
	<td width="31%" height="18" style="color: windowtext; border-top: .5pt solid windowtext; border-right: .5pt solid windowtext;" ><input type="text" style="width: 100%; background-color:#CCFF99;" name="tgl_return" onClick="displayCalendar(document.forms[0].tgl_return,'dd/mm/yyyy',this)" onChange="javascript:get_tglretur(this.parentNode, this.form);showCustomer(this.value)" value="<?php echo tampil_tgl($head[tanggal_retur]); ?>" readonly></td>
	</tr>
<tr class="medium">
	<td height="18" style="color: windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext; "><div align="left">&nbsp;NO. RETURN</div></td>
    <td style="color: windowtext; border-top: .5pt solid windowtext; "><div align="left"><input name="no_return" id="no_return" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $head[kode_retur];?>" readonly/></div></td>
	<td width="22%" height="18" style="color: windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext; "><div align="left">&nbsp;ID 
	</div></td>
	<td height="18" style="color: windowtext; border-top: .5pt solid windowtext; border-right: .5pt solid windowtext;"><input name="kode_retur" id="kode_retur" type="text" style="width: 100%; background-color:#CCFF99;" value="<?php echo $head[kode_retur_int];?>" readonly/></td>
	</tr>
<tr class="medium">
	<td height="18" style="color: windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext; "><div align="left">&nbsp;ITEM
	  </div></td>
    <td style="color: windowtext; border-top: .5pt solid windowtext; "><div align="left"><select name="item" style="width: 100%; background-color:#CCFF99;" >
	<option value="00000000000000000000" selected="selected">--- Isi Item ---</option>
	  	<?php
			$sql_item=mysql_query("SELECT tbl_produk.kode_produk, tbl_produk.nama_produk FROM tbl_produk ORDER BY tbl_produk.nama_produk ASC");
			while($item = mysql_fetch_assoc($sql_item)){
		?>
		<option value="<?php echo $item[kode_produk];?>"><?php echo strtoupper($item[nama_produk]);?></option>
		<?php
			}
		?>
	  </select></div></td>
    <td width="22%" height="18" style="color: windowtext; border-top: .5pt solid windowtext; border-left: .5pt solid windowtext; "><div align="left">&nbsp;JUMLAH / HARGA</div></td>
	<td style="color: windowtext; border-top: .5pt solid windowtext; border-right: .5pt solid windowtext;"><input name="jumlah" type="text" style="width: 30%; background-color:#FFFFCC;" onClick="javascript:get_nol_jumlah(this.parentNode, this.form);showCustomer(this.value)" onKeyPress="return goodchars(event,'0123456789.',this)"/>
	  &nbsp;&nbsp;/&nbsp;&nbsp;
	  <input name="harga_jual" type="text" style="width: 61%; background-color:#FFFFCC;" onClick="javascript:get_nol_harga(this.parentNode, this.form);showCustomer(this.value)" onKeyPress="return goodchars(event,'0123456789.',this)"/></td>
	</tr>
<tr class="medium">
	<td colspan="5" style="color: windowtext; border-top: .5pt solid windowtext; "><div align="center">
	  <input type="hidden" name="input_time" value="<?php echo $lengkap;?>">
	  <input type="hidden" name="input_account" value="<?php echo $session_user;?>">
	  <input class="inputbutton" type="button" name="button2" value="POST" onClick="javascript:get(this.parentNode, this.form);showCustomer(this.value)" />
      </div></td>
	</tr>
<tr class="medium">
	<td colspan="5" id="hslcek1"><div align="center"></div></td>
	</tr>
</table>
</form>
<form name="myform1" id="myform1"  method="post" >
<span name="myspan" id="myspan">
</form>
<script language=Javascript>
function Inint_AJAX() {
   try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
   try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
   try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
   alert("XMLHttpRequest not supported");
   return null;
};
window.onLoad=get_load();
</script>
</body>
</html>
