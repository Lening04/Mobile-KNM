<?php
	class cek_no_return {
		function createConnection() {
			require_once "../include/conn.php";
			mysql_select_db($database_conn);
		}
		
		function cek_no_return1($no_return) {
			if (!empty($no_return)) {
			  $user = trim($no_return);		
			      $query12 = mysql_query("SELECT kode_retur FROM tbl_retur where kode_retur ='$no_return'");
			      $result12 = mysql_fetch_array($query12);
			      if(empty($result12[0])){
					echo "<div align=center><input class=inputbutton type=button name=button2 value=POST onClick='javascript:get(this.parentNode, this.form);showCustomer(this.value)'/>   <input class=inputbutton type=button name=button3 value=SAVE onClick='javascript:window.close()'/></div>";
			      }else{
			        echo "<div align=center><font color=red>Already Registered</font><br/> <img src=../images/no.ico /></div>";
			      } 
			}else {
			  echo ""; 
			}
		}		
	}
	
	$no_return = $_GET['v'];
	cek_no_return::createConnection();
	cek_no_return::cek_no_return1($no_return);
?>
